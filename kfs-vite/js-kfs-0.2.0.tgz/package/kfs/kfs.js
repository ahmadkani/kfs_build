import { K } from "./kfs-Bpj766xl.js";
export {
  K as KFS
};
//# sourceMappingURL=kfs.js.map
