import { g as getDefaultExportFromCjs } from "./index-Euy9kdnd.js";
function _mergeNamespaces(n, m) {
  m.forEach(function(e) {
    e && typeof e !== "string" && !Array.isArray(e) && Object.keys(e).forEach(function(k) {
      if (k !== "default" && !(k in n)) {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function() {
            return e[k];
          }
        });
      }
    });
  });
  return Object.freeze(n);
}
var browser$2 = {};
var hasRequiredBrowser;
function requireBrowser() {
  if (hasRequiredBrowser) return browser$2;
  hasRequiredBrowser = 1;
  browser$2.endianness = function() {
    return "LE";
  };
  browser$2.hostname = function() {
    if (typeof location !== "undefined") {
      return location.hostname;
    } else return "";
  };
  browser$2.loadavg = function() {
    return [];
  };
  browser$2.uptime = function() {
    return 0;
  };
  browser$2.freemem = function() {
    return Number.MAX_VALUE;
  };
  browser$2.totalmem = function() {
    return Number.MAX_VALUE;
  };
  browser$2.cpus = function() {
    return [];
  };
  browser$2.type = function() {
    return "Browser";
  };
  browser$2.release = function() {
    if (typeof navigator !== "undefined") {
      return navigator.appVersion;
    }
    return "";
  };
  browser$2.networkInterfaces = browser$2.getNetworkInterfaces = function() {
    return {};
  };
  browser$2.arch = function() {
    return "javascript";
  };
  browser$2.platform = function() {
    return "browser";
  };
  browser$2.tmpdir = browser$2.tmpDir = function() {
    return "/tmp";
  };
  browser$2.EOL = "\n";
  browser$2.homedir = function() {
    return "/";
  };
  return browser$2;
}
var browserExports = requireBrowser();
var browser = /* @__PURE__ */ getDefaultExportFromCjs(browserExports);
var browser$1 = /* @__PURE__ */ _mergeNamespaces({
  __proto__: null,
  default: browser
}, [browserExports]);
export {
  browser$1 as b
};
//# sourceMappingURL=browser-DTbey3pl.js.map
