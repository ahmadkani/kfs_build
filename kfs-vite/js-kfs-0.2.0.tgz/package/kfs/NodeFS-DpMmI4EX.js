import { g as getConfig, w as workerPool, p as process$1, L as Logger } from "./kfs-Bpj766xl.js";
import fs from "fs/promises";
import path from "path";
import os from "os";
const config = await getConfig();
const logger = new Logger(config.logging.nodeFS);
function consoleDotLog(...parameters) {
  logger.consoleDotLog("[ NodeFS ] ", ...parameters);
}
class NodeFS {
  constructor(fsPath, options = {}) {
    this.virtualPath = fsPath;
    if (options.fsType === "node") {
      this.realPath = fsPath;
      consoleDotLog(`NodeFS Mode: Explicit Disk Path initialized at ${this.realPath}`);
    } else {
      const sanitizedName = fsPath.replace(/\//g, "_");
      this.realPath = path.join(os.tmpdir(), "kfs_node_temp", sanitizedName);
      consoleDotLog(`NodeFS Mode: Memory Path mapped to ${this.realPath}`);
    }
    this.fileDescriptors = /* @__PURE__ */ new Map();
    this.fdCounter = 3;
    this.workerEntry = null;
    this.workerThread = null;
    this.versioningStrategy = options?.versioning?.strategy || config.versioning.strategy;
    this.doImmediateCommit = this.versioningStrategy === "immediate" ? true : false;
    this.isInitialized = false;
    consoleDotLog(`NodeFS created for virtual path ${fsPath}`);
  }
  async _ensureRealPathExists() {
    try {
      await fs.mkdir(this.realPath, { recursive: true });
    } catch (error) {
    }
  }
  async initializeWorker() {
    if (this.isInitialized && this.workerThread) return;
    await this._ensureRealPathExists();
    this.workerEntry = await workerPool.getWorker(this.virtualPath);
    this.workerThread = this.workerEntry.thread;
    await this.workerThread.execute("setFs", {
      fsName: this.realPath,
      fsType: "node"
    });
    this.isInitialized = true;
    consoleDotLog(`Worker initialized for ${this.virtualPath} -> ${this.realPath}`);
  }
  async cleanup() {
    if (this.workerEntry) {
      await workerPool.releaseWorker(this.virtualPath);
      this.workerEntry = null;
      this.workerThread = null;
      this.isInitialized = false;
    }
  }
  async ensureInitialized() {
    if (!this.isInitialized || !this.workerThread) {
      await this.initializeWorker();
    }
  }
  async ensureInitialized() {
    if (!this.isInitialized || !this.workerThread) {
      await this.initializeWorker();
    }
  }
  // ... (Keep all the rest of the methods from previous NodeFS.js exactly the same) ...
  // (fs_fopen, fs_fclose, fs_fread, fs_fwrite, fs_stat, etc.)
  async fs_fopen(filename, mode) {
    await this.ensureInitialized();
    if (mode.includes("w") || mode.includes("a") || mode.includes("x")) {
      const parentDir = filename.split("/").slice(0, -1).join("/");
      if (parentDir && parentDir !== "") {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, open '${filename}'`);
        }
      }
    }
    const fd = this.fdCounter++;
    this.fileDescriptors.set(fd, { path: filename, pos: 0, mode });
    return fd;
  }
  async fs_fclose(fd) {
    if (!this.fileDescriptors.has(fd)) {
      throw new Error(`EBADF: bad file descriptor, close '${fd}'`);
    }
    this.fileDescriptors.delete(fd);
    return 0;
  }
  async fs_fread(fd, length) {
    const file = this.fileDescriptors.get(fd);
    if (!file) throw new Error(`EBADF: bad file descriptor, read '${fd}'`);
    await this.ensureInitialized();
    const data = await this.workerThread.execute("readFileDot", { filePath: file.path });
    if (data === null || data === void 0) throw new Error(`ENOENT: no such file, read '${file.path}'`);
    const chunk = data.slice(file.pos, file.pos + length);
    file.pos += chunk.length;
    return chunk;
  }
  async fs_fwrite(fd, content) {
    const file = this.fileDescriptors.get(fd);
    if (!file) throw new Error(`EBADF: bad file descriptor, write '${fd}'`);
    await this.ensureInitialized();
    const parentDir = file.path.split("/").slice(0, -1).join("/");
    if (parentDir && parentDir !== "") {
      const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
      if (!dirExists.exists || !dirExists.isDirectory) {
        throw new Error(`ENOENT: no such directory, open '${file.path}'`);
      }
    }
    let currentData = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
    let data = currentData || "";
    data = data.slice(0, file.pos) + content + data.slice(file.pos + content.length);
    await this.workerThread.execute("writeFileDot", {
      filePath: file.path,
      fileContent: data,
      doCommit: this.doImmediateCommit
    });
    file.pos += content.length;
    return content.length;
  }
  async fs_stat(path2) {
    await this.ensureInitialized();
    const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
    if (!exists.exists) throw new Error(`ENOENT: no such file or directory, stat '${path2}'`);
    const noteData = await this.workerThread.execute("getPathNote", { path: path2 }).catch(() => null);
    const metadata = noteData?.paths?.[path2.replace(/^\/+|\/+$/g, "")]?.metadata || {};
    const stats = {
      dev: 0,
      ino: metadata.inode || Math.floor(Math.random() * 1e6),
      mode: exists.isDirectory ? 16895 : 33188,
      nlink: 1,
      uid: process$1.getuid?.() || 1e3,
      gid: process$1.getgid?.() || 1e3,
      rdev: 0,
      size: metadata.size || 0,
      blksize: 4096,
      blocks: Math.ceil((metadata.size || 0) / 512),
      atimeMs: Date.now(),
      mtimeMs: Date.now(),
      ctimeMs: Date.now(),
      birthtimeMs: Date.now(),
      isDirectory: () => exists.isDirectory,
      isFile: () => !exists.isDirectory,
      isBlockDevice: () => false,
      isCharacterDevice: () => false,
      isSymbolicLink: () => false,
      isFIFO: () => false,
      isSocket: () => false
    };
    return stats;
  }
  async fs_fstat(fd) {
    const file = this.fileDescriptors.get(fd);
    if (!file) throw new Error(`EBADF: bad file descriptor`);
    return this.fs_stat(file.path);
  }
  async fs_remove(path2) {
    await this.ensureInitialized();
    const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
    if (!exists.exists) throw new Error(`ENOENT: no such file`);
    if (exists.isDirectory) throw new Error(`EISDIR: illegal operation on a directory`);
    await this.workerThread.execute("removeFileDot", { filePath: path2, doCommit: this.doImmediateCommit });
    return 0;
  }
  async fs_mkdir(path2) {
    await this.ensureInitialized();
    const parentDir = path2.split("/").slice(0, -1).join("/");
    if (parentDir && parentDir !== "") {
      const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
      if (!dirExists.exists || !dirExists.isDirectory) throw new Error(`ENOENT: no such directory`);
    }
    const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
    if (exists.exists) return exists.isDirectory ? -1 : Promise.reject(new Error("ENOTDIR"));
    await this.workerThread.execute("mkdirDot", { dirPath: path2, doCommit: this.doImmediateCommit });
    return 0;
  }
  async fs_rmdir(path2) {
    await this.ensureInitialized();
    const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
    if (!exists.exists) throw new Error(`ENOENT`);
    if (!exists.isDirectory) throw new Error(`ENOTDIR`);
    const dirContents = await this.fs_readdir(path2);
    if (dirContents.length > 0) throw new Error(`ENOTEMPTY`);
    await this.workerThread.execute("removeDirDot", { dirPath: path2, doCommit: this.doImmediateCommit });
    return 0;
  }
  async fs_readdir(path2, options = {}) {
    await this.ensureInitialized();
    const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
    if (!exists.exists) throw new Error(`ENOENT`);
    if (!exists.isDirectory) throw new Error(`ENOTDIR`);
    const result = await this.workerThread.execute("readDirDot", { path: path2 });
    return (result?.entries || []).map((e) => ({ name: e.name || e.path.split("/").pop(), path: e.path, type: e.type === "tree" ? "dir" : "file" }));
  }
  async fs_fcloseall() {
    this.fileDescriptors.clear();
    return 0;
  }
  async fs_fseek(fd, offset, whence) {
    return 0;
  }
  async fs_ftell(fd) {
    return 0;
  }
  async fs_ftruncate(fd, length) {
    return 0;
  }
  async fs_rename(oldPath, newPath) {
    throw new Error("Not implemented");
  }
  async fs_opendir(path2) {
    return 0;
  }
  async fs_feof(fd) {
    return false;
  }
  async fs_fflush(fd) {
    return 0;
  }
}
export {
  NodeFS
};
//# sourceMappingURL=NodeFS-DpMmI4EX.js.map
