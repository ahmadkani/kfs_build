function getDefaultExportFromCjs$1(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var browser$1 = { exports: {} };
var process = browser$1.exports = {};
var cachedSetTimeout;
var cachedClearTimeout;
function defaultSetTimout() {
  throw new Error("setTimeout has not been defined");
}
function defaultClearTimeout() {
  throw new Error("clearTimeout has not been defined");
}
(function() {
  try {
    if (typeof setTimeout === "function") {
      cachedSetTimeout = setTimeout;
    } else {
      cachedSetTimeout = defaultSetTimout;
    }
  } catch (e2) {
    cachedSetTimeout = defaultSetTimout;
  }
  try {
    if (typeof clearTimeout === "function") {
      cachedClearTimeout = clearTimeout;
    } else {
      cachedClearTimeout = defaultClearTimeout;
    }
  } catch (e2) {
    cachedClearTimeout = defaultClearTimeout;
  }
})();
function runTimeout(fun) {
  if (cachedSetTimeout === setTimeout) {
    return setTimeout(fun, 0);
  }
  if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
    cachedSetTimeout = setTimeout;
    return setTimeout(fun, 0);
  }
  try {
    return cachedSetTimeout(fun, 0);
  } catch (e2) {
    try {
      return cachedSetTimeout.call(null, fun, 0);
    } catch (e22) {
      return cachedSetTimeout.call(this, fun, 0);
    }
  }
}
function runClearTimeout(marker) {
  if (cachedClearTimeout === clearTimeout) {
    return clearTimeout(marker);
  }
  if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
    cachedClearTimeout = clearTimeout;
    return clearTimeout(marker);
  }
  try {
    return cachedClearTimeout(marker);
  } catch (e2) {
    try {
      return cachedClearTimeout.call(null, marker);
    } catch (e22) {
      return cachedClearTimeout.call(this, marker);
    }
  }
}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;
function cleanUpNextTick() {
  if (!draining || !currentQueue) {
    return;
  }
  draining = false;
  if (currentQueue.length) {
    queue = currentQueue.concat(queue);
  } else {
    queueIndex = -1;
  }
  if (queue.length) {
    drainQueue();
  }
}
function drainQueue() {
  if (draining) {
    return;
  }
  var timeout = runTimeout(cleanUpNextTick);
  draining = true;
  var len = queue.length;
  while (len) {
    currentQueue = queue;
    queue = [];
    while (++queueIndex < len) {
      if (currentQueue) {
        currentQueue[queueIndex].run();
      }
    }
    queueIndex = -1;
    len = queue.length;
  }
  currentQueue = null;
  draining = false;
  runClearTimeout(timeout);
}
process.nextTick = function(fun) {
  var args = new Array(arguments.length - 1);
  if (arguments.length > 1) {
    for (var i = 1; i < arguments.length; i++) {
      args[i - 1] = arguments[i];
    }
  }
  queue.push(new Item(fun, args));
  if (queue.length === 1 && !draining) {
    runTimeout(drainQueue);
  }
};
function Item(fun, array) {
  this.fun = fun;
  this.array = array;
}
Item.prototype.run = function() {
  this.fun.apply(null, this.array);
};
process.title = "browser";
process.browser = true;
process.env = {};
process.argv = [];
process.version = "";
process.versions = {};
function noop() {
}
process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;
process.listeners = function(name) {
  return [];
};
process.binding = function(name) {
  throw new Error("process.binding is not supported");
};
process.cwd = function() {
  return "/";
};
process.chdir = function(dir) {
  throw new Error("process.chdir is not supported");
};
process.umask = function() {
  return 0;
};
var browserExports = browser$1.exports;
const process$1 = /* @__PURE__ */ getDefaultExportFromCjs$1(browserExports);
class Logger {
  constructor(on = true, trace = false) {
    this.on = on;
    this.trace = trace;
  }
  consoleDotLog(...parameters) {
    if (!this.on) return;
    console.log(...parameters);
    this.trace && console.trace();
  }
  consoleDotError(...parameters) {
    if (!this.on) return;
    console.error(...parameters);
    this.trace && console.trace();
  }
}
var e = function(e2) {
  var t = this;
  this.rpc_counter = 0, this.channel = e2, this.foreign = /* @__PURE__ */ new Map(), this.local = /* @__PURE__ */ new Map(), this.calls = /* @__PURE__ */ new Map(), this.queue = [], this.connectionEstablished = false, this.channel.addEventListener("message", function(e3) {
    var n = e3.data;
    if (n && "object" == typeof n) switch (n.type) {
      case "MP_INIT":
        return t.onInit(n);
      case "MP_SET":
        return t.onSet(n);
      case "MP_CALL":
        return t.onCall(n);
      case "MP_RETURN":
        return t.onReturn(n);
    }
  }), this.channel.postMessage({ type: "MP_INIT", id: 1, reply: true });
};
e.prototype.onInit = function(e2) {
  this.connectionEstablished = true;
  var t = this.queue;
  this.queue = [];
  for (var n = 0, o = t; n < o.length; n += 1) {
    this.channel.postMessage(o[n]);
  }
  e2.reply && this.channel.postMessage({ type: "MP_INIT", reply: false });
}, e.prototype.onSet = function(e2) {
  for (var t = this, n = {}, o = e2.object, s = function() {
    var s2 = i[r], c2 = !e2.void.includes(s2);
    n[s2] = function() {
      for (var e3 = [], n2 = arguments.length; n2--; ) e3[n2] = arguments[n2];
      return t.rpc_counter = (t.rpc_counter + 1) % Number.MAX_SAFE_INTEGER, new Promise(function(n3, r2) {
        t.postMessage({ type: "MP_CALL", object: o, method: s2, id: t.rpc_counter, args: e3, reply: c2 }), c2 ? t.calls.set(t.rpc_counter, { resolve: n3, reject: r2 }) : n3();
      });
    };
  }, r = 0, i = e2.methods; r < i.length; r += 1) s();
  var c = this.foreign.get(e2.object);
  this.foreign.set(e2.object, n), "function" == typeof c && c(n);
}, e.prototype.onCall = function(e2) {
  var t = this, n = this.local.get(e2.object);
  n && n[e2.method].apply(n, e2.args).then(function(n2) {
    return e2.reply && t.channel.postMessage({ type: "MP_RETURN", id: e2.id, result: n2 });
  }).catch(function(n2) {
    return t.channel.postMessage({ type: "MP_RETURN", id: e2.id, error: n2.message });
  });
}, e.prototype.onReturn = function(e2) {
  if (this.calls.has(e2.id)) {
    var t = this.calls.get(e2.id), n = t.resolve, o = t.reject;
    this.calls.clear(e2.id), e2.error ? o(e2.error) : n(e2.result);
  }
}, e.prototype.postMessage = function(e2) {
  this.connectionEstablished ? this.channel.postMessage(e2) : this.queue.push(e2);
}, e.prototype.set = function(e2, t, n) {
  void 0 === n && (n = {}), this.local.set(e2, t);
  var o = Object.entries(t).filter(function(e3) {
    return "function" == typeof e3[1];
  }).map(function(e3) {
    return e3[0];
  });
  this.postMessage({ type: "MP_SET", object: e2, methods: o, void: n.void || [] });
}, e.prototype.get = function(e2) {
  return new Promise(function(t, n) {
    var o = this;
    return this.foreign.has(e2) ? t(this.foreign.get(e2)) : t(new Promise(function(t2, n2) {
      return o.foreign.set(e2, t2);
    }));
  }.bind(this));
};
function MagicPortal(t) {
  var n = new e(t);
  Object.defineProperties(this, { get: { writable: false, configurable: false, value: n.get.bind(n) }, set: { writable: false, configurable: false, value: n.set.bind(n) } });
}
let config$a = null;
const loggingGroups = {
  kfs: [
    "kfs",
    "fsType",
    "fsManagerES6",
    "fsManagerGlobal",
    "vfs",
    "VFSutils"
  ],
  gitWorker: [
    "gitWorker",
    "dotGit",
    "acl",
    "stats",
    "GitAuth",
    "WorkerPool",
    "gitNoteManager"
  ],
  storage: [
    "memoryFS",
    "memoryBackendES6",
    "memoryBackendGlobal",
    "IDBFs"
  ]
};
const defaultConfig = {
  corsProxy: "http://localhost:9000/",
  dir: "/",
  logging: {
    vfs: true,
    kfs: true,
    IDBFs: true,
    gitWorker: true,
    acl: true,
    stats: true,
    fsType: true,
    fsManagerES6: false,
    fsManagerGlobal: false,
    memoryFS: true,
    memoryBackendES6: false,
    memoryBackendGlobal: false,
    VFSutils: true,
    gitNoteManager: true,
    storageUtils: true,
    supportChecker: true,
    dotGit: true,
    GitAuth: true,
    WorkerPool: true
  },
  versioning: {
    strategy: "immediate",
    interval: 10,
    number: 5
  },
  merging: {
    strategy: "immediate",
    interval: 60,
    onConflictStrategy: "remote"
  }
};
let configReadyPromise = null;
async function loadConfig() {
  const candidates = [
    "/config.json",
    // served from host root
    "./config.json",
    // relative to current page URL
    "/kfs/config.json",
    // if library is under /kfs/
    "/dist/config.json",
    new URL("./config.json", import.meta.url).href,
    // same folder as this script
    new URL("../config.json", import.meta.url).href
    // one level up from script
  ];
  for (const url of candidates) {
    try {
      console.debug(`[Config] Trying to load config from: ${url}`);
      const response = await fetch(url);
      if (response.ok) {
        const jsonConfig = await response.json();
        console.debug(`[Config] Successfully loaded config from: ${url}`);
        if (jsonConfig.logging) {
          for (const group in loggingGroups) {
            if (jsonConfig.logging.hasOwnProperty(group)) {
              const value = jsonConfig.logging[group];
              loggingGroups[group].forEach((subKey) => {
                if (jsonConfig.logging.hasOwnProperty(subKey)) {
                  jsonConfig.logging[subKey] = value;
                }
              });
            }
          }
        }
        return {
          ...defaultConfig,
          ...jsonConfig,
          logging: {
            ...defaultConfig.logging,
            ...jsonConfig.logging || {}
          },
          versioning: {
            ...defaultConfig.versioning,
            ...jsonConfig.versioning || {}
          },
          merging: {
            ...defaultConfig.merging,
            ...jsonConfig.merging || {}
          }
        };
      } else {
        console.debug(`[Config] Failed to load from ${url} (status ${response.status})`);
      }
    } catch (err) {
      console.debug(`[Config] Error fetching ${url}: ${err.message}`);
    }
  }
  console.warn("Using default configuration: Config file not found in any candidate location.");
  return defaultConfig;
}
configReadyPromise = loadConfig().then((loadedConfig) => {
  config$a = loadedConfig;
  return config$a;
}).catch((error) => {
  console.error("Failed to load config:", error);
  config$a = defaultConfig;
  return config$a;
});
async function getConfig() {
  await configReadyPromise;
  return config$a;
}
const config$9 = await getConfig();
const logger$8 = new Logger(config$9.logging.WorkerPool);
function consoleDotLog$8(...parameters) {
  logger$8.consoleDotLog("[WorkerPool]", ...parameters);
}
function consoleDotError$7(...parameters) {
  logger$8.consoleDotError("[WorkerPool]", ...parameters);
}
consoleDotLog$8("Loading workerPool.");
class NodeWorkerWrapper {
  constructor(worker) {
    this.worker = worker;
    this.listeners = /* @__PURE__ */ new Map();
    this.worker.on("message", (message) => {
      const event = { data: message };
      if (this.onmessage) this.onmessage(event);
      const listeners = this.listeners.get("message") || [];
      listeners.forEach((fn) => fn(event));
    });
    this.worker.on("error", (err) => {
      const listeners = this.listeners.get("error") || [];
      listeners.forEach((fn) => fn(err));
    });
  }
  postMessage(message) {
    this.worker.postMessage(message);
  }
  addEventListener(type, listener) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(listener);
  }
  terminate() {
    return this.worker.terminate();
  }
}
class WorkerPool {
  constructor() {
    this.workers = /* @__PURE__ */ new Map();
    this.workerCount = 0;
    this.isNode = typeof window === "undefined";
  }
  async getWorker(mountPath, useSW = false) {
    try {
      if (!this.workers.has(mountPath)) {
        consoleDotLog$8(`Creating new worker for ${mountPath}`);
        let workerInstance;
        if (this.isNode) {
          const { Worker: Worker2 } = await import("worker_threads");
          const { fileURLToPath } = await import("url");
          const { dirname, join } = await import("path");
          const __filename = fileURLToPath(import.meta.url);
          const __dirname = dirname(__filename);
          const workerPath = join(__dirname, "workers", "gitWorker.js");
          const rawWorker = new Worker2(workerPath);
          workerInstance = new NodeWorkerWrapper(rawWorker);
        } else {
          workerInstance = new Worker(new URL(
            /* @vite-ignore */
            "/assets/gitWorker-DqVgfZDq.js",
            import.meta.url
          ), { type: "module" });
        }
        const portal = new MagicPortal(workerInstance);
        const thread = await Promise.race([
          portal.get("workerThread"),
          new Promise(
            (_, reject) => setTimeout(() => reject(new Error("Worker thread timeout")), 1e4)
          )
        ]);
        consoleDotLog$8("Worker thread obtained, waiting for readiness...");
        await thread.ready();
        consoleDotLog$8("Worker is ready");
        this.workers.set(mountPath, {
          worker: workerInstance,
          portal,
          thread,
          users: 0
        });
        this.workerCount++;
        consoleDotLog$8(`Worker for ${mountPath} initialized`);
      }
      const entry = this.workers.get(mountPath);
      entry.users++;
      return entry;
    } catch (error) {
      consoleDotError$7(`Failed to get worker for ${mountPath}:`, error);
      throw error;
    }
  }
  async releaseWorker(mountPath) {
    if (this.workers.has(mountPath)) {
      const entry = this.workers.get(mountPath);
      entry.users--;
      if (entry.users <= 0) {
        await entry.worker.terminate();
        this.workers.delete(mountPath);
        this.workerCount--;
      }
    }
  }
}
const workerPool = new WorkerPool();
const config$8 = await getConfig();
const logger$7 = new Logger(config$8.logging.memoryFS);
function consoleDotLog$7(...parameters) {
  logger$7.consoleDotLog("[ MemoryFS ] ", ...parameters);
}
function consoleDotError$6(...parameters) {
  logger$7.consoleDotError("[ MemoryFS ] ", ...parameters);
}
consoleDotLog$7("memoryFs loaded.");
class MemoryFS {
  constructor(fsName, options = {}) {
    this.fsName = fsName;
    this.fileDescriptors = /* @__PURE__ */ new Map();
    this.fdCounter = 3;
    this.workerEntry = null;
    this.workerThread = null;
    this.versioningStrategy = options?.versioning?.strategy || config$8.versioning.strategy;
    this.doImmediateCommit = this.versioningStrategy === "immediate" ? true : false;
    this.isInitialized = false;
    consoleDotLog$7(`MemoryFS created for ${fsName}`);
  }
  async initializeWorker() {
    if (this.isInitialized && this.workerThread) return;
    this.workerEntry = await workerPool.getWorker(this.fsName);
    this.workerThread = this.workerEntry.thread;
    await this.workerThread.execute("setFs", {
      fsName: this.fsName,
      fsType: "memory"
    });
    this.isInitialized = true;
    consoleDotLog$7(`Worker initialized for ${this.fsName}`);
  }
  async cleanup() {
    if (this.workerEntry) {
      await workerPool.releaseWorker(this.fsName);
      this.workerEntry = null;
      this.workerThread = null;
      this.isInitialized = false;
    }
  }
  async ensureInitialized() {
    if (!this.isInitialized || !this.workerThread) {
      await this.initializeWorker();
    }
  }
  async fs_fopen(filename, mode) {
    await this.ensureInitialized();
    if (mode.includes("w") || mode.includes("a") || mode.includes("x")) {
      const parentDir = filename.split("/").slice(0, -1).join("/");
      if (parentDir && parentDir !== "") {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, open '${filename}'`);
        }
      }
    }
    const fd = this.fdCounter++;
    this.fileDescriptors.set(fd, { path: filename, pos: 0, mode });
    consoleDotLog$7(`File descriptor ${fd} created for ${filename}`);
    return fd;
  }
  async fs_fclose(fd) {
    consoleDotLog$7(`Closing file descriptor: ${fd}`);
    if (!this.fileDescriptors.has(fd)) {
      throw new Error(`EBADF: bad file descriptor, close '${fd}'`);
    }
    this.fileDescriptors.delete(fd);
    consoleDotLog$7(`File descriptor ${fd} closed successfully.`);
    return 0;
  }
  async fs_fread(fd, length) {
    consoleDotLog$7(`Reading ${length} bytes from file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, read '${fd}'`);
    }
    try {
      await this.ensureInitialized();
      const data = await this.workerThread.execute("readFileDot", { filePath: file.path });
      if (data === null || data === void 0) {
        throw new Error(`ENOENT: no such file, read '${file.path}'`);
      }
      const chunk = data.slice(file.pos, file.pos + length);
      file.pos += chunk.length;
      consoleDotLog$7(`Read chunk: ${chunk}, new position: ${file.pos}`);
      return chunk;
    } catch (error) {
      consoleDotError$6(`Error reading file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_fwrite(fd, content) {
    consoleDotLog$7(`Writing content to file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, write '${fd}'`);
    }
    try {
      await this.ensureInitialized();
      const parentDir = file.path.split("/").slice(0, -1).join("/");
      if (parentDir && parentDir !== "") {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, open '${file.path}'`);
        }
      }
      let currentData = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      let data = currentData;
      consoleDotLog$7(`Current data in file ${file.path}:`, data);
      if (data === null || data === void 0) data = "";
      data = data.slice(0, file.pos) + content + data.slice(file.pos + content.length);
      await this.workerThread.execute("writeFileDot", {
        filePath: file.path,
        fileContent: data,
        doCommit: this.doImmediateCommit
      });
      file.pos += content.length;
      consoleDotLog$7(`Content written to file ${file.path}, new position: ${file.pos}`);
      return content.length;
    } catch (error) {
      consoleDotError$6(`Error writing to file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_fseek(fd, offset, whence) {
    consoleDotLog$7(`Seeking in file descriptor: ${fd}, offset: ${offset}, whence: ${whence}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, seek '${fd}'`);
    }
    try {
      await this.ensureInitialized();
      const data = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      if (whence === "SEEK_SET") file.pos = offset;
      else if (whence === "SEEK_CUR") file.pos += offset;
      else if (whence === "SEEK_END") file.pos = (data?.length || 0) + offset;
      file.pos = Math.max(0, Math.min(file.pos, data?.length || 0));
      consoleDotLog$7(`New position in file ${file.path}: ${file.pos}`);
      return 0;
    } catch (error) {
      consoleDotError$6(`Error seeking in file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_ftell(fd) {
    consoleDotLog$7(`Getting current position for file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, tell '${fd}'`);
    }
    consoleDotLog$7(`Current position in file ${file.path}: ${file.pos}`);
    return file.pos;
  }
  async fs_ftruncate(fd, length) {
    consoleDotLog$7(`Truncating file descriptor: ${fd} to length: ${length}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, truncate '${fd}'`);
    }
    try {
      await this.ensureInitialized();
      let currentData = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      let data = currentData;
      consoleDotLog$7(`Current data in file ${file.path}:`, data);
      if (data === null || data === void 0) data = "";
      data = data.slice(0, length);
      await this.workerThread.execute("writeFileDot", {
        filePath: file.path,
        fileContent: data,
        doCommit: this.doImmediateCommit
      });
      consoleDotLog$7(`File ${file.path} truncated to length: ${length}`);
      return 0;
    } catch (error) {
      consoleDotError$6(`Error truncating file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_stat(path2, visited = /* @__PURE__ */ new Set()) {
    consoleDotLog$7(`Getting stats for path: ${path2}`);
    const pathKey = path2.toString();
    if (visited.has(pathKey)) {
      consoleDotError$6(`Circular reference detected at ${path2}`);
      throw new Error(`Circular reference detected at ${path2}`);
    }
    visited.add(pathKey);
    try {
      const normalizedPath = path2.replace(/^\/+|\/+$/g, "");
      await this.ensureInitialized();
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such file or directory, stat '${path2}'`);
      }
      let noteData = null;
      try {
        noteData = await this.workerThread.execute("getPathNote", { path: path2 });
      } catch (noteError) {
        consoleDotLog$7(`Could not get note for ${path2}:`, noteError.message);
      }
      const metadata = noteData?.paths?.[normalizedPath]?.metadata || noteData || { created_at: Date.now(), updated_at: Date.now() };
      const stats = {
        // Standard fs.Stats properties
        dev: 0,
        ino: metadata.inode || metadata.dentry_id || Math.floor(Math.random() * 1e6),
        mode: exists.isDirectory ? 16895 : 33188,
        // Directory or file with proper mode
        nlink: 1,
        uid: metadata.uid || process$1.getuid?.() || 1e3,
        gid: metadata.gid || process$1.getgid?.() || 1e3,
        rdev: 0,
        size: metadata.size || 0,
        blksize: metadata.block_size || 4096,
        blocks: Math.ceil((metadata.size || 0) / 512),
        atimeMs: metadata.atime ? new Date(metadata.atime).getTime() : Date.now(),
        mtimeMs: metadata.mtime ? new Date(metadata.mtime).getTime() : Date.now(),
        ctimeMs: metadata.ctime ? new Date(metadata.ctime).getTime() : Date.now(),
        birthtimeMs: metadata.created_at ? new Date(metadata.created_at).getTime() : Date.now(),
        // Deno/Node compatibility methods
        isDirectory: () => exists.isDirectory === true,
        isFile: () => exists.isDirectory === false,
        isBlockDevice: () => false,
        isCharacterDevice: () => false,
        isSymbolicLink: () => false,
        isFIFO: () => false,
        isSocket: () => false,
        // Timestamp getters for compatibility
        atime: new Date(metadata.atime || Date.now()),
        mtime: new Date(metadata.mtime || Date.now()),
        ctime: new Date(metadata.ctime || Date.now()),
        birthtime: new Date(metadata.created_at || Date.now())
      };
      stats.isDirectory = stats.isDirectory.bind(stats);
      stats.isFile = stats.isFile.bind(stats);
      stats.isBlockDevice = stats.isBlockDevice.bind(stats);
      stats.isCharacterDevice = stats.isCharacterDevice.bind(stats);
      stats.isSymbolicLink = stats.isSymbolicLink.bind(stats);
      stats.isFIFO = stats.isFIFO.bind(stats);
      stats.isSocket = stats.isSocket.bind(stats);
      consoleDotLog$7(`Retrieved stats for ${path2}:`, {
        isDirectory: stats.isDirectory(),
        size: stats.size,
        mode: stats.mode.toString(8)
      });
      return stats;
    } catch (error) {
      consoleDotError$6(`Error getting stats for path ${path2}:`, error.message);
      throw error;
    }
  }
  async fs_fstat(fd) {
    consoleDotLog$7(`Getting stats for file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, fstat '${fd}'`);
    }
    return this.fs_stat(file.path);
  }
  async fs_remove(path2) {
    await this.ensureInitialized();
    consoleDotLog$7(`Removing file: ${path2}`);
    try {
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such file, unlink '${path2}'`);
      }
      if (exists.isDirectory) {
        throw new Error(`EISDIR: illegal operation on a directory, unlink '${path2}'`);
      }
      await this.workerThread.execute("removeFileDot", {
        filePath: path2,
        doCommit: this.doImmediateCommit
      });
      return 0;
    } catch (error) {
      consoleDotError$6(`Error removing file ${path2}:`, error);
      throw error;
    }
  }
  async fs_mkdir(path2) {
    await this.ensureInitialized();
    consoleDotLog$7(`Creating directory: ${path2}`);
    try {
      const parentDir = path2.split("/").slice(0, -1).join("/");
      if (parentDir && parentDir !== "") {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, mkdir '${path2}'`);
        }
      }
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (exists.exists) {
        if (exists.isDirectory) {
          consoleDotError$6(`EEXIST: directory already exists, mkdir '${path2}'`);
          return -1;
        } else {
          throw new Error(`ENOTDIR: path exists but is not a directory, mkdir '${path2}'`);
        }
      }
      await this.workerThread.execute("mkdirDot", {
        dirPath: path2,
        doCommit: this.doImmediateCommit
      });
      return 0;
    } catch (error) {
      consoleDotError$6(`Error creating directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_rmdir(path2) {
    await this.ensureInitialized();
    consoleDotLog$7(`Removing directory: ${path2}`);
    try {
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such directory, rmdir '${path2}'`);
      }
      if (!exists.isDirectory) {
        throw new Error(`ENOTDIR: not a directory, rmdir '${path2}'`);
      }
      const dirContents = await this.fs_readdir(path2);
      if (dirContents.length > 0) {
        throw new Error(`ENOTEMPTY: directory not empty, rmdir '${path2}'`);
      }
      await this.workerThread.execute("removeDirDot", {
        dirPath: path2,
        doCommit: this.doImmediateCommit
      });
      return 0;
    } catch (error) {
      consoleDotError$6(`Error removing directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_rename(oldPath, newPath) {
    await this.ensureInitialized();
    consoleDotLog$7(`Renaming ${oldPath} to ${newPath}`);
    try {
      const oldExists = await this.workerThread.execute("isDirectoryDot", { path: oldPath });
      if (!oldExists.exists) {
        throw new Error(`ENOENT: no such file or directory, rename '${oldPath}' -> '${newPath}'`);
      }
      const newParentDir = newPath.split("/").slice(0, -1).join("/");
      if (newParentDir && newParentDir !== "") {
        const parentExists = await this.workerThread.execute("isDirectoryDot", { path: newParentDir });
        if (!parentExists.exists || !parentExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, rename '${oldPath}' -> '${newPath}'`);
        }
      }
      await this.workerThread.execute("rename", {
        oldPath,
        newPath
      });
      return 0;
    } catch (error) {
      consoleDotError$6(`Error renaming ${oldPath} to ${newPath}:`, error);
      throw error;
    }
  }
  async fs_opendir(path2) {
    await this.ensureInitialized();
    consoleDotLog$7(`Opening directory: ${path2}`);
    try {
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such directory, opendir '${path2}'`);
      }
      if (!exists.isDirectory) {
        throw new Error(`ENOTDIR: not a directory, opendir '${path2}'`);
      }
      await this.workerThread.execute("opendir", { path: path2 });
      return 0;
    } catch (error) {
      consoleDotError$6(`Error opening directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_readdir(path2, options = {}) {
    consoleDotLog$7(`Reading directory: ${path2}`);
    try {
      await this.ensureInitialized();
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such directory, readdir '${path2}'`);
      }
      if (!exists.isDirectory) {
        throw new Error(`ENOTDIR: not a directory, readdir '${path2}'`);
      }
      const result = await this.workerThread.execute("readDirDot", { path: path2 });
      const dirEntries = result?.entries || [];
      return dirEntries.map((entry) => ({
        name: entry.name || entry.path.split("/").pop(),
        path: entry.path,
        type: entry.type === "tree" ? "dir" : "file"
      }));
    } catch (error) {
      consoleDotError$6(`Error reading directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_feof(fd) {
    consoleDotLog$7(`Checking EOF for file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, eof '${fd}'`);
    }
    try {
      await this.ensureInitialized();
      const data = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      consoleDotLog$7(`Current data in file ${file.path}:`, data);
      const eof = file.pos >= (data?.length || 0);
      consoleDotLog$7(`EOF status for file ${file.path}: ${eof}`);
      return eof;
    } catch (error) {
      consoleDotError$6(`Error checking EOF for file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_fflush(fd) {
    consoleDotLog$7(`Flushing file descriptor: ${fd}`);
    return 0;
  }
  async fs_fcloseall() {
    consoleDotLog$7("Closing all file descriptors.");
    this.fileDescriptors.clear();
    return 0;
  }
}
const memoryFs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  MemoryFS
}, Symbol.toStringTag, { value: "Module" }));
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
function getAugmentedNamespace(n) {
  if (Object.prototype.hasOwnProperty.call(n, "__esModule")) return n;
  var f = n.default;
  if (typeof f == "function") {
    var a = function a2() {
      if (this instanceof a2) {
        return Reflect.construct(f, arguments, this.constructor);
      }
      return f.apply(this, arguments);
    };
    a.prototype = f.prototype;
  } else a = {};
  Object.defineProperty(a, "__esModule", { value: true });
  Object.keys(n).forEach(function(k) {
    var d = Object.getOwnPropertyDescriptor(n, k);
    Object.defineProperty(a, k, d.get ? d : {
      enumerable: true,
      get: function() {
        return n[k];
      }
    });
  });
  return a;
}
var justOnce;
var hasRequiredJustOnce;
function requireJustOnce() {
  if (hasRequiredJustOnce) return justOnce;
  hasRequiredJustOnce = 1;
  justOnce = once;
  function once(fn) {
    var called, value;
    if (typeof fn !== "function") {
      throw new Error("expected a function but got " + fn);
    }
    return function wrap() {
      if (called) {
        return value;
      }
      called = true;
      value = fn.apply(this, arguments);
      return value;
    };
  }
  return justOnce;
}
var buffer = {};
var base64Js = {};
base64Js.byteLength = byteLength;
base64Js.toByteArray = toByteArray;
base64Js.fromByteArray = fromByteArray;
var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i];
  revLookup[code.charCodeAt(i)] = i;
}
revLookup["-".charCodeAt(0)] = 62;
revLookup["_".charCodeAt(0)] = 63;
function getLens(b64) {
  var len = b64.length;
  if (len % 4 > 0) {
    throw new Error("Invalid string. Length must be a multiple of 4");
  }
  var validLen = b64.indexOf("=");
  if (validLen === -1) validLen = len;
  var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
  return [validLen, placeHoldersLen];
}
function byteLength(b64) {
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];
  return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function _byteLength(b64, validLen, placeHoldersLen) {
  return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function toByteArray(b64) {
  var tmp;
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];
  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
  var curByte = 0;
  var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
  var i;
  for (i = 0; i < len; i += 4) {
    tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
    arr[curByte++] = tmp >> 16 & 255;
    arr[curByte++] = tmp >> 8 & 255;
    arr[curByte++] = tmp & 255;
  }
  if (placeHoldersLen === 2) {
    tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
    arr[curByte++] = tmp & 255;
  }
  if (placeHoldersLen === 1) {
    tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
    arr[curByte++] = tmp >> 8 & 255;
    arr[curByte++] = tmp & 255;
  }
  return arr;
}
function tripletToBase64(num) {
  return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
}
function encodeChunk(uint8, start, end) {
  var tmp;
  var output = [];
  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16 & 16711680) + (uint8[i + 1] << 8 & 65280) + (uint8[i + 2] & 255);
    output.push(tripletToBase64(tmp));
  }
  return output.join("");
}
function fromByteArray(uint8) {
  var tmp;
  var len = uint8.length;
  var extraBytes = len % 3;
  var parts = [];
  var maxChunkLength = 16383;
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
  }
  if (extraBytes === 1) {
    tmp = uint8[len - 1];
    parts.push(
      lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
    );
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1];
    parts.push(
      lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
    );
  }
  return parts.join("");
}
var ieee754 = {};
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
ieee754.read = function(buffer2, offset, isLE, mLen, nBytes) {
  var e2, m;
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = -7;
  var i = isLE ? nBytes - 1 : 0;
  var d = isLE ? -1 : 1;
  var s = buffer2[offset + i];
  i += d;
  e2 = s & (1 << -nBits) - 1;
  s >>= -nBits;
  nBits += eLen;
  for (; nBits > 0; e2 = e2 * 256 + buffer2[offset + i], i += d, nBits -= 8) {
  }
  m = e2 & (1 << -nBits) - 1;
  e2 >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer2[offset + i], i += d, nBits -= 8) {
  }
  if (e2 === 0) {
    e2 = 1 - eBias;
  } else if (e2 === eMax) {
    return m ? NaN : (s ? -1 : 1) * Infinity;
  } else {
    m = m + Math.pow(2, mLen);
    e2 = e2 - eBias;
  }
  return (s ? -1 : 1) * m * Math.pow(2, e2 - mLen);
};
ieee754.write = function(buffer2, value, offset, isLE, mLen, nBytes) {
  var e2, m, c;
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
  var i = isLE ? 0 : nBytes - 1;
  var d = isLE ? 1 : -1;
  var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  value = Math.abs(value);
  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0;
    e2 = eMax;
  } else {
    e2 = Math.floor(Math.log(value) / Math.LN2);
    if (value * (c = Math.pow(2, -e2)) < 1) {
      e2--;
      c *= 2;
    }
    if (e2 + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * Math.pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e2++;
      c /= 2;
    }
    if (e2 + eBias >= eMax) {
      m = 0;
      e2 = eMax;
    } else if (e2 + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen);
      e2 = e2 + eBias;
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
      e2 = 0;
    }
  }
  for (; mLen >= 8; buffer2[offset + i] = m & 255, i += d, m /= 256, mLen -= 8) {
  }
  e2 = e2 << mLen | m;
  eLen += mLen;
  for (; eLen > 0; buffer2[offset + i] = e2 & 255, i += d, e2 /= 256, eLen -= 8) {
  }
  buffer2[offset + i - d] |= s * 128;
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
(function(exports) {
  const base64 = base64Js;
  const ieee754$1 = ieee754;
  const customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
  exports.Buffer = Buffer2;
  exports.SlowBuffer = SlowBuffer2;
  exports.INSPECT_MAX_BYTES = 50;
  const K_MAX_LENGTH = 2147483647;
  exports.kMaxLength = K_MAX_LENGTH;
  const { Uint8Array: GlobalUint8Array, ArrayBuffer: GlobalArrayBuffer, SharedArrayBuffer: GlobalSharedArrayBuffer } = globalThis;
  Buffer2.TYPED_ARRAY_SUPPORT = typedArraySupport();
  if (!Buffer2.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
    console.error(
      "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
    );
  }
  function typedArraySupport() {
    try {
      const arr = new GlobalUint8Array(1);
      const proto = { foo: function() {
        return 42;
      } };
      Object.setPrototypeOf(proto, GlobalUint8Array.prototype);
      Object.setPrototypeOf(arr, proto);
      return arr.foo() === 42;
    } catch (e2) {
      return false;
    }
  }
  Object.defineProperty(Buffer2.prototype, "parent", {
    enumerable: true,
    get: function() {
      if (!Buffer2.isBuffer(this)) return void 0;
      return this.buffer;
    }
  });
  Object.defineProperty(Buffer2.prototype, "offset", {
    enumerable: true,
    get: function() {
      if (!Buffer2.isBuffer(this)) return void 0;
      return this.byteOffset;
    }
  });
  function createBuffer(length) {
    if (length > K_MAX_LENGTH) {
      throw new RangeError('The value "' + length + '" is invalid for option "size"');
    }
    const buf = new GlobalUint8Array(length);
    Object.setPrototypeOf(buf, Buffer2.prototype);
    return buf;
  }
  function Buffer2(arg, encodingOrOffset, length) {
    if (typeof arg === "number") {
      if (typeof encodingOrOffset === "string") {
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        );
      }
      return allocUnsafe(arg);
    }
    return from(arg, encodingOrOffset, length);
  }
  Buffer2.poolSize = 8192;
  function from(value, encodingOrOffset, length) {
    if (typeof value === "string") {
      return fromString(value, encodingOrOffset);
    }
    if (GlobalArrayBuffer.isView(value)) {
      return fromArrayView(value);
    }
    if (value == null) {
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
      );
    }
    if (isInstance(value, GlobalArrayBuffer) || value && isInstance(value.buffer, GlobalArrayBuffer)) {
      return fromArrayBuffer(value, encodingOrOffset, length);
    }
    if (typeof GlobalSharedArrayBuffer !== "undefined" && (isInstance(value, GlobalSharedArrayBuffer) || value && isInstance(value.buffer, GlobalSharedArrayBuffer))) {
      return fromArrayBuffer(value, encodingOrOffset, length);
    }
    if (typeof value === "number") {
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      );
    }
    const valueOf = value.valueOf && value.valueOf();
    if (valueOf != null && valueOf !== value) {
      return Buffer2.from(valueOf, encodingOrOffset, length);
    }
    const b = fromObject(value);
    if (b) return b;
    if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
      return Buffer2.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
    }
    throw new TypeError(
      "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
    );
  }
  Buffer2.from = function(value, encodingOrOffset, length) {
    return from(value, encodingOrOffset, length);
  };
  Object.setPrototypeOf(Buffer2.prototype, GlobalUint8Array.prototype);
  Object.setPrototypeOf(Buffer2, GlobalUint8Array);
  function assertSize(size) {
    if (typeof size !== "number") {
      throw new TypeError('"size" argument must be of type number');
    } else if (size < 0) {
      throw new RangeError('The value "' + size + '" is invalid for option "size"');
    }
  }
  function alloc(size, fill, encoding) {
    assertSize(size);
    if (size <= 0) {
      return createBuffer(size);
    }
    if (fill !== void 0) {
      return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
    }
    return createBuffer(size);
  }
  Buffer2.alloc = function(size, fill, encoding) {
    return alloc(size, fill, encoding);
  };
  function allocUnsafe(size) {
    assertSize(size);
    return createBuffer(size < 0 ? 0 : checked(size) | 0);
  }
  Buffer2.allocUnsafe = function(size) {
    return allocUnsafe(size);
  };
  Buffer2.allocUnsafeSlow = function(size) {
    return allocUnsafe(size);
  };
  function fromString(string, encoding) {
    if (typeof encoding !== "string" || encoding === "") {
      encoding = "utf8";
    }
    if (!Buffer2.isEncoding(encoding)) {
      throw new TypeError("Unknown encoding: " + encoding);
    }
    const length = byteLength2(string, encoding) | 0;
    let buf = createBuffer(length);
    const actual = buf.write(string, encoding);
    if (actual !== length) {
      buf = buf.slice(0, actual);
    }
    return buf;
  }
  function fromArrayLike(array) {
    const length = array.length < 0 ? 0 : checked(array.length) | 0;
    const buf = createBuffer(length);
    for (let i = 0; i < length; i += 1) {
      buf[i] = array[i] & 255;
    }
    return buf;
  }
  function fromArrayView(arrayView) {
    if (isInstance(arrayView, GlobalUint8Array)) {
      const copy = new GlobalUint8Array(arrayView);
      return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
    }
    return fromArrayLike(arrayView);
  }
  function fromArrayBuffer(array, byteOffset, length) {
    if (byteOffset < 0 || array.byteLength < byteOffset) {
      throw new RangeError('"offset" is outside of buffer bounds');
    }
    if (array.byteLength < byteOffset + (length || 0)) {
      throw new RangeError('"length" is outside of buffer bounds');
    }
    let buf;
    if (byteOffset === void 0 && length === void 0) {
      buf = new GlobalUint8Array(array);
    } else if (length === void 0) {
      buf = new GlobalUint8Array(array, byteOffset);
    } else {
      buf = new GlobalUint8Array(array, byteOffset, length);
    }
    Object.setPrototypeOf(buf, Buffer2.prototype);
    return buf;
  }
  function fromObject(obj) {
    if (Buffer2.isBuffer(obj)) {
      const len = checked(obj.length) | 0;
      const buf = createBuffer(len);
      if (buf.length === 0) {
        return buf;
      }
      obj.copy(buf, 0, 0, len);
      return buf;
    }
    if (obj.length !== void 0) {
      if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
        return createBuffer(0);
      }
      return fromArrayLike(obj);
    }
    if (obj.type === "Buffer" && Array.isArray(obj.data)) {
      return fromArrayLike(obj.data);
    }
  }
  function checked(length) {
    if (length >= K_MAX_LENGTH) {
      throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
    }
    return length | 0;
  }
  function SlowBuffer2(length) {
    if (+length != length) {
      length = 0;
    }
    return Buffer2.alloc(+length);
  }
  Buffer2.isBuffer = function isBuffer(b) {
    return b != null && b._isBuffer === true && b !== Buffer2.prototype;
  };
  Buffer2.compare = function compare(a, b) {
    if (isInstance(a, GlobalUint8Array)) a = Buffer2.from(a, a.offset, a.byteLength);
    if (isInstance(b, GlobalUint8Array)) b = Buffer2.from(b, b.offset, b.byteLength);
    if (!Buffer2.isBuffer(a) || !Buffer2.isBuffer(b)) {
      throw new TypeError(
        'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
      );
    }
    if (a === b) return 0;
    let x = a.length;
    let y = b.length;
    for (let i = 0, len = Math.min(x, y); i < len; ++i) {
      if (a[i] !== b[i]) {
        x = a[i];
        y = b[i];
        break;
      }
    }
    if (x < y) return -1;
    if (y < x) return 1;
    return 0;
  };
  Buffer2.isEncoding = function isEncoding(encoding) {
    switch (String(encoding).toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "latin1":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return true;
      default:
        return false;
    }
  };
  Buffer2.concat = function concat(list, length) {
    if (!Array.isArray(list)) {
      throw new TypeError('"list" argument must be an Array of Buffers');
    }
    if (list.length === 0) {
      return Buffer2.alloc(0);
    }
    let i;
    if (length === void 0) {
      length = 0;
      for (i = 0; i < list.length; ++i) {
        length += list[i].length;
      }
    }
    const buffer2 = Buffer2.allocUnsafe(length);
    let pos = 0;
    for (i = 0; i < list.length; ++i) {
      let buf = list[i];
      if (isInstance(buf, GlobalUint8Array)) {
        if (pos + buf.length > buffer2.length) {
          if (!Buffer2.isBuffer(buf)) buf = Buffer2.from(buf);
          buf.copy(buffer2, pos);
        } else {
          GlobalUint8Array.prototype.set.call(
            buffer2,
            buf,
            pos
          );
        }
      } else if (!Buffer2.isBuffer(buf)) {
        throw new TypeError('"list" argument must be an Array of Buffers');
      } else {
        buf.copy(buffer2, pos);
      }
      pos += buf.length;
    }
    return buffer2;
  };
  function byteLength2(string, encoding) {
    if (Buffer2.isBuffer(string)) {
      return string.length;
    }
    if (GlobalArrayBuffer.isView(string) || isInstance(string, GlobalArrayBuffer)) {
      return string.byteLength;
    }
    if (typeof string !== "string") {
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
      );
    }
    const len = string.length;
    const mustMatch = arguments.length > 2 && arguments[2] === true;
    if (!mustMatch && len === 0) return 0;
    let loweredCase = false;
    for (; ; ) {
      switch (encoding) {
        case "ascii":
        case "latin1":
        case "binary":
          return len;
        case "utf8":
        case "utf-8":
          return utf8ToBytes(string).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return len * 2;
        case "hex":
          return len >>> 1;
        case "base64":
          return base64ToBytes(string).length;
        default:
          if (loweredCase) {
            return mustMatch ? -1 : utf8ToBytes(string).length;
          }
          encoding = ("" + encoding).toLowerCase();
          loweredCase = true;
      }
    }
  }
  Buffer2.byteLength = byteLength2;
  function slowToString(encoding, start, end) {
    let loweredCase = false;
    if (start === void 0 || start < 0) {
      start = 0;
    }
    if (start > this.length) {
      return "";
    }
    if (end === void 0 || end > this.length) {
      end = this.length;
    }
    if (end <= 0) {
      return "";
    }
    end >>>= 0;
    start >>>= 0;
    if (end <= start) {
      return "";
    }
    if (!encoding) encoding = "utf8";
    while (true) {
      switch (encoding) {
        case "hex":
          return hexSlice(this, start, end);
        case "utf8":
        case "utf-8":
          return utf8Slice(this, start, end);
        case "ascii":
          return asciiSlice(this, start, end);
        case "latin1":
        case "binary":
          return latin1Slice(this, start, end);
        case "base64":
          return base64Slice(this, start, end);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return utf16leSlice(this, start, end);
        default:
          if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
          encoding = (encoding + "").toLowerCase();
          loweredCase = true;
      }
    }
  }
  Buffer2.prototype._isBuffer = true;
  function swap(b, n, m) {
    const i = b[n];
    b[n] = b[m];
    b[m] = i;
  }
  Buffer2.prototype.swap16 = function swap16() {
    const len = this.length;
    if (len % 2 !== 0) {
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    }
    for (let i = 0; i < len; i += 2) {
      swap(this, i, i + 1);
    }
    return this;
  };
  Buffer2.prototype.swap32 = function swap32() {
    const len = this.length;
    if (len % 4 !== 0) {
      throw new RangeError("Buffer size must be a multiple of 32-bits");
    }
    for (let i = 0; i < len; i += 4) {
      swap(this, i, i + 3);
      swap(this, i + 1, i + 2);
    }
    return this;
  };
  Buffer2.prototype.swap64 = function swap64() {
    const len = this.length;
    if (len % 8 !== 0) {
      throw new RangeError("Buffer size must be a multiple of 64-bits");
    }
    for (let i = 0; i < len; i += 8) {
      swap(this, i, i + 7);
      swap(this, i + 1, i + 6);
      swap(this, i + 2, i + 5);
      swap(this, i + 3, i + 4);
    }
    return this;
  };
  Buffer2.prototype.toString = function toString() {
    const length = this.length;
    if (length === 0) return "";
    if (arguments.length === 0) return utf8Slice(this, 0, length);
    return slowToString.apply(this, arguments);
  };
  Buffer2.prototype.toLocaleString = Buffer2.prototype.toString;
  Buffer2.prototype.equals = function equals(b) {
    if (!Buffer2.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
    if (this === b) return true;
    return Buffer2.compare(this, b) === 0;
  };
  Buffer2.prototype.inspect = function inspect() {
    let str = "";
    const max = exports.INSPECT_MAX_BYTES;
    str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
    if (this.length > max) str += " ... ";
    return "<Buffer " + str + ">";
  };
  if (customInspectSymbol) {
    Buffer2.prototype[customInspectSymbol] = Buffer2.prototype.inspect;
  }
  Buffer2.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
    if (isInstance(target, GlobalUint8Array)) {
      target = Buffer2.from(target, target.offset, target.byteLength);
    }
    if (!Buffer2.isBuffer(target)) {
      throw new TypeError(
        'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
      );
    }
    if (start === void 0) {
      start = 0;
    }
    if (end === void 0) {
      end = target ? target.length : 0;
    }
    if (thisStart === void 0) {
      thisStart = 0;
    }
    if (thisEnd === void 0) {
      thisEnd = this.length;
    }
    if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
      throw new RangeError("out of range index");
    }
    if (thisStart >= thisEnd && start >= end) {
      return 0;
    }
    if (thisStart >= thisEnd) {
      return -1;
    }
    if (start >= end) {
      return 1;
    }
    start >>>= 0;
    end >>>= 0;
    thisStart >>>= 0;
    thisEnd >>>= 0;
    if (this === target) return 0;
    let x = thisEnd - thisStart;
    let y = end - start;
    const len = Math.min(x, y);
    const thisCopy = this.slice(thisStart, thisEnd);
    const targetCopy = target.slice(start, end);
    for (let i = 0; i < len; ++i) {
      if (thisCopy[i] !== targetCopy[i]) {
        x = thisCopy[i];
        y = targetCopy[i];
        break;
      }
    }
    if (x < y) return -1;
    if (y < x) return 1;
    return 0;
  };
  function bidirectionalIndexOf(buffer2, val, byteOffset, encoding, dir) {
    if (buffer2.length === 0) return -1;
    if (typeof byteOffset === "string") {
      encoding = byteOffset;
      byteOffset = 0;
    } else if (byteOffset > 2147483647) {
      byteOffset = 2147483647;
    } else if (byteOffset < -2147483648) {
      byteOffset = -2147483648;
    }
    byteOffset = +byteOffset;
    if (numberIsNaN(byteOffset)) {
      byteOffset = dir ? 0 : buffer2.length - 1;
    }
    if (byteOffset < 0) byteOffset = buffer2.length + byteOffset;
    if (byteOffset >= buffer2.length) {
      if (dir) return -1;
      else byteOffset = buffer2.length - 1;
    } else if (byteOffset < 0) {
      if (dir) byteOffset = 0;
      else return -1;
    }
    if (typeof val === "string") {
      val = Buffer2.from(val, encoding);
    }
    if (Buffer2.isBuffer(val)) {
      if (val.length === 0) {
        return -1;
      }
      return arrayIndexOf(buffer2, val, byteOffset, encoding, dir);
    } else if (typeof val === "number") {
      val = val & 255;
      if (typeof GlobalUint8Array.prototype.indexOf === "function") {
        if (dir) {
          return GlobalUint8Array.prototype.indexOf.call(buffer2, val, byteOffset);
        } else {
          return GlobalUint8Array.prototype.lastIndexOf.call(buffer2, val, byteOffset);
        }
      }
      return arrayIndexOf(buffer2, [val], byteOffset, encoding, dir);
    }
    throw new TypeError("val must be string, number or Buffer");
  }
  function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
    let indexSize = 1;
    let arrLength = arr.length;
    let valLength = val.length;
    if (encoding !== void 0) {
      encoding = String(encoding).toLowerCase();
      if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
        if (arr.length < 2 || val.length < 2) {
          return -1;
        }
        indexSize = 2;
        arrLength /= 2;
        valLength /= 2;
        byteOffset /= 2;
      }
    }
    function read(buf, i2) {
      if (indexSize === 1) {
        return buf[i2];
      } else {
        return buf.readUInt16BE(i2 * indexSize);
      }
    }
    let i;
    if (dir) {
      let foundIndex = -1;
      for (i = byteOffset; i < arrLength; i++) {
        if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
          if (foundIndex === -1) foundIndex = i;
          if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
        } else {
          if (foundIndex !== -1) i -= i - foundIndex;
          foundIndex = -1;
        }
      }
    } else {
      if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
      for (i = byteOffset; i >= 0; i--) {
        let found = true;
        for (let j = 0; j < valLength; j++) {
          if (read(arr, i + j) !== read(val, j)) {
            found = false;
            break;
          }
        }
        if (found) return i;
      }
    }
    return -1;
  }
  Buffer2.prototype.includes = function includes(val, byteOffset, encoding) {
    return this.indexOf(val, byteOffset, encoding) !== -1;
  };
  Buffer2.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
  };
  Buffer2.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
  };
  function hexWrite(buf, string, offset, length) {
    offset = Number(offset) || 0;
    const remaining = buf.length - offset;
    if (!length) {
      length = remaining;
    } else {
      length = Number(length);
      if (length > remaining) {
        length = remaining;
      }
    }
    const strLen = string.length;
    if (length > strLen / 2) {
      length = strLen / 2;
    }
    let i;
    for (i = 0; i < length; ++i) {
      const parsed = parseInt(string.substr(i * 2, 2), 16);
      if (numberIsNaN(parsed)) return i;
      buf[offset + i] = parsed;
    }
    return i;
  }
  function utf8Write(buf, string, offset, length) {
    return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
  }
  function asciiWrite(buf, string, offset, length) {
    return blitBuffer(asciiToBytes(string), buf, offset, length);
  }
  function base64Write(buf, string, offset, length) {
    return blitBuffer(base64ToBytes(string), buf, offset, length);
  }
  function ucs2Write(buf, string, offset, length) {
    return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
  }
  Buffer2.prototype.write = function write(string, offset, length, encoding) {
    if (offset === void 0) {
      encoding = "utf8";
      length = this.length;
      offset = 0;
    } else if (length === void 0 && typeof offset === "string") {
      encoding = offset;
      length = this.length;
      offset = 0;
    } else if (isFinite(offset)) {
      offset = offset >>> 0;
      if (isFinite(length)) {
        length = length >>> 0;
        if (encoding === void 0) encoding = "utf8";
      } else {
        encoding = length;
        length = void 0;
      }
    } else {
      throw new Error(
        "Buffer.write(string, encoding, offset[, length]) is no longer supported"
      );
    }
    const remaining = this.length - offset;
    if (length === void 0 || length > remaining) length = remaining;
    if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
      throw new RangeError("Attempt to write outside buffer bounds");
    }
    if (!encoding) encoding = "utf8";
    let loweredCase = false;
    for (; ; ) {
      switch (encoding) {
        case "hex":
          return hexWrite(this, string, offset, length);
        case "utf8":
        case "utf-8":
          return utf8Write(this, string, offset, length);
        case "ascii":
        case "latin1":
        case "binary":
          return asciiWrite(this, string, offset, length);
        case "base64":
          return base64Write(this, string, offset, length);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return ucs2Write(this, string, offset, length);
        default:
          if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
          encoding = ("" + encoding).toLowerCase();
          loweredCase = true;
      }
    }
  };
  Buffer2.prototype.toJSON = function toJSON() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  };
  function base64Slice(buf, start, end) {
    if (start === 0 && end === buf.length) {
      return base64.fromByteArray(buf);
    } else {
      return base64.fromByteArray(buf.slice(start, end));
    }
  }
  function utf8Slice(buf, start, end) {
    end = Math.min(buf.length, end);
    const res = [];
    let i = start;
    while (i < end) {
      const firstByte = buf[i];
      let codePoint = null;
      let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
      if (i + bytesPerSequence <= end) {
        let secondByte, thirdByte, fourthByte, tempCodePoint;
        switch (bytesPerSequence) {
          case 1:
            if (firstByte < 128) {
              codePoint = firstByte;
            }
            break;
          case 2:
            secondByte = buf[i + 1];
            if ((secondByte & 192) === 128) {
              tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
              if (tempCodePoint > 127) {
                codePoint = tempCodePoint;
              }
            }
            break;
          case 3:
            secondByte = buf[i + 1];
            thirdByte = buf[i + 2];
            if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
              tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
              if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                codePoint = tempCodePoint;
              }
            }
            break;
          case 4:
            secondByte = buf[i + 1];
            thirdByte = buf[i + 2];
            fourthByte = buf[i + 3];
            if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
              tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
              if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                codePoint = tempCodePoint;
              }
            }
        }
      }
      if (codePoint === null) {
        codePoint = 65533;
        bytesPerSequence = 1;
      } else if (codePoint > 65535) {
        codePoint -= 65536;
        res.push(codePoint >>> 10 & 1023 | 55296);
        codePoint = 56320 | codePoint & 1023;
      }
      res.push(codePoint);
      i += bytesPerSequence;
    }
    return decodeCodePointsArray(res);
  }
  const MAX_ARGUMENTS_LENGTH = 4096;
  function decodeCodePointsArray(codePoints) {
    const len = codePoints.length;
    if (len <= MAX_ARGUMENTS_LENGTH) {
      return String.fromCharCode.apply(String, codePoints);
    }
    let res = "";
    let i = 0;
    while (i < len) {
      res += String.fromCharCode.apply(
        String,
        codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
      );
    }
    return res;
  }
  function asciiSlice(buf, start, end) {
    let ret = "";
    end = Math.min(buf.length, end);
    for (let i = start; i < end; ++i) {
      ret += String.fromCharCode(buf[i] & 127);
    }
    return ret;
  }
  function latin1Slice(buf, start, end) {
    let ret = "";
    end = Math.min(buf.length, end);
    for (let i = start; i < end; ++i) {
      ret += String.fromCharCode(buf[i]);
    }
    return ret;
  }
  function hexSlice(buf, start, end) {
    const len = buf.length;
    if (!start || start < 0) start = 0;
    if (!end || end < 0 || end > len) end = len;
    let out = "";
    for (let i = start; i < end; ++i) {
      out += hexSliceLookupTable[buf[i]];
    }
    return out;
  }
  function utf16leSlice(buf, start, end) {
    const bytes = buf.slice(start, end);
    let res = "";
    for (let i = 0; i < bytes.length - 1; i += 2) {
      res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
    }
    return res;
  }
  Buffer2.prototype.slice = function slice(start, end) {
    const len = this.length;
    start = ~~start;
    end = end === void 0 ? len : ~~end;
    if (start < 0) {
      start += len;
      if (start < 0) start = 0;
    } else if (start > len) {
      start = len;
    }
    if (end < 0) {
      end += len;
      if (end < 0) end = 0;
    } else if (end > len) {
      end = len;
    }
    if (end < start) end = start;
    const newBuf = this.subarray(start, end);
    Object.setPrototypeOf(newBuf, Buffer2.prototype);
    return newBuf;
  };
  function checkOffset(offset, ext, length) {
    if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
    if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
  }
  Buffer2.prototype.readUintLE = Buffer2.prototype.readUIntLE = function readUIntLE(offset, byteLength3, noAssert) {
    offset = offset >>> 0;
    byteLength3 = byteLength3 >>> 0;
    if (!noAssert) checkOffset(offset, byteLength3, this.length);
    let val = this[offset];
    let mul = 1;
    let i = 0;
    while (++i < byteLength3 && (mul *= 256)) {
      val += this[offset + i] * mul;
    }
    return val;
  };
  Buffer2.prototype.readUintBE = Buffer2.prototype.readUIntBE = function readUIntBE(offset, byteLength3, noAssert) {
    offset = offset >>> 0;
    byteLength3 = byteLength3 >>> 0;
    if (!noAssert) {
      checkOffset(offset, byteLength3, this.length);
    }
    let val = this[offset + --byteLength3];
    let mul = 1;
    while (byteLength3 > 0 && (mul *= 256)) {
      val += this[offset + --byteLength3] * mul;
    }
    return val;
  };
  Buffer2.prototype.readUint8 = Buffer2.prototype.readUInt8 = function readUInt8(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 1, this.length);
    return this[offset];
  };
  Buffer2.prototype.readUint16LE = Buffer2.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    return this[offset] | this[offset + 1] << 8;
  };
  Buffer2.prototype.readUint16BE = Buffer2.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    return this[offset] << 8 | this[offset + 1];
  };
  Buffer2.prototype.readUint32LE = Buffer2.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
  };
  Buffer2.prototype.readUint32BE = Buffer2.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
  };
  Buffer2.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === void 0 || last === void 0) {
      boundsError(offset, this.length - 8);
    }
    const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
    const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
    return BigInt(lo) + (BigInt(hi) << BigInt(32));
  });
  Buffer2.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === void 0 || last === void 0) {
      boundsError(offset, this.length - 8);
    }
    const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
    const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
    return (BigInt(hi) << BigInt(32)) + BigInt(lo);
  });
  Buffer2.prototype.readIntLE = function readIntLE(offset, byteLength3, noAssert) {
    offset = offset >>> 0;
    byteLength3 = byteLength3 >>> 0;
    if (!noAssert) checkOffset(offset, byteLength3, this.length);
    let val = this[offset];
    let mul = 1;
    let i = 0;
    while (++i < byteLength3 && (mul *= 256)) {
      val += this[offset + i] * mul;
    }
    mul *= 128;
    if (val >= mul) val -= Math.pow(2, 8 * byteLength3);
    return val;
  };
  Buffer2.prototype.readIntBE = function readIntBE(offset, byteLength3, noAssert) {
    offset = offset >>> 0;
    byteLength3 = byteLength3 >>> 0;
    if (!noAssert) checkOffset(offset, byteLength3, this.length);
    let i = byteLength3;
    let mul = 1;
    let val = this[offset + --i];
    while (i > 0 && (mul *= 256)) {
      val += this[offset + --i] * mul;
    }
    mul *= 128;
    if (val >= mul) val -= Math.pow(2, 8 * byteLength3);
    return val;
  };
  Buffer2.prototype.readInt8 = function readInt8(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 1, this.length);
    if (!(this[offset] & 128)) return this[offset];
    return (255 - this[offset] + 1) * -1;
  };
  Buffer2.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    const val = this[offset] | this[offset + 1] << 8;
    return val & 32768 ? val | 4294901760 : val;
  };
  Buffer2.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    const val = this[offset + 1] | this[offset] << 8;
    return val & 32768 ? val | 4294901760 : val;
  };
  Buffer2.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
  };
  Buffer2.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
  };
  Buffer2.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === void 0 || last === void 0) {
      boundsError(offset, this.length - 8);
    }
    const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
    return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
  });
  Buffer2.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === void 0 || last === void 0) {
      boundsError(offset, this.length - 8);
    }
    const val = (first << 24) + // Overflow
    this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
    return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
  });
  Buffer2.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return ieee754$1.read(this, offset, true, 23, 4);
  };
  Buffer2.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return ieee754$1.read(this, offset, false, 23, 4);
  };
  Buffer2.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 8, this.length);
    return ieee754$1.read(this, offset, true, 52, 8);
  };
  Buffer2.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 8, this.length);
    return ieee754$1.read(this, offset, false, 52, 8);
  };
  function checkInt(buf, value, offset, ext, max, min) {
    if (!Buffer2.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
    if (offset + ext > buf.length) throw new RangeError("Index out of range");
  }
  Buffer2.prototype.writeUintLE = Buffer2.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength3, noAssert) {
    value = +value;
    offset = offset >>> 0;
    byteLength3 = byteLength3 >>> 0;
    if (!noAssert) {
      const maxBytes = Math.pow(2, 8 * byteLength3) - 1;
      checkInt(this, value, offset, byteLength3, maxBytes, 0);
    }
    let mul = 1;
    let i = 0;
    this[offset] = value & 255;
    while (++i < byteLength3 && (mul *= 256)) {
      this[offset + i] = value / mul & 255;
    }
    return offset + byteLength3;
  };
  Buffer2.prototype.writeUintBE = Buffer2.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength3, noAssert) {
    value = +value;
    offset = offset >>> 0;
    byteLength3 = byteLength3 >>> 0;
    if (!noAssert) {
      const maxBytes = Math.pow(2, 8 * byteLength3) - 1;
      checkInt(this, value, offset, byteLength3, maxBytes, 0);
    }
    let i = byteLength3 - 1;
    let mul = 1;
    this[offset + i] = value & 255;
    while (--i >= 0 && (mul *= 256)) {
      this[offset + i] = value / mul & 255;
    }
    return offset + byteLength3;
  };
  Buffer2.prototype.writeUint8 = Buffer2.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
    this[offset] = value & 255;
    return offset + 1;
  };
  Buffer2.prototype.writeUint16LE = Buffer2.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
    this[offset] = value & 255;
    this[offset + 1] = value >>> 8;
    return offset + 2;
  };
  Buffer2.prototype.writeUint16BE = Buffer2.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
    this[offset] = value >>> 8;
    this[offset + 1] = value & 255;
    return offset + 2;
  };
  Buffer2.prototype.writeUint32LE = Buffer2.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
    this[offset + 3] = value >>> 24;
    this[offset + 2] = value >>> 16;
    this[offset + 1] = value >>> 8;
    this[offset] = value & 255;
    return offset + 4;
  };
  Buffer2.prototype.writeUint32BE = Buffer2.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
    this[offset] = value >>> 24;
    this[offset + 1] = value >>> 16;
    this[offset + 2] = value >>> 8;
    this[offset + 3] = value & 255;
    return offset + 4;
  };
  function wrtBigUInt64LE(buf, value, offset, min, max) {
    checkIntBI(value, min, max, buf, offset, 7);
    let lo = Number(value & BigInt(4294967295));
    buf[offset++] = lo;
    lo = lo >> 8;
    buf[offset++] = lo;
    lo = lo >> 8;
    buf[offset++] = lo;
    lo = lo >> 8;
    buf[offset++] = lo;
    let hi = Number(value >> BigInt(32) & BigInt(4294967295));
    buf[offset++] = hi;
    hi = hi >> 8;
    buf[offset++] = hi;
    hi = hi >> 8;
    buf[offset++] = hi;
    hi = hi >> 8;
    buf[offset++] = hi;
    return offset;
  }
  function wrtBigUInt64BE(buf, value, offset, min, max) {
    checkIntBI(value, min, max, buf, offset, 7);
    let lo = Number(value & BigInt(4294967295));
    buf[offset + 7] = lo;
    lo = lo >> 8;
    buf[offset + 6] = lo;
    lo = lo >> 8;
    buf[offset + 5] = lo;
    lo = lo >> 8;
    buf[offset + 4] = lo;
    let hi = Number(value >> BigInt(32) & BigInt(4294967295));
    buf[offset + 3] = hi;
    hi = hi >> 8;
    buf[offset + 2] = hi;
    hi = hi >> 8;
    buf[offset + 1] = hi;
    hi = hi >> 8;
    buf[offset] = hi;
    return offset + 8;
  }
  Buffer2.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
    return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
  });
  Buffer2.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
    return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
  });
  Buffer2.prototype.writeIntLE = function writeIntLE(value, offset, byteLength3, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) {
      const limit = Math.pow(2, 8 * byteLength3 - 1);
      checkInt(this, value, offset, byteLength3, limit - 1, -limit);
    }
    let i = 0;
    let mul = 1;
    let sub = 0;
    this[offset] = value & 255;
    while (++i < byteLength3 && (mul *= 256)) {
      if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
        sub = 1;
      }
      this[offset + i] = (value / mul >> 0) - sub & 255;
    }
    return offset + byteLength3;
  };
  Buffer2.prototype.writeIntBE = function writeIntBE(value, offset, byteLength3, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) {
      const limit = Math.pow(2, 8 * byteLength3 - 1);
      checkInt(this, value, offset, byteLength3, limit - 1, -limit);
    }
    let i = byteLength3 - 1;
    let mul = 1;
    let sub = 0;
    this[offset + i] = value & 255;
    while (--i >= 0 && (mul *= 256)) {
      if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
        sub = 1;
      }
      this[offset + i] = (value / mul >> 0) - sub & 255;
    }
    return offset + byteLength3;
  };
  Buffer2.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
    if (value < 0) value = 255 + value + 1;
    this[offset] = value & 255;
    return offset + 1;
  };
  Buffer2.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
    this[offset] = value & 255;
    this[offset + 1] = value >>> 8;
    return offset + 2;
  };
  Buffer2.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
    this[offset] = value >>> 8;
    this[offset + 1] = value & 255;
    return offset + 2;
  };
  Buffer2.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
    this[offset] = value & 255;
    this[offset + 1] = value >>> 8;
    this[offset + 2] = value >>> 16;
    this[offset + 3] = value >>> 24;
    return offset + 4;
  };
  Buffer2.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
    if (value < 0) value = 4294967295 + value + 1;
    this[offset] = value >>> 24;
    this[offset + 1] = value >>> 16;
    this[offset + 2] = value >>> 8;
    this[offset + 3] = value & 255;
    return offset + 4;
  };
  Buffer2.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
    return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  });
  Buffer2.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
    return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  });
  function checkIEEE754(buf, value, offset, ext, max, min) {
    if (offset + ext > buf.length) throw new RangeError("Index out of range");
    if (offset < 0) throw new RangeError("Index out of range");
  }
  function writeFloat(buf, value, offset, littleEndian, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) {
      checkIEEE754(buf, value, offset, 4);
    }
    ieee754$1.write(buf, value, offset, littleEndian, 23, 4);
    return offset + 4;
  }
  Buffer2.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
    return writeFloat(this, value, offset, true, noAssert);
  };
  Buffer2.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
    return writeFloat(this, value, offset, false, noAssert);
  };
  function writeDouble(buf, value, offset, littleEndian, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) {
      checkIEEE754(buf, value, offset, 8);
    }
    ieee754$1.write(buf, value, offset, littleEndian, 52, 8);
    return offset + 8;
  }
  Buffer2.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
    return writeDouble(this, value, offset, true, noAssert);
  };
  Buffer2.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
    return writeDouble(this, value, offset, false, noAssert);
  };
  Buffer2.prototype.copy = function copy(target, targetStart, start, end) {
    if (!Buffer2.isBuffer(target)) throw new TypeError("argument should be a Buffer");
    if (!start) start = 0;
    if (!end && end !== 0) end = this.length;
    if (targetStart >= target.length) targetStart = target.length;
    if (!targetStart) targetStart = 0;
    if (end > 0 && end < start) end = start;
    if (end === start) return 0;
    if (target.length === 0 || this.length === 0) return 0;
    if (targetStart < 0) {
      throw new RangeError("targetStart out of bounds");
    }
    if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
    if (end < 0) throw new RangeError("sourceEnd out of bounds");
    if (end > this.length) end = this.length;
    if (target.length - targetStart < end - start) {
      end = target.length - targetStart + start;
    }
    const len = end - start;
    if (this === target && typeof GlobalUint8Array.prototype.copyWithin === "function") {
      this.copyWithin(targetStart, start, end);
    } else {
      GlobalUint8Array.prototype.set.call(
        target,
        this.subarray(start, end),
        targetStart
      );
    }
    return len;
  };
  Buffer2.prototype.fill = function fill(val, start, end, encoding) {
    if (typeof val === "string") {
      if (typeof start === "string") {
        encoding = start;
        start = 0;
        end = this.length;
      } else if (typeof end === "string") {
        encoding = end;
        end = this.length;
      }
      if (encoding !== void 0 && typeof encoding !== "string") {
        throw new TypeError("encoding must be a string");
      }
      if (typeof encoding === "string" && !Buffer2.isEncoding(encoding)) {
        throw new TypeError("Unknown encoding: " + encoding);
      }
      if (val.length === 1) {
        const code2 = val.charCodeAt(0);
        if (encoding === "utf8" && code2 < 128 || encoding === "latin1") {
          val = code2;
        }
      }
    } else if (typeof val === "number") {
      val = val & 255;
    } else if (typeof val === "boolean") {
      val = Number(val);
    }
    if (start < 0 || this.length < start || this.length < end) {
      throw new RangeError("Out of range index");
    }
    if (end <= start) {
      return this;
    }
    start = start >>> 0;
    end = end === void 0 ? this.length : end >>> 0;
    if (!val) val = 0;
    let i;
    if (typeof val === "number") {
      for (i = start; i < end; ++i) {
        this[i] = val;
      }
    } else {
      const bytes = Buffer2.isBuffer(val) ? val : Buffer2.from(val, encoding);
      const len = bytes.length;
      if (len === 0) {
        throw new TypeError('The value "' + val + '" is invalid for argument "value"');
      }
      for (i = 0; i < end - start; ++i) {
        this[i + start] = bytes[i % len];
      }
    }
    return this;
  };
  const errors2 = {};
  function E(sym, getMessage, Base) {
    errors2[sym] = class NodeError extends Base {
      constructor() {
        super();
        Object.defineProperty(this, "message", {
          value: getMessage.apply(this, arguments),
          writable: true,
          configurable: true
        });
        this.name = `${this.name} [${sym}]`;
        this.stack;
        delete this.name;
      }
      get code() {
        return sym;
      }
      set code(value) {
        Object.defineProperty(this, "code", {
          configurable: true,
          enumerable: true,
          value,
          writable: true
        });
      }
      toString() {
        return `${this.name} [${sym}]: ${this.message}`;
      }
    };
  }
  E(
    "ERR_BUFFER_OUT_OF_BOUNDS",
    function(name) {
      if (name) {
        return `${name} is outside of buffer bounds`;
      }
      return "Attempt to access memory outside buffer bounds";
    },
    RangeError
  );
  E(
    "ERR_INVALID_ARG_TYPE",
    function(name, actual) {
      return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
    },
    TypeError
  );
  E(
    "ERR_OUT_OF_RANGE",
    function(str, range, input) {
      let msg = `The value of "${str}" is out of range.`;
      let received = input;
      if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
        received = addNumericalSeparator(String(input));
      } else if (typeof input === "bigint") {
        received = String(input);
        if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
          received = addNumericalSeparator(received);
        }
        received += "n";
      }
      msg += ` It must be ${range}. Received ${received}`;
      return msg;
    },
    RangeError
  );
  function addNumericalSeparator(val) {
    let res = "";
    let i = val.length;
    const start = val[0] === "-" ? 1 : 0;
    for (; i >= start + 4; i -= 3) {
      res = `_${val.slice(i - 3, i)}${res}`;
    }
    return `${val.slice(0, i)}${res}`;
  }
  function checkBounds(buf, offset, byteLength3) {
    validateNumber(offset, "offset");
    if (buf[offset] === void 0 || buf[offset + byteLength3] === void 0) {
      boundsError(offset, buf.length - (byteLength3 + 1));
    }
  }
  function checkIntBI(value, min, max, buf, offset, byteLength3) {
    if (value > max || value < min) {
      const n = typeof min === "bigint" ? "n" : "";
      let range;
      {
        if (min === 0 || min === BigInt(0)) {
          range = `>= 0${n} and < 2${n} ** ${(byteLength3 + 1) * 8}${n}`;
        } else {
          range = `>= -(2${n} ** ${(byteLength3 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength3 + 1) * 8 - 1}${n}`;
        }
      }
      throw new errors2.ERR_OUT_OF_RANGE("value", range, value);
    }
    checkBounds(buf, offset, byteLength3);
  }
  function validateNumber(value, name) {
    if (typeof value !== "number") {
      throw new errors2.ERR_INVALID_ARG_TYPE(name, "number", value);
    }
  }
  function boundsError(value, length, type) {
    if (Math.floor(value) !== value) {
      validateNumber(value, type);
      throw new errors2.ERR_OUT_OF_RANGE("offset", "an integer", value);
    }
    if (length < 0) {
      throw new errors2.ERR_BUFFER_OUT_OF_BOUNDS();
    }
    throw new errors2.ERR_OUT_OF_RANGE(
      "offset",
      `>= ${0} and <= ${length}`,
      value
    );
  }
  const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
  function base64clean(str) {
    str = str.split("=")[0];
    str = str.trim().replace(INVALID_BASE64_RE, "");
    if (str.length < 2) return "";
    while (str.length % 4 !== 0) {
      str = str + "=";
    }
    return str;
  }
  function utf8ToBytes(string, units) {
    units = units || Infinity;
    let codePoint;
    const length = string.length;
    let leadSurrogate = null;
    const bytes = [];
    for (let i = 0; i < length; ++i) {
      codePoint = string.charCodeAt(i);
      if (codePoint > 55295 && codePoint < 57344) {
        if (!leadSurrogate) {
          if (codePoint > 56319) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
            continue;
          } else if (i + 1 === length) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
            continue;
          }
          leadSurrogate = codePoint;
          continue;
        }
        if (codePoint < 56320) {
          if ((units -= 3) > -1) bytes.push(239, 191, 189);
          leadSurrogate = codePoint;
          continue;
        }
        codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
      } else if (leadSurrogate) {
        if ((units -= 3) > -1) bytes.push(239, 191, 189);
      }
      leadSurrogate = null;
      if (codePoint < 128) {
        if ((units -= 1) < 0) break;
        bytes.push(codePoint);
      } else if (codePoint < 2048) {
        if ((units -= 2) < 0) break;
        bytes.push(
          codePoint >> 6 | 192,
          codePoint & 63 | 128
        );
      } else if (codePoint < 65536) {
        if ((units -= 3) < 0) break;
        bytes.push(
          codePoint >> 12 | 224,
          codePoint >> 6 & 63 | 128,
          codePoint & 63 | 128
        );
      } else if (codePoint < 1114112) {
        if ((units -= 4) < 0) break;
        bytes.push(
          codePoint >> 18 | 240,
          codePoint >> 12 & 63 | 128,
          codePoint >> 6 & 63 | 128,
          codePoint & 63 | 128
        );
      } else {
        throw new Error("Invalid code point");
      }
    }
    return bytes;
  }
  function asciiToBytes(str) {
    const byteArray = [];
    for (let i = 0; i < str.length; ++i) {
      byteArray.push(str.charCodeAt(i) & 255);
    }
    return byteArray;
  }
  function utf16leToBytes(str, units) {
    let c, hi, lo;
    const byteArray = [];
    for (let i = 0; i < str.length; ++i) {
      if ((units -= 2) < 0) break;
      c = str.charCodeAt(i);
      hi = c >> 8;
      lo = c % 256;
      byteArray.push(lo);
      byteArray.push(hi);
    }
    return byteArray;
  }
  function base64ToBytes(str) {
    return base64.toByteArray(base64clean(str));
  }
  function blitBuffer(src2, dst, offset, length) {
    let i;
    for (i = 0; i < length; ++i) {
      if (i + offset >= dst.length || i >= src2.length) break;
      dst[i + offset] = src2[i];
    }
    return i;
  }
  function isInstance(obj, type) {
    return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
  }
  function numberIsNaN(obj) {
    return obj !== obj;
  }
  const hexSliceLookupTable = function() {
    const alphabet = "0123456789abcdef";
    const table = new Array(256);
    for (let i = 0; i < 16; ++i) {
      const i16 = i * 16;
      for (let j = 0; j < 16; ++j) {
        table[i16 + j] = alphabet[i] + alphabet[j];
      }
    }
    return table;
  }();
  function defineBigIntMethod(fn) {
    return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
  }
  function BufferBigIntNotDefined() {
    throw new Error("BigInt not supported");
  }
})(buffer);
const Buffer = buffer.Buffer;
var text_min = {};
var hasRequiredText_min;
function requireText_min() {
  if (hasRequiredText_min) return text_min;
  hasRequiredText_min = 1;
  (function(scope) {
    function B(r, e2) {
      var f;
      return r instanceof Buffer ? f = r : f = Buffer.from(r.buffer, r.byteOffset, r.byteLength), f.toString(e2);
    }
    var w = function(r) {
      return Buffer.from(r);
    };
    function h(r) {
      for (var e2 = 0, f = Math.min(256 * 256, r.length + 1), n = new Uint16Array(f), i = [], o = 0; ; ) {
        var t = e2 < r.length;
        if (!t || o >= f - 1) {
          var s = n.subarray(0, o), m = s;
          if (i.push(String.fromCharCode.apply(null, m)), !t) return i.join("");
          r = r.subarray(e2), e2 = 0, o = 0;
        }
        var a = r[e2++];
        if ((a & 128) === 0) n[o++] = a;
        else if ((a & 224) === 192) {
          var d = r[e2++] & 63;
          n[o++] = (a & 31) << 6 | d;
        } else if ((a & 240) === 224) {
          var d = r[e2++] & 63, l = r[e2++] & 63;
          n[o++] = (a & 31) << 12 | d << 6 | l;
        } else if ((a & 248) === 240) {
          var d = r[e2++] & 63, l = r[e2++] & 63, R = r[e2++] & 63, c = (a & 7) << 18 | d << 12 | l << 6 | R;
          c > 65535 && (c -= 65536, n[o++] = c >>> 10 & 1023 | 55296, c = 56320 | c & 1023), n[o++] = c;
        }
      }
    }
    function F(r) {
      for (var e2 = 0, f = r.length, n = 0, i = Math.max(32, f + (f >>> 1) + 7), o = new Uint8Array(i >>> 3 << 3); e2 < f; ) {
        var t = r.charCodeAt(e2++);
        if (t >= 55296 && t <= 56319) {
          if (e2 < f) {
            var s = r.charCodeAt(e2);
            (s & 64512) === 56320 && (++e2, t = ((t & 1023) << 10) + (s & 1023) + 65536);
          }
          if (t >= 55296 && t <= 56319) continue;
        }
        if (n + 4 > o.length) {
          i += 8, i *= 1 + e2 / r.length * 2, i = i >>> 3 << 3;
          var m = new Uint8Array(i);
          m.set(o), o = m;
        }
        if ((t & 4294967168) === 0) {
          o[n++] = t;
          continue;
        } else if ((t & 4294965248) === 0) o[n++] = t >>> 6 & 31 | 192;
        else if ((t & 4294901760) === 0) o[n++] = t >>> 12 & 15 | 224, o[n++] = t >>> 6 & 63 | 128;
        else if ((t & 4292870144) === 0) o[n++] = t >>> 18 & 7 | 240, o[n++] = t >>> 12 & 63 | 128, o[n++] = t >>> 6 & 63 | 128;
        else continue;
        o[n++] = t & 63 | 128;
      }
      return o.slice ? o.slice(0, n) : o.subarray(0, n);
    }
    var u = "Failed to ", p = function(r, e2, f) {
      if (r) throw new Error("".concat(u).concat(e2, ": the '").concat(f, "' option is unsupported."));
    };
    var x = typeof Buffer == "function" && Buffer.from;
    var A = x ? w : F;
    function v() {
      this.encoding = "utf-8";
    }
    v.prototype.encode = function(r, e2) {
      return p(e2 && e2.stream, "encode", "stream"), A(r);
    };
    function U(r) {
      var e2;
      try {
        var f = new Blob([r], { type: "text/plain;charset=UTF-8" });
        e2 = URL.createObjectURL(f);
        var n = new XMLHttpRequest();
        return n.open("GET", e2, false), n.send(), n.responseText;
      } finally {
        e2 && URL.revokeObjectURL(e2);
      }
    }
    var O = !x && typeof Blob == "function" && typeof URL == "function" && typeof URL.createObjectURL == "function", S = ["utf-8", "utf8", "unicode-1-1-utf-8"], T = h;
    x ? T = B : O && (T = function(r) {
      try {
        return U(r);
      } catch (e2) {
        return h(r);
      }
    });
    var y = "construct 'TextDecoder'", E = "".concat(u, " ").concat(y, ": the ");
    function g(r, e2) {
      p(e2 && e2.fatal, y, "fatal"), r = r || "utf-8";
      var f;
      if (x ? f = Buffer.isEncoding(r) : f = S.indexOf(r.toLowerCase()) !== -1, !f) throw new RangeError("".concat(E, " encoding label provided ('").concat(r, "') is invalid."));
      this.encoding = r, this.fatal = false, this.ignoreBOM = false;
    }
    g.prototype.decode = function(r, e2) {
      p(e2 && e2.stream, "decode", "stream");
      var f;
      return r instanceof Uint8Array ? f = r : r.buffer instanceof ArrayBuffer ? f = new Uint8Array(r.buffer) : f = new Uint8Array(r), T(f, this.encoding);
    };
    scope.TextEncoder = scope.TextEncoder || v;
    scope.TextDecoder = scope.TextDecoder || g;
  })(typeof window !== "undefined" ? window : typeof globalThis !== "undefined" ? globalThis : text_min);
  return text_min;
}
var browser;
var hasRequiredBrowser;
function requireBrowser() {
  if (hasRequiredBrowser) return browser;
  hasRequiredBrowser = 1;
  requireText_min();
  browser = {
    encode: (string) => new TextEncoder().encode(string),
    decode: (buffer2) => new TextDecoder().decode(buffer2)
  };
  return browser;
}
var justDebounceIt;
var hasRequiredJustDebounceIt;
function requireJustDebounceIt() {
  if (hasRequiredJustDebounceIt) return justDebounceIt;
  hasRequiredJustDebounceIt = 1;
  justDebounceIt = debounce;
  function debounce(fn, wait, callFirst) {
    var timeout;
    return function() {
      if (!wait) {
        return fn.apply(this, arguments);
      }
      var context = this;
      var args = arguments;
      var callNow = callFirst && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(function() {
        timeout = null;
        if (!callNow) {
          return fn.apply(context, args);
        }
      }, wait);
      if (callNow) {
        return fn.apply(this, arguments);
      }
    };
  }
  return justDebounceIt;
}
var path;
var hasRequiredPath;
function requirePath() {
  if (hasRequiredPath) return path;
  hasRequiredPath = 1;
  function normalizePath(path2) {
    if (path2.length === 0) {
      return ".";
    }
    let parts = splitPath(path2);
    parts = parts.reduce(reducer, []);
    return joinPath(...parts);
  }
  function resolvePath(...paths) {
    let result = "";
    for (let path2 of paths) {
      if (path2.startsWith("/")) {
        result = path2;
      } else {
        result = normalizePath(joinPath(result, path2));
      }
    }
    return result;
  }
  function joinPath(...parts) {
    if (parts.length === 0) return "";
    let path2 = parts.join("/");
    path2 = path2.replace(/\/{2,}/g, "/");
    return path2;
  }
  function splitPath(path2) {
    if (path2.length === 0) return [];
    if (path2 === "/") return ["/"];
    let parts = path2.split("/");
    if (parts[parts.length - 1] === "") {
      parts.pop();
    }
    if (path2[0] === "/") {
      parts[0] = "/";
    } else {
      if (parts[0] !== ".") {
        parts.unshift(".");
      }
    }
    return parts;
  }
  function dirname(path2) {
    const last = path2.lastIndexOf("/");
    if (last === -1) throw new Error(`Cannot get dirname of "${path2}"`);
    if (last === 0) return "/";
    return path2.slice(0, last);
  }
  function basename(path2) {
    if (path2 === "/") throw new Error(`Cannot get basename of "${path2}"`);
    const last = path2.lastIndexOf("/");
    if (last === -1) return path2;
    return path2.slice(last + 1);
  }
  function reducer(ancestors, current) {
    if (ancestors.length === 0) {
      ancestors.push(current);
      return ancestors;
    }
    if (current === ".") return ancestors;
    if (current === "..") {
      if (ancestors.length === 1) {
        if (ancestors[0] === "/") {
          throw new Error("Unable to normalize path - traverses above root directory");
        }
        if (ancestors[0] === ".") {
          ancestors.push(current);
          return ancestors;
        }
      }
      if (ancestors[ancestors.length - 1] === "..") {
        ancestors.push("..");
        return ancestors;
      } else {
        ancestors.pop();
        return ancestors;
      }
    }
    ancestors.push(current);
    return ancestors;
  }
  path = {
    join: joinPath,
    normalize: normalizePath,
    split: splitPath,
    basename,
    dirname,
    resolve: resolvePath
  };
  return path;
}
var errors;
var hasRequiredErrors;
function requireErrors() {
  if (hasRequiredErrors) return errors;
  hasRequiredErrors = 1;
  function Err(name) {
    return class extends Error {
      constructor(...args) {
        super(...args);
        this.code = name;
        if (this.message) {
          this.message = name + ": " + this.message;
        } else {
          this.message = name;
        }
      }
    };
  }
  const EEXIST = Err("EEXIST");
  const ENOENT = Err("ENOENT");
  const ENOTDIR = Err("ENOTDIR");
  const ENOTEMPTY = Err("ENOTEMPTY");
  const ETIMEDOUT = Err("ETIMEDOUT");
  errors = { EEXIST, ENOENT, ENOTDIR, ENOTEMPTY, ETIMEDOUT };
  return errors;
}
var CacheFS_1;
var hasRequiredCacheFS;
function requireCacheFS() {
  if (hasRequiredCacheFS) return CacheFS_1;
  hasRequiredCacheFS = 1;
  const path2 = requirePath();
  const { EEXIST, ENOENT, ENOTDIR, ENOTEMPTY } = requireErrors();
  const STAT = 0;
  CacheFS_1 = class CacheFS {
    constructor() {
    }
    _makeRoot(root = /* @__PURE__ */ new Map()) {
      root.set(STAT, { mode: 511, type: "dir", size: 0, ino: 0, mtimeMs: Date.now() });
      return root;
    }
    activate(superblock = null) {
      if (superblock === null) {
        this._root = /* @__PURE__ */ new Map([["/", this._makeRoot()]]);
      } else if (typeof superblock === "string") {
        this._root = /* @__PURE__ */ new Map([["/", this._makeRoot(this.parse(superblock))]]);
      } else {
        this._root = superblock;
      }
    }
    get activated() {
      return !!this._root;
    }
    deactivate() {
      this._root = void 0;
    }
    size() {
      return this._countInodes(this._root.get("/")) - 1;
    }
    _countInodes(map) {
      let count = 1;
      for (let [key, val] of map) {
        if (key === STAT) continue;
        count += this._countInodes(val);
      }
      return count;
    }
    autoinc() {
      let val = this._maxInode(this._root.get("/")) + 1;
      return val;
    }
    _maxInode(map) {
      let max = map.get(STAT).ino;
      for (let [key, val] of map) {
        if (key === STAT) continue;
        max = Math.max(max, this._maxInode(val));
      }
      return max;
    }
    print(root = this._root.get("/")) {
      let str = "";
      const printTree = (root2, indent) => {
        for (let [file, node] of root2) {
          if (file === 0) continue;
          let stat = node.get(STAT);
          let mode = stat.mode.toString(8);
          str += `${"	".repeat(indent)}${file}	${mode}`;
          if (stat.type === "file") {
            str += `	${stat.size}	${stat.mtimeMs}
`;
          } else {
            str += `
`;
            printTree(node, indent + 1);
          }
        }
      };
      printTree(root, 0);
      return str;
    }
    parse(print) {
      let autoinc = 0;
      function mk(stat) {
        const ino = ++autoinc;
        const type = stat.length === 1 ? "dir" : "file";
        let [mode, size, mtimeMs] = stat;
        mode = parseInt(mode, 8);
        size = size ? parseInt(size) : 0;
        mtimeMs = mtimeMs ? parseInt(mtimeMs) : Date.now();
        return /* @__PURE__ */ new Map([[STAT, { mode, type, size, mtimeMs, ino }]]);
      }
      let lines = print.trim().split("\n");
      let _root = this._makeRoot();
      let stack = [
        { indent: -1, node: _root },
        { indent: 0, node: null }
      ];
      for (let line of lines) {
        let prefix = line.match(/^\t*/)[0];
        let indent = prefix.length;
        line = line.slice(indent);
        let [filename, ...stat] = line.split("	");
        let node = mk(stat);
        if (indent <= stack[stack.length - 1].indent) {
          while (indent <= stack[stack.length - 1].indent) {
            stack.pop();
          }
        }
        stack.push({ indent, node });
        let cd = stack[stack.length - 2].node;
        cd.set(filename, node);
      }
      return _root;
    }
    _lookup(filepath, follow = true) {
      let dir = this._root;
      let partialPath = "/";
      let parts = path2.split(filepath);
      for (let i = 0; i < parts.length; ++i) {
        let part = parts[i];
        dir = dir.get(part);
        if (!dir) throw new ENOENT(filepath);
        if (follow || i < parts.length - 1) {
          const stat = dir.get(STAT);
          if (stat.type === "symlink") {
            let target = path2.resolve(partialPath, stat.target);
            dir = this._lookup(target);
          }
          if (!partialPath) {
            partialPath = part;
          } else {
            partialPath = path2.join(partialPath, part);
          }
        }
      }
      return dir;
    }
    mkdir(filepath, { mode }) {
      if (filepath === "/") throw new EEXIST();
      let dir = this._lookup(path2.dirname(filepath));
      let basename = path2.basename(filepath);
      if (dir.has(basename)) {
        throw new EEXIST();
      }
      let entry = /* @__PURE__ */ new Map();
      let stat = {
        mode,
        type: "dir",
        size: 0,
        mtimeMs: Date.now(),
        ino: this.autoinc()
      };
      entry.set(STAT, stat);
      dir.set(basename, entry);
    }
    rmdir(filepath) {
      let dir = this._lookup(filepath);
      if (dir.get(STAT).type !== "dir") throw new ENOTDIR();
      if (dir.size > 1) throw new ENOTEMPTY();
      let parent = this._lookup(path2.dirname(filepath));
      let basename = path2.basename(filepath);
      parent.delete(basename);
    }
    readdir(filepath) {
      let dir = this._lookup(filepath);
      if (dir.get(STAT).type !== "dir") throw new ENOTDIR();
      return [...dir.keys()].filter((key) => typeof key === "string");
    }
    writeStat(filepath, size, { mode }) {
      let ino;
      try {
        let oldStat = this.stat(filepath);
        if (mode == null) {
          mode = oldStat.mode;
        }
        ino = oldStat.ino;
      } catch (err) {
      }
      if (mode == null) {
        mode = 438;
      }
      if (ino == null) {
        ino = this.autoinc();
      }
      let dir = this._lookup(path2.dirname(filepath));
      let basename = path2.basename(filepath);
      let stat = {
        mode,
        type: "file",
        size,
        mtimeMs: Date.now(),
        ino
      };
      let entry = /* @__PURE__ */ new Map();
      entry.set(STAT, stat);
      dir.set(basename, entry);
      return stat;
    }
    unlink(filepath) {
      let parent = this._lookup(path2.dirname(filepath));
      let basename = path2.basename(filepath);
      parent.delete(basename);
    }
    rename(oldFilepath, newFilepath) {
      let basename = path2.basename(newFilepath);
      let entry = this._lookup(oldFilepath);
      let destDir = this._lookup(path2.dirname(newFilepath));
      destDir.set(basename, entry);
      this.unlink(oldFilepath);
    }
    stat(filepath) {
      return this._lookup(filepath).get(STAT);
    }
    lstat(filepath) {
      return this._lookup(filepath, false).get(STAT);
    }
    readlink(filepath) {
      return this._lookup(filepath, false).get(STAT).target;
    }
    symlink(target, filepath) {
      let ino, mode;
      try {
        let oldStat = this.stat(filepath);
        if (mode === null) {
          mode = oldStat.mode;
        }
        ino = oldStat.ino;
      } catch (err) {
      }
      if (mode == null) {
        mode = 40960;
      }
      if (ino == null) {
        ino = this.autoinc();
      }
      let dir = this._lookup(path2.dirname(filepath));
      let basename = path2.basename(filepath);
      let stat = {
        mode,
        type: "symlink",
        target,
        size: 0,
        mtimeMs: Date.now(),
        ino
      };
      let entry = /* @__PURE__ */ new Map();
      entry.set(STAT, stat);
      dir.set(basename, entry);
      return stat;
    }
    _du(dir) {
      let size = 0;
      for (const [name, entry] of dir.entries()) {
        if (name === STAT) {
          size += entry.size;
        } else {
          size += this._du(entry);
        }
      }
      return size;
    }
    du(filepath) {
      let dir = this._lookup(filepath);
      return this._du(dir);
    }
  };
  return CacheFS_1;
}
class Store {
  constructor(dbName = "keyval-store", storeName = "keyval") {
    this.storeName = storeName;
    this._dbName = dbName;
    this._storeName = storeName;
    this._init();
  }
  _init() {
    if (this._dbp) {
      return;
    }
    this._dbp = new Promise((resolve, reject) => {
      const openreq = indexedDB.open(this._dbName);
      openreq.onerror = () => reject(openreq.error);
      openreq.onsuccess = () => resolve(openreq.result);
      openreq.onupgradeneeded = () => {
        openreq.result.createObjectStore(this._storeName);
      };
    });
  }
  _withIDBStore(type, callback) {
    this._init();
    return this._dbp.then((db) => new Promise((resolve, reject) => {
      const transaction = db.transaction(this.storeName, type);
      transaction.oncomplete = () => resolve();
      transaction.onabort = transaction.onerror = () => reject(transaction.error);
      callback(transaction.objectStore(this.storeName));
    }));
  }
  _close() {
    this._init();
    return this._dbp.then((db) => {
      db.close();
      this._dbp = void 0;
    });
  }
}
let store;
function getDefaultStore() {
  if (!store)
    store = new Store();
  return store;
}
function get(key, store2 = getDefaultStore()) {
  let req;
  return store2._withIDBStore("readwrite", (store3) => {
    req = store3.get(key);
  }).then(() => req.result);
}
function set(key, value, store2 = getDefaultStore()) {
  return store2._withIDBStore("readwrite", (store3) => {
    store3.put(value, key);
  });
}
function update(key, updater, store2 = getDefaultStore()) {
  return store2._withIDBStore("readwrite", (store3) => {
    const req = store3.get(key);
    req.onsuccess = () => {
      store3.put(updater(req.result), key);
    };
  });
}
function del(key, store2 = getDefaultStore()) {
  return store2._withIDBStore("readwrite", (store3) => {
    store3.delete(key);
  });
}
function clear(store2 = getDefaultStore()) {
  return store2._withIDBStore("readwrite", (store3) => {
    store3.clear();
  });
}
function keys(store2 = getDefaultStore()) {
  const keys2 = [];
  return store2._withIDBStore("readwrite", (store3) => {
    (store3.openKeyCursor || store3.openCursor).call(store3).onsuccess = function() {
      if (!this.result)
        return;
      keys2.push(this.result.key);
      this.result.continue();
    };
  }).then(() => keys2);
}
function close(store2 = getDefaultStore()) {
  return store2._close();
}
const idbKeyval = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Store,
  clear,
  close,
  del,
  get,
  keys,
  set,
  update
}, Symbol.toStringTag, { value: "Module" }));
const require$$0 = /* @__PURE__ */ getAugmentedNamespace(idbKeyval);
var IdbBackend_1;
var hasRequiredIdbBackend;
function requireIdbBackend() {
  if (hasRequiredIdbBackend) return IdbBackend_1;
  hasRequiredIdbBackend = 1;
  const idb = require$$0;
  IdbBackend_1 = class IdbBackend {
    constructor(dbname, storename) {
      this._database = dbname;
      this._storename = storename;
      this._store = new idb.Store(this._database, this._storename);
    }
    saveSuperblock(superblock) {
      return idb.set("!root", superblock, this._store);
    }
    loadSuperblock() {
      return idb.get("!root", this._store);
    }
    readFile(inode) {
      return idb.get(inode, this._store);
    }
    writeFile(inode, data) {
      return idb.set(inode, data, this._store);
    }
    unlink(inode) {
      return idb.del(inode, this._store);
    }
    wipe() {
      return idb.clear(this._store);
    }
    close() {
      return idb.close(this._store);
    }
  };
  return IdbBackend_1;
}
var HttpBackend_1;
var hasRequiredHttpBackend;
function requireHttpBackend() {
  if (hasRequiredHttpBackend) return HttpBackend_1;
  hasRequiredHttpBackend = 1;
  HttpBackend_1 = class HttpBackend {
    constructor(url) {
      this._url = url;
    }
    loadSuperblock() {
      return fetch(this._url + "/.superblock.txt").then((res) => res.ok ? res.text() : null);
    }
    async readFile(filepath) {
      const res = await fetch(this._url + filepath);
      if (res.status === 200) {
        return res.arrayBuffer();
      } else {
        throw new Error("ENOENT");
      }
    }
    async sizeFile(filepath) {
      const res = await fetch(this._url + filepath, { method: "HEAD" });
      if (res.status === 200) {
        return res.headers.get("content-length");
      } else {
        throw new Error("ENOENT");
      }
    }
  };
  return HttpBackend_1;
}
var Mutex_1;
var hasRequiredMutex;
function requireMutex() {
  if (hasRequiredMutex) return Mutex_1;
  hasRequiredMutex = 1;
  const idb = require$$0;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  Mutex_1 = class Mutex {
    constructor(dbname, storename) {
      this._id = Math.random();
      this._database = dbname;
      this._storename = storename;
      this._store = new idb.Store(this._database, this._storename);
      this._lock = null;
    }
    async has({ margin = 2e3 } = {}) {
      if (this._lock && this._lock.holder === this._id) {
        const now = Date.now();
        if (this._lock.expires > now + margin) {
          return true;
        } else {
          return await this.renew();
        }
      } else {
        return false;
      }
    }
    // Returns true if successful
    async renew({ ttl = 5e3 } = {}) {
      let success;
      await idb.update("lock", (current) => {
        const now = Date.now();
        const expires = now + ttl;
        success = current && current.holder === this._id;
        this._lock = success ? { holder: this._id, expires } : current;
        return this._lock;
      }, this._store);
      return success;
    }
    // Returns true if successful
    async acquire({ ttl = 5e3 } = {}) {
      let success;
      let expired;
      let doubleLock;
      await idb.update("lock", (current) => {
        const now = Date.now();
        const expires = now + ttl;
        expired = current && current.expires < now;
        success = current === void 0 || expired;
        doubleLock = current && current.holder === this._id;
        this._lock = success ? { holder: this._id, expires } : current;
        return this._lock;
      }, this._store);
      if (doubleLock) {
        throw new Error("Mutex double-locked");
      }
      return success;
    }
    // check at 10Hz, give up after 10 minutes
    async wait({ interval = 100, limit = 6e3, ttl } = {}) {
      while (limit--) {
        if (await this.acquire({ ttl })) return true;
        await sleep(interval);
      }
      throw new Error("Mutex timeout");
    }
    // Returns true if successful
    async release({ force = false } = {}) {
      let success;
      let doubleFree;
      let someoneElseHasIt;
      await idb.update("lock", (current) => {
        success = force || current && current.holder === this._id;
        doubleFree = current === void 0;
        someoneElseHasIt = current && current.holder !== this._id;
        this._lock = success ? void 0 : current;
        return this._lock;
      }, this._store);
      await idb.close(this._store);
      if (!success && !force) {
        if (doubleFree) throw new Error("Mutex double-freed");
        if (someoneElseHasIt) throw new Error("Mutex lost ownership");
      }
      return success;
    }
  };
  return Mutex_1;
}
var Mutex2;
var hasRequiredMutex2;
function requireMutex2() {
  if (hasRequiredMutex2) return Mutex2;
  hasRequiredMutex2 = 1;
  Mutex2 = class Mutex {
    constructor(name) {
      this._id = Math.random();
      this._database = name;
      this._has = false;
      this._release = null;
    }
    async has() {
      return this._has;
    }
    // Returns true if successful
    async acquire() {
      return new Promise((resolve) => {
        navigator.locks.request(this._database + "_lock", { ifAvailable: true }, (lock) => {
          this._has = !!lock;
          resolve(!!lock);
          return new Promise((resolve2) => {
            this._release = resolve2;
          });
        });
      });
    }
    // Returns true if successful, gives up after 10 minutes
    async wait({ timeout = 6e5 } = {}) {
      return new Promise((resolve, reject) => {
        const controller = new AbortController();
        setTimeout(() => {
          controller.abort();
          reject(new Error("Mutex timeout"));
        }, timeout);
        navigator.locks.request(this._database + "_lock", { signal: controller.signal }, (lock) => {
          this._has = !!lock;
          resolve(!!lock);
          return new Promise((resolve2) => {
            this._release = resolve2;
          });
        });
      });
    }
    // Returns true if successful
    async release({ force = false } = {}) {
      this._has = false;
      if (this._release) {
        this._release();
      } else if (force) {
        navigator.locks.request(this._database + "_lock", { steal: true }, (lock) => true);
      }
    }
  };
  return Mutex2;
}
var DefaultBackend_1;
var hasRequiredDefaultBackend;
function requireDefaultBackend() {
  if (hasRequiredDefaultBackend) return DefaultBackend_1;
  hasRequiredDefaultBackend = 1;
  const { encode, decode } = requireBrowser();
  const debounce = requireJustDebounceIt();
  const CacheFS = requireCacheFS();
  const { ENOENT, ENOTEMPTY, ETIMEDOUT } = requireErrors();
  const IdbBackend = requireIdbBackend();
  const HttpBackend = requireHttpBackend();
  const Mutex = requireMutex();
  const Mutex22 = requireMutex2();
  const path2 = requirePath();
  DefaultBackend_1 = class DefaultBackend {
    constructor() {
      this.saveSuperblock = debounce(() => {
        this.flush();
      }, 500);
    }
    async init(name, {
      wipe,
      url,
      urlauto,
      fileDbName = name,
      db = null,
      fileStoreName = name + "_files",
      lockDbName = name + "_lock",
      lockStoreName = name + "_lock"
    } = {}) {
      this._name = name;
      this._idb = db || new IdbBackend(fileDbName, fileStoreName);
      this._mutex = navigator.locks ? new Mutex22(name) : new Mutex(lockDbName, lockStoreName);
      this._cache = new CacheFS(name);
      this._opts = { wipe, url };
      this._needsWipe = !!wipe;
      if (url) {
        this._http = new HttpBackend(url);
        this._urlauto = !!urlauto;
      }
    }
    async activate() {
      if (this._cache.activated) return;
      if (this._needsWipe) {
        this._needsWipe = false;
        await this._idb.wipe();
        await this._mutex.release({ force: true });
      }
      if (!await this._mutex.has()) await this._mutex.wait();
      const root = await this._idb.loadSuperblock();
      if (root) {
        this._cache.activate(root);
      } else if (this._http) {
        const text = await this._http.loadSuperblock();
        this._cache.activate(text);
        await this._saveSuperblock();
      } else {
        this._cache.activate();
      }
      if (await this._mutex.has()) {
        return;
      } else {
        throw new ETIMEDOUT();
      }
    }
    async deactivate() {
      if (await this._mutex.has()) {
        await this._saveSuperblock();
      }
      this._cache.deactivate();
      try {
        await this._mutex.release();
      } catch (e2) {
        console.log(e2);
      }
      await this._idb.close();
    }
    async _saveSuperblock() {
      if (this._cache.activated) {
        this._lastSavedAt = Date.now();
        await this._idb.saveSuperblock(this._cache._root);
      }
    }
    _writeStat(filepath, size, opts) {
      let dirparts = path2.split(path2.dirname(filepath));
      let dir = dirparts.shift();
      for (let dirpart of dirparts) {
        dir = path2.join(dir, dirpart);
        try {
          this._cache.mkdir(dir, { mode: 511 });
        } catch (e2) {
        }
      }
      return this._cache.writeStat(filepath, size, opts);
    }
    async readFile(filepath, opts) {
      const { encoding } = opts;
      if (encoding && encoding !== "utf8") throw new Error('Only "utf8" encoding is supported in readFile');
      let data = null, stat = null;
      try {
        stat = this._cache.stat(filepath);
        data = await this._idb.readFile(stat.ino);
      } catch (e2) {
        if (!this._urlauto) throw e2;
      }
      if (!data && this._http) {
        let lstat = this._cache.lstat(filepath);
        while (lstat.type === "symlink") {
          filepath = path2.resolve(path2.dirname(filepath), lstat.target);
          lstat = this._cache.lstat(filepath);
        }
        data = await this._http.readFile(filepath);
      }
      if (data) {
        if (!stat || stat.size != data.byteLength) {
          stat = await this._writeStat(filepath, data.byteLength, { mode: stat ? stat.mode : 438 });
          this.saveSuperblock();
        }
        if (encoding === "utf8") {
          data = decode(data);
        } else {
          data.toString = () => decode(data);
        }
      }
      if (!stat) throw new ENOENT(filepath);
      return data;
    }
    async writeFile(filepath, data, opts) {
      const { mode, encoding = "utf8" } = opts;
      if (typeof data === "string") {
        if (encoding !== "utf8") {
          throw new Error('Only "utf8" encoding is supported in writeFile');
        }
        data = encode(data);
      }
      const stat = await this._cache.writeStat(filepath, data.byteLength, { mode });
      await this._idb.writeFile(stat.ino, data);
    }
    async unlink(filepath, opts) {
      const stat = this._cache.lstat(filepath);
      this._cache.unlink(filepath);
      if (stat.type !== "symlink") {
        await this._idb.unlink(stat.ino);
      }
    }
    readdir(filepath, opts) {
      return this._cache.readdir(filepath);
    }
    mkdir(filepath, opts) {
      const { mode = 511 } = opts;
      this._cache.mkdir(filepath, { mode });
    }
    rmdir(filepath, opts) {
      if (filepath === "/") {
        throw new ENOTEMPTY();
      }
      this._cache.rmdir(filepath);
    }
    rename(oldFilepath, newFilepath) {
      this._cache.rename(oldFilepath, newFilepath);
    }
    stat(filepath, opts) {
      return this._cache.stat(filepath);
    }
    lstat(filepath, opts) {
      return this._cache.lstat(filepath);
    }
    readlink(filepath, opts) {
      return this._cache.readlink(filepath);
    }
    symlink(target, filepath) {
      this._cache.symlink(target, filepath);
    }
    async backFile(filepath, opts) {
      let size = await this._http.sizeFile(filepath);
      await this._writeStat(filepath, size, opts);
    }
    du(filepath) {
      return this._cache.du(filepath);
    }
    flush() {
      return this._saveSuperblock();
    }
  };
  return DefaultBackend_1;
}
var Stat_1;
var hasRequiredStat;
function requireStat() {
  if (hasRequiredStat) return Stat_1;
  hasRequiredStat = 1;
  Stat_1 = class Stat {
    constructor(stats) {
      this.type = stats.type;
      this.mode = stats.mode;
      this.size = stats.size;
      this.ino = stats.ino;
      this.mtimeMs = stats.mtimeMs;
      this.ctimeMs = stats.ctimeMs || stats.mtimeMs;
      this.uid = 1;
      this.gid = 1;
      this.dev = 1;
    }
    isFile() {
      return this.type === "file";
    }
    isDirectory() {
      return this.type === "dir";
    }
    isSymbolicLink() {
      return this.type === "symlink";
    }
  };
  return Stat_1;
}
var PromisifiedFS_1;
var hasRequiredPromisifiedFS;
function requirePromisifiedFS() {
  if (hasRequiredPromisifiedFS) return PromisifiedFS_1;
  hasRequiredPromisifiedFS = 1;
  const DefaultBackend = requireDefaultBackend();
  const Stat = requireStat();
  const path2 = requirePath();
  function cleanParamsFilepathOpts(filepath, opts, ...rest) {
    filepath = path2.normalize(filepath);
    if (typeof opts === "undefined" || typeof opts === "function") {
      opts = {};
    }
    if (typeof opts === "string") {
      opts = {
        encoding: opts
      };
    }
    return [filepath, opts, ...rest];
  }
  function cleanParamsFilepathDataOpts(filepath, data, opts, ...rest) {
    filepath = path2.normalize(filepath);
    if (typeof opts === "undefined" || typeof opts === "function") {
      opts = {};
    }
    if (typeof opts === "string") {
      opts = {
        encoding: opts
      };
    }
    return [filepath, data, opts, ...rest];
  }
  function cleanParamsFilepathFilepath(oldFilepath, newFilepath, ...rest) {
    return [path2.normalize(oldFilepath), path2.normalize(newFilepath), ...rest];
  }
  PromisifiedFS_1 = class PromisifiedFS {
    constructor(name, options = {}) {
      this.init = this.init.bind(this);
      this.readFile = this._wrap(this.readFile, cleanParamsFilepathOpts, false);
      this.writeFile = this._wrap(this.writeFile, cleanParamsFilepathDataOpts, true);
      this.unlink = this._wrap(this.unlink, cleanParamsFilepathOpts, true);
      this.readdir = this._wrap(this.readdir, cleanParamsFilepathOpts, false);
      this.mkdir = this._wrap(this.mkdir, cleanParamsFilepathOpts, true);
      this.rmdir = this._wrap(this.rmdir, cleanParamsFilepathOpts, true);
      this.rename = this._wrap(this.rename, cleanParamsFilepathFilepath, true);
      this.stat = this._wrap(this.stat, cleanParamsFilepathOpts, false);
      this.lstat = this._wrap(this.lstat, cleanParamsFilepathOpts, false);
      this.readlink = this._wrap(this.readlink, cleanParamsFilepathOpts, false);
      this.symlink = this._wrap(this.symlink, cleanParamsFilepathFilepath, true);
      this.backFile = this._wrap(this.backFile, cleanParamsFilepathOpts, true);
      this.du = this._wrap(this.du, cleanParamsFilepathOpts, false);
      this._deactivationPromise = null;
      this._deactivationTimeout = null;
      this._activationPromise = null;
      this._operations = /* @__PURE__ */ new Set();
      if (name) {
        this.init(name, options);
      }
    }
    async init(...args) {
      if (this._initPromiseResolve) await this._initPromise;
      this._initPromise = this._init(...args);
      return this._initPromise;
    }
    async _init(name, options = {}) {
      await this._gracefulShutdown();
      if (this._activationPromise) await this._deactivate();
      if (this._backend && this._backend.destroy) {
        await this._backend.destroy();
      }
      this._backend = options.backend || new DefaultBackend();
      if (this._backend.init) {
        await this._backend.init(name, options);
      }
      if (this._initPromiseResolve) {
        this._initPromiseResolve();
        this._initPromiseResolve = null;
      }
      if (!options.defer) {
        this.stat("/");
      }
    }
    async _gracefulShutdown() {
      if (this._operations.size > 0) {
        this._isShuttingDown = true;
        await new Promise((resolve) => this._gracefulShutdownResolve = resolve);
        this._isShuttingDown = false;
        this._gracefulShutdownResolve = null;
      }
    }
    _wrap(fn, paramCleaner, mutating) {
      return async (...args) => {
        args = paramCleaner(...args);
        let op = {
          name: fn.name,
          args
        };
        this._operations.add(op);
        try {
          await this._activate();
          return await fn.apply(this, args);
        } finally {
          this._operations.delete(op);
          if (mutating) this._backend.saveSuperblock();
          if (this._operations.size === 0) {
            if (!this._deactivationTimeout) clearTimeout(this._deactivationTimeout);
            this._deactivationTimeout = setTimeout(this._deactivate.bind(this), 500);
          }
        }
      };
    }
    async _activate() {
      if (!this._initPromise) console.warn(new Error(`Attempted to use LightningFS ${this._name} before it was initialized.`));
      await this._initPromise;
      if (this._deactivationTimeout) {
        clearTimeout(this._deactivationTimeout);
        this._deactivationTimeout = null;
      }
      if (this._deactivationPromise) await this._deactivationPromise;
      this._deactivationPromise = null;
      if (!this._activationPromise) {
        this._activationPromise = this._backend.activate ? this._backend.activate() : Promise.resolve();
      }
      await this._activationPromise;
    }
    async _deactivate() {
      if (this._activationPromise) await this._activationPromise;
      if (!this._deactivationPromise) {
        this._deactivationPromise = this._backend.deactivate ? this._backend.deactivate() : Promise.resolve();
      }
      this._activationPromise = null;
      if (this._gracefulShutdownResolve) this._gracefulShutdownResolve();
      return this._deactivationPromise;
    }
    async readFile(filepath, opts) {
      return this._backend.readFile(filepath, opts);
    }
    async writeFile(filepath, data, opts) {
      await this._backend.writeFile(filepath, data, opts);
      return null;
    }
    async unlink(filepath, opts) {
      await this._backend.unlink(filepath, opts);
      return null;
    }
    async readdir(filepath, opts) {
      return this._backend.readdir(filepath, opts);
    }
    async mkdir(filepath, opts) {
      await this._backend.mkdir(filepath, opts);
      return null;
    }
    async rmdir(filepath, opts) {
      await this._backend.rmdir(filepath, opts);
      return null;
    }
    async rename(oldFilepath, newFilepath) {
      await this._backend.rename(oldFilepath, newFilepath);
      return null;
    }
    async stat(filepath, opts) {
      const data = await this._backend.stat(filepath, opts);
      return new Stat(data);
    }
    async lstat(filepath, opts) {
      const data = await this._backend.lstat(filepath, opts);
      return new Stat(data);
    }
    async readlink(filepath, opts) {
      return this._backend.readlink(filepath, opts);
    }
    async symlink(target, filepath) {
      await this._backend.symlink(target, filepath);
      return null;
    }
    async backFile(filepath, opts) {
      await this._backend.backFile(filepath, opts);
      return null;
    }
    async du(filepath) {
      return this._backend.du(filepath);
    }
    async flush() {
      return this._backend.flush();
    }
  };
  return PromisifiedFS_1;
}
var src;
var hasRequiredSrc;
function requireSrc() {
  if (hasRequiredSrc) return src;
  hasRequiredSrc = 1;
  const once = requireJustOnce();
  const PromisifiedFS = requirePromisifiedFS();
  function wrapCallback(opts, cb) {
    if (typeof opts === "function") {
      cb = opts;
    }
    cb = once(cb);
    const resolve = (...args) => cb(null, ...args);
    return [resolve, cb];
  }
  src = class FS {
    constructor(...args) {
      this.promises = new PromisifiedFS(...args);
      this.init = this.init.bind(this);
      this.readFile = this.readFile.bind(this);
      this.writeFile = this.writeFile.bind(this);
      this.unlink = this.unlink.bind(this);
      this.readdir = this.readdir.bind(this);
      this.mkdir = this.mkdir.bind(this);
      this.rmdir = this.rmdir.bind(this);
      this.rename = this.rename.bind(this);
      this.stat = this.stat.bind(this);
      this.lstat = this.lstat.bind(this);
      this.readlink = this.readlink.bind(this);
      this.symlink = this.symlink.bind(this);
      this.backFile = this.backFile.bind(this);
      this.du = this.du.bind(this);
      this.flush = this.flush.bind(this);
    }
    init(name, options) {
      return this.promises.init(name, options);
    }
    readFile(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.readFile(filepath, opts).then(resolve).catch(reject);
    }
    writeFile(filepath, data, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.writeFile(filepath, data, opts).then(resolve).catch(reject);
    }
    unlink(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.unlink(filepath, opts).then(resolve).catch(reject);
    }
    readdir(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.readdir(filepath, opts).then(resolve).catch(reject);
    }
    mkdir(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.mkdir(filepath, opts).then(resolve).catch(reject);
    }
    rmdir(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.rmdir(filepath, opts).then(resolve).catch(reject);
    }
    rename(oldFilepath, newFilepath, cb) {
      const [resolve, reject] = wrapCallback(cb);
      this.promises.rename(oldFilepath, newFilepath).then(resolve).catch(reject);
    }
    stat(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.stat(filepath).then(resolve).catch(reject);
    }
    lstat(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.lstat(filepath).then(resolve).catch(reject);
    }
    readlink(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.readlink(filepath).then(resolve).catch(reject);
    }
    symlink(target, filepath, cb) {
      const [resolve, reject] = wrapCallback(cb);
      this.promises.symlink(target, filepath).then(resolve).catch(reject);
    }
    backFile(filepath, opts, cb) {
      const [resolve, reject] = wrapCallback(opts, cb);
      this.promises.backFile(filepath, opts).then(resolve).catch(reject);
    }
    du(filepath, cb) {
      const [resolve, reject] = wrapCallback(cb);
      this.promises.du(filepath).then(resolve).catch(reject);
    }
    flush(cb) {
      const [resolve, reject] = wrapCallback(cb);
      this.promises.flush().then(resolve).catch(reject);
    }
  };
  return src;
}
var srcExports = requireSrc();
const LightningFS = /* @__PURE__ */ getDefaultExportFromCjs(srcExports);
const config$7 = await getConfig();
const logger$6 = new Logger(config$7.logging.IDBFs);
function consoleDotLog$6(...parameters) {
  logger$6.consoleDotLog("[IDBFS] ", ...parameters);
}
function consoleDotError$5(...parameters) {
  logger$6.consoleDotError("[IDBFS] ", ...parameters);
}
class IDBFs {
  constructor(fsName, options = {}) {
    this.fs = new LightningFS(fsName, options);
    this.fileDescriptors = /* @__PURE__ */ new Map();
    this.fdCounter = 3;
    this.workerEntry = null;
    this.workerThread = null;
    this.fsName = fsName;
    this.versioningStrategy = options?.versioning?.strategy || config$7.versioning.strategy;
    this.doImmediateCommit = this.versioningStrategy === "immediate" ? true : false;
    (async () => {
      await this.initializeWorker();
    })();
    consoleDotLog$6("IDBFS initialized with LightningFS.");
  }
  async initializeWorker() {
    this.workerEntry = await workerPool.getWorker(this.fsName);
    this.workerThread = this.workerEntry.thread;
    await this.workerThread.execute("setFs", {
      fsName: this.fsName,
      fsType: "idb",
      gitDir: "/"
    });
    consoleDotLog$6(`Worker initialized for ${this.fsName}`);
  }
  async cleanup() {
    if (this.workerEntry) {
      await workerPool.releaseWorker(this.fsName);
      this.workerEntry = null;
      this.workerThread = null;
    }
  }
  async fs_fopen(filename, mode) {
    if (!this.workerThread) await this.initializeWorker();
    consoleDotLog$6(`Opening file: ${filename} with mode: ${mode}`);
    if (mode.includes("w") || mode.includes("a") || mode.includes("x")) {
      const parentDir = filename.split("/").slice(0, -1).join("/");
      if (parentDir) {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, open '${filename}'`);
        }
      }
    }
    const fd = this.fdCounter++;
    this.fileDescriptors.set(fd, { path: filename, pos: 0, mode });
    consoleDotLog$6(`File descriptor ${fd} created for file: ${filename}`);
    return fd;
  }
  async fs_fclose(fd) {
    consoleDotLog$6(`Closing file descriptor: ${fd}`);
    if (!this.fileDescriptors.has(fd)) {
      throw new Error(`EBADF: bad file descriptor, close '${fd}'`);
    }
    this.fileDescriptors.delete(fd);
    consoleDotLog$6(`File descriptor ${fd} closed successfully.`);
    return 0;
  }
  async fs_fread(fd, length) {
    consoleDotLog$6(`Reading ${length} bytes from file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, read '${fd}'`);
    }
    try {
      if (!this.workerThread) await this.initializeWorker();
      const data = await this.workerThread.execute("readFileDot", { filePath: file.path });
      if (data === null) {
        throw new Error(`ENOENT: no such file, read '${file.path}'`);
      }
      const chunk = data.slice(file.pos, file.pos + length);
      file.pos += chunk.length;
      consoleDotLog$6(`Read chunk: ${chunk}, new position: ${file.pos}`);
      return chunk;
    } catch (error) {
      consoleDotError$5(`Error reading file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_fwrite(fd, content) {
    consoleDotLog$6(`Writing content to file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, write '${fd}'`);
    }
    try {
      if (!this.workerThread) await this.initializeWorker();
      const parentDir = file.path.split("/").slice(0, -1).join("/");
      if (parentDir) {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, open '${file.path}'`);
        }
      }
      let currentData = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      let data = currentData;
      consoleDotLog$6(`Current data in file ${file.path}:`, data);
      if (data === null) data = "";
      data = data.slice(0, file.pos) + content + data.slice(file.pos + content.length);
      await this.workerThread.execute("writeFileDot", {
        filePath: file.path,
        fileContent: data,
        doCommit: this.doImmediateCommit
      });
      file.pos += content.length;
      consoleDotLog$6(`Content written to file ${file.path}, new position: ${file.pos}`);
      return content.length;
    } catch (error) {
      consoleDotError$5(`Error writing to file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_fseek(fd, offset, whence) {
    consoleDotLog$6(`Seeking in file descriptor: ${fd}, offset: ${offset}, whence: ${whence}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, seek '${fd}'`);
    }
    try {
      if (!this.workerThread) await this.initializeWorker();
      const data = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      if (whence === "SEEK_SET") file.pos = offset;
      else if (whence === "SEEK_CUR") file.pos += offset;
      else if (whence === "SEEK_END") file.pos = data.length + offset;
      file.pos = Math.max(0, Math.min(file.pos, data.length));
      consoleDotLog$6(`New position in file ${file.path}: ${file.pos}`);
      return 0;
    } catch (error) {
      consoleDotError$5(`Error seeking in file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_ftell(fd) {
    consoleDotLog$6(`Getting current position for file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, tell '${fd}'`);
    }
    consoleDotLog$6(`Current position in file ${file.path}: ${file.pos}`);
    return file.pos;
  }
  async fs_ftruncate(fd, length) {
    consoleDotLog$6(`Truncating file descriptor: ${fd} to length: ${length}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, truncate '${fd}'`);
    }
    try {
      if (!this.workerThread) await this.initializeWorker();
      let currentData = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      let data = currentData;
      consoleDotLog$6(`Current data in file ${file.path}:`, data);
      data = data.slice(0, length);
      await this.workerThread.execute("writeFileDot", {
        filePath: file.path,
        fileContent: data,
        doCommit: this.doImmediateCommit
      });
      consoleDotLog$6(`File ${file.path} truncated to length: ${length}`);
      return 0;
    } catch (error) {
      consoleDotError$5(`Error truncating file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_stat(path2) {
    consoleDotLog$6(`Getting stats for path: ${path2}`);
    try {
      const normalizedPath = path2.replace(/^\/+|\/+$/g, "");
      if (!this.workerThread) await this.initializeWorker();
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such file or directory, stat '${path2}'`);
      }
      const noteType = exists.isDirectory ? "dentry" : "inode";
      const noteData = await this.workerThread.execute("getPathNote", {
        path: path2
      });
      if (noteData.error || !noteData || !noteData?.paths?.[normalizedPath]) {
        consoleDotLog$6(`No note found for ${path2}, returning basic stats`);
      }
      const metadata = noteData?.paths?.[normalizedPath]?.metadata || noteData;
      const stats = {
        // Standard fs.Stats properties
        dev: 0,
        ino: metadata.inode || metadata.dentry_id || 0,
        mode: parseInt(metadata.mode, 8) || (exists.isDirectory ? 16877 : 33188),
        nlink: 1,
        uid: metadata.uid || 1e3,
        gid: metadata.gid || 1e3,
        rdev: 0,
        size: metadata.size || 0,
        blksize: metadata.block_size || 4096,
        blocks: Math.ceil((metadata.size || 0) / 4096),
        atimeMs: new Date(metadata.atime || metadata.updated_at).getTime(),
        mtimeMs: new Date(metadata.mtime || metadata.updated_at).getTime(),
        ctimeMs: new Date(metadata.ctime || metadata.created_at).getTime(),
        birthtimeMs: new Date(metadata.created_at).getTime(),
        // Extended properties from notes
        acl: metadata.acl || "root",
        owner: metadata.owner,
        fsType: metadata.fsType,
        fullPath: metadata.full_path || path2,
        // Boolean check methods
        isDirectory: () => exists.isDirectory,
        isFile: () => !exists.isDirectory,
        isBlockDevice: () => false,
        isCharacterDevice: () => false,
        isSymbolicLink: () => false,
        isFIFO: () => false,
        isSocket: () => false,
        // Timestamp getters
        atime: () => new Date(metadata.atime || metadata.updated_at),
        mtime: () => new Date(metadata.mtime || metadata.updated_at),
        ctime: () => new Date(metadata.ctime || metadata.created_at),
        birthtime: () => new Date(metadata.created_at),
        // Additional metadata
        getMetadata: () => metadata,
        getNoteType: () => noteType,
        getAllPaths: () => noteData.filepath_metadata ? Object.keys(noteData.filepath_metadata) : [path2]
      };
      consoleDotLog$6(`Retrieved detailed stats for ${path2}`, stats);
      return stats;
    } catch (error) {
      consoleDotError$5(`Error getting stats for path ${path2}:`, error);
      if (error.message.includes("ENOENT")) {
        throw error;
      }
    }
  }
  async fs_fstat(fd) {
    consoleDotLog$6(`Getting stats for file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, fstat '${fd}'`);
    }
    return this.fs_stat(file.path);
  }
  async fs_remove(path2) {
    if (!this.workerThread) await this.initializeWorker();
    consoleDotLog$6(`Removing file: ${path2}`);
    try {
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such file, unlink '${path2}'`);
      }
      if (exists.isDirectory) {
        throw new Error(`EISDIR: illegal operation on a directory, unlink '${path2}'`);
      }
      await this.workerThread.execute("removeFileDot", {
        filePath: path2,
        doCommit: this.doImmediateCommit
      });
      return 0;
    } catch (error) {
      consoleDotError$5(`Error removing file ${path2}:`, error);
      throw error;
    }
  }
  async fs_mkdir(path2) {
    if (!this.workerThread) await this.initializeWorker();
    consoleDotLog$6(`Creating directory: ${path2}`);
    try {
      const parentDir = path2.split("/").slice(0, -1).join("/");
      if (parentDir) {
        const dirExists = await this.workerThread.execute("isDirectoryDot", { path: parentDir });
        if (!dirExists.exists || !dirExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, mkdir '${path2}'`);
        }
      }
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (exists.exists) {
        throw new Error(`EEXIST: file or directory already exists, mkdir '${path2}'`);
      }
      await this.workerThread.execute("mkdirDot", {
        dirPath: path2,
        doCommit: this.doImmediateCommit
      });
      return 0;
    } catch (error) {
      consoleDotError$5(`Error creating directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_rmdir(path2) {
    if (!this.workerThread) await this.initializeWorker();
    consoleDotLog$6(`Removing directory: ${path2}`);
    try {
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such directory, rmdir '${path2}'`);
      }
      if (!exists.isDirectory) {
        throw new Error(`ENOTDIR: not a directory, rmdir '${path2}'`);
      }
      const dirContents = await this.fs_readdir(path2);
      if (dirContents.length > 0) {
        throw new Error(`ENOTEMPTY: directory not empty, rmdir '${path2}'`);
      }
      await this.workerThread.execute("removeDirDot", {
        dirPath: path2,
        doCommit: this.doImmediateCommit
      });
      return 0;
    } catch (error) {
      consoleDotError$5(`Error removing directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_rename(oldPath, newPath) {
    if (!this.workerThread) await this.initializeWorker();
    consoleDotLog$6(`Renaming ${oldPath} to ${newPath}`);
    try {
      const oldExists = await this.workerThread.execute("isDirectoryDot", { path: oldPath });
      if (!oldExists.exists) {
        throw new Error(`ENOENT: no such file or directory, rename '${oldPath}' -> '${newPath}'`);
      }
      const newParentDir = newPath.split("/").slice(0, -1).join("/");
      if (newParentDir) {
        const parentExists = await this.workerThread.execute("isDirectoryDot", { path: newParentDir });
        if (!parentExists.exists || !parentExists.isDirectory) {
          throw new Error(`ENOENT: no such directory, rename '${oldPath}' -> '${newPath}'`);
        }
      }
      await this.workerThread.execute("rename", {
        oldPath,
        newPath
      });
      return 0;
    } catch (error) {
      consoleDotError$5(`Error renaming ${oldPath} to ${newPath}:`, error);
      throw error;
    }
  }
  async fs_opendir(path2) {
    if (!this.workerThread) await this.initializeWorker();
    consoleDotLog$6(`Opening directory: ${path2}`);
    try {
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such directory, opendir '${path2}'`);
      }
      if (!exists.isDirectory) {
        throw new Error(`ENOTDIR: not a directory, opendir '${path2}'`);
      }
      await this.workerThread.execute("opendir", { path: path2 });
      return 0;
    } catch (error) {
      consoleDotError$5(`Error opening directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_readdir(path2, options = {}) {
    consoleDotLog$6(`Reading directory: ${path2}`);
    try {
      if (!this.workerThread) await this.initializeWorker();
      const exists = await this.workerThread.execute("isDirectoryDot", { path: path2 });
      if (!exists.exists) {
        throw new Error(`ENOENT: no such directory, readdir '${path2}'`);
      }
      if (!exists.isDirectory) {
        throw new Error(`ENOTDIR: not a directory, readdir '${path2}'`);
      }
      const result = await this.workerThread.execute("readDirDot", { path: path2 });
      const dirEntries = result?.entries || [];
      return dirEntries.map((entry) => ({ path: entry.path, type: entry.type === "tree" ? "dir" : "file" }));
    } catch (error) {
      consoleDotError$5(`Error reading directory ${path2}:`, error);
      throw error;
    }
  }
  async fs_feof(fd) {
    consoleDotLog$6(`Checking EOF for file descriptor: ${fd}`);
    const file = this.fileDescriptors.get(fd);
    if (!file) {
      throw new Error(`EBADF: bad file descriptor, eof '${fd}'`);
    }
    try {
      if (!this.workerThread) await this.initializeWorker();
      const data = await this.workerThread.execute("readFileDot", { filePath: file.path }).catch(() => "");
      consoleDotLog$6(`Current data in file ${file.path}:`, data);
      const eof = file.pos >= data.length;
      consoleDotLog$6(`EOF status for file ${file.path}: ${eof}`);
      return eof;
    } catch (error) {
      consoleDotError$5(`Error checking EOF for file ${file.path}:`, error);
      throw error;
    }
  }
  async fs_fflush(fd) {
    consoleDotLog$6(`Flushing file descriptor: ${fd}`);
    return 0;
  }
  async fs_fcloseall() {
    consoleDotLog$6("Closing all file descriptors.");
    this.fileDescriptors.clear();
    return 0;
  }
}
const IDBFs$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  IDBFs
}, Symbol.toStringTag, { value: "Module" }));
const config$6 = await getConfig();
const logger$5 = new Logger(config$6.logging.GitAuth);
function consoleDotLog$5(...parameters) {
  logger$5.consoleDotLog(...parameters);
}
function consoleDotError$4(...parameters) {
  logger$5.consoleDotError(...parameters);
}
class GitAuth {
  constructor(workerThread) {
    this.workerThread = workerThread;
    this.AuthChecked = false;
  }
  /**
   * Sets authentication credentials for Git operations
   * @param {string} username 
   * @param {string} password 
   * @returns {Promise<boolean>}
   */
  async setAuthParams(username, password) {
    try {
      if (!this.workerThread) {
        throw new Error("Worker thread not initialized");
      }
      await this.workerThread.execute("setAuthParams", { username, password });
      consoleDotLog$5("Auth params set successfully");
      if (!this.AuthChecked) {
        this.AuthChecked = true;
      }
      consoleDotLog$5("Auth params verified successfully");
      return true;
    } catch (error) {
      consoleDotError$4("Failed to set auth params:", error);
      throw error;
    }
  }
  /**
   * Verifies if current auth credentials are valid
   * @returns {Promise<boolean>}
   */
  async verifyAuth() {
    try {
      if (!this.workerThread) {
        throw new Error("Worker thread not initialized");
      }
      await this.workerThread.execute("listServerRefs");
      consoleDotLog$5("Auth verification successful");
      return true;
    } catch (error) {
      if (error.toString().includes("401") || error.toString().includes("403")) {
        consoleDotLog$5("Auth verification failed - invalid credentials");
        return false;
      }
      consoleDotError$4("Auth verification error:", error);
      throw error;
    }
  }
  /**
   * Sets Git user config (name and email)
   * @param {string} name 
   * @param {string} email 
   */
  async setUserConfig(name, email) {
    try {
      await this.workerThread.execute("setConfigs", { name, email });
      consoleDotLog$5(`User config set, name: ${name}, email: ${email}`);
      return true;
    } catch (error) {
      consoleDotError$4(`Failed to set user config: ${error}`);
      throw error;
    }
  }
}
const config$5 = await getConfig();
const logger$4 = new Logger(config$5.logging.VFSutils);
function consoleDotLog$4(...parameters) {
  logger$4.consoleDotLog("[ VFSUtils ]", ...parameters);
}
function consoleDotError$3(...parameters) {
  logger$4.consoleDotError("[ VFSUtils ]", ...parameters);
}
consoleDotLog$4("Loading VFSUtils module");
class VFSutils {
  constructor(fsType, fsInstance, fsName, fetchInfo) {
    this.fsType = fsType;
    this.fsInstance = fsInstance;
    this.fsName = fsName;
    this.fetchInfo = fetchInfo;
    this.workerEntry = null;
    this.workerThread = null;
    this.inodeCounter = 12341;
    this.fsTable = {};
    this.initialized = false;
    this.auth = null;
  }
  async initialize() {
    if (this.initialized) return;
    try {
      this.workerEntry = await workerPool.getWorker(this.fsName);
      this.workerThread = this.workerEntry.thread;
      consoleDotLog$4("Setting Fs for VFSUtils.");
      await this.workerThread.execute("setFs", {
        fsName: this.fsName,
        fsType: this.fsType
      });
      consoleDotLog$4("Fs set.");
      if (this.fetchInfo.corsProxy) {
        await this.workerThread.execute("setCorsProxy", {
          corsProxy: this.fetchInfo.corsProxy
        });
      }
      this.auth = new GitAuth(this.workerThread);
      if (this.fetchInfo.username || this.fetchInfo.password) {
        await this.setAuthParams(this.fetchInfo.username, this.fetchInfo.password);
      }
      this.initialized = true;
      consoleDotLog$4(`VFSutils initialized for ${this.fsName} with type ${this.fsType}`);
    } catch (error) {
      await this.terminate();
      throw error;
    }
  }
  async terminate(fsName = null, fsType = null) {
    try {
      if (fsName && fsType && this.workerThread) {
        try {
          consoleDotLog$4("Terminating VFSUtils...", fsName, fsType);
          await this.workerThread.execute("handleDeleteCloseAndReclone", {
            fsName,
            fsType,
            reclone: true
          });
        } catch (error) {
          consoleDotError$3(`Some error happened while terminating VFS: `, error);
        }
      }
      if (this.workerEntry) {
        await workerPool.releaseWorker(this.fsName);
        this.workerEntry = null;
        this.workerThread = null;
      }
      this.initialized = false;
      return true;
    } catch (error) {
      consoleDotError$3("VFSutils termination error:", error);
      return false;
    }
  }
  async initRepoLocally() {
    try {
      consoleDotLog$4("Initializing local repository...");
      if (!this.initialized) await this.initialize();
      const initResult = await this.workerThread.execute("init");
      consoleDotLog$4("initialized.");
      if (!initResult.success) {
        throw new Error("Local repository initialization failed!");
      }
      if (this.fetchInfo.name && this.fetchInfo.email) {
        await this.setUserConfig(this.fetchInfo.name, this.fetchInfo.email);
      }
      await this.generateFsTable();
      consoleDotLog$4("Repository successfully initialized and indexed");
    } catch (error) {
      consoleDotError$3(`Local repo init failed: ${error}`);
      await this.terminate();
      throw error;
    }
  }
  async fetchFromGit() {
    try {
      consoleDotLog$4("Fetching from Git repository...");
      if (!this.initialized) await this.initialize();
      consoleDotLog$4("initialized.");
      const { url, dir = "/" } = this.fetchInfo;
      consoleDotLog$4(`Cloning repository from ${url} to ${dir}`);
      if (url === "" || !url) {
        await this.initRepoLocally();
      } else {
        const cloneResult = await this.workerThread.execute("doCloneAndStuff", { url });
        await this.fetchNotes();
        if (!cloneResult.success) {
          throw new Error("Fetching from git failed!");
        }
      }
      if (this.fetchInfo.name && this.fetchInfo.email) {
        await this.setUserConfig(this.fetchInfo.name, this.fetchInfo.email);
      }
      await this.generateFsTable();
      consoleDotLog$4("Repository successfully cloned and indexed");
    } catch (error) {
      consoleDotError$3(`Git fetch failed: ${error}`);
      await this.terminate();
      throw error;
    }
  }
  async fetchFromDisk() {
    try {
      if (!this.initialized) await this.initialize();
      consoleDotLog$4(`Loading filesystem from disk`);
      await this.initRepoLocally();
      await this.generateFsTable();
      consoleDotLog$4(`Successfully loaded filesystem from disk`);
    } catch (error) {
      consoleDotError$3(`Disk load failed: ${error.message}`);
      await this.terminate();
      throw error;
    }
  }
  async fetchFromGoogleDrive() {
    try {
      if (!this.initialized) await this.initialize();
      const { fileId } = this.fetchInfo;
      consoleDotLog$4(`Fetching from Google Drive file ${fileId}`);
      await this.generateFsTable();
      consoleDotLog$4(`Successfully fetched from Google Drive`);
    } catch (error) {
      consoleDotError$3(`Google Drive fetch failed: ${error.message}`);
      await this.terminate();
      throw error;
    }
  }
  /* FS Table Management */
  async generateFsTable() {
    try {
      if (!this.initialized) await this.initialize();
      consoleDotLog$4("Generating FS table...");
      const fileList = await this.workerThread.execute("listFilesDot", { listDirs: true });
      consoleDotLog$4("File list:", fileList);
      this.fsTable = this.buildHierarchicalFsTable(fileList);
      consoleDotLog$4(
        "FS table generated with",
        Object.keys(this.fsTable["/"].children).length,
        "root entries"
      );
      return this.fsTable;
    } catch (error) {
      consoleDotError$3("FS table generation failed:", error);
      throw error;
    }
  }
  buildHierarchicalFsTable(fileList) {
    const root = this.createRootEntry();
    fileList.forEach((entry) => {
      const pathParts = entry.path.split("/").filter((p) => p !== "");
      let current = root;
      pathParts.forEach((part, index) => {
        const isLast = index === pathParts.length - 1;
        if (current.children[part]) {
          const existing = current.children[part];
          const expectedType = isLast && entry.type !== "tree" ? "file" : "directory";
          if (existing.type !== expectedType) {
            throw new Error(
              `FS conflict: ${entry.path} has ${expectedType} where ${existing.type} already exists`
            );
          }
        } else {
          current.children[part] = this.createFsTableEntry(
            part,
            isLast && entry.type !== "tree" ? "file" : "directory",
            entry.size || 0,
            current.dentry_id
          );
        }
        if (!isLast) {
          if (current.children[part].type !== "directory") {
            current.children[part] = {
              ...current.children[part],
              type: "directory",
              children: {}
            };
          }
          current = current.children[part];
        }
      });
    });
    return { "/": root };
  }
  async updateFsTable(action, path2, type = "file", size = 0) {
    try {
      const normalizedPath = path2.replace(/^\/+|\/+$/g, "");
      if (!this.fsTable["/"]) {
        this.fsTable["/"] = this.createRootEntry();
      }
      const pathParts = normalizedPath.split("/");
      let current = this.fsTable["/"];
      if (action === "remove" && pathParts.length === 0) {
        throw new Error("Cannot remove root directory");
      }
      for (let i = 0; i < pathParts.length - 1; i++) {
        const part = pathParts[i];
        if (!current.children || !current.children[part]) {
          if (action === "remove") {
            throw new Error(`Parent path not found: ${pathParts.slice(0, i + 1).join("/")}`);
          }
          current.children[part] = this.createFsTableEntry(
            part,
            "directory",
            0,
            current.dentry_id
          );
        }
        current = current.children[part];
      }
      const name = pathParts[pathParts.length - 1];
      switch (action) {
        case "create":
          if (!current.children) {
            current.children = {};
          }
          if (current.children[name]) {
            consoleDotLog$4(`path ${path2} already exists, updating its content`);
          }
          current.children[name] = this.createFsTableEntry(
            name,
            type,
            size,
            current.dentry_id
          );
          break;
        case "remove":
          if (!current.children || !current.children[name]) {
            return { success: false, message: `Path not found: ${path2}` };
          }
          if (current.children[name].type === "directory" && Object.keys(current.children[name].children || {}).length > 0) {
            throw new Error(`Cannot remove non-empty directory: ${path2}`);
          }
          delete current.children[name];
          break;
        default:
          throw new Error(`Invalid action: ${action}`);
      }
      return { success: true, fsTable: this.fsTable };
    } catch (error) {
      consoleDotError$3("FS table update failed:", error);
      throw error;
    }
  }
  createRootEntry() {
    return {
      type: "directory",
      dentry_id: this.inodeCounter++,
      name: "",
      parent_inode: 0,
      acl: { owner: "root", permissions: "rwx", groups: { "users": "r" } },
      children: {},
      ctime: Date.now(),
      mtime: Date.now()
    };
  }
  createFsTableEntry(name, type, size, parentInode) {
    const isDir = type === "directory";
    return {
      inode: this.inodeCounter++,
      type,
      name,
      mode: isDir ? 16877 : 100644,
      size: isDir ? 0 : size,
      uid: 1e3,
      gid: 100,
      parent_inode: parentInode,
      acl: {
        owner: "user",
        permissions: isDir ? "rwx" : "rw-",
        groups: { users: "r" }
      },
      children: isDir ? {} : void 0,
      ctime: Date.now(),
      mtime: Date.now()
    };
  }
  async getFsTableSize(fsTable) {
    try {
      return fsTable ? JSON.stringify(fsTable).length : 0;
    } catch (error) {
      consoleDotError$3("Size calculation failed:", error);
      return 0;
    }
  }
  async commitStagedChanges(message) {
    try {
      if (!this.initialized) await this.initialize();
      await this.workerThread.execute("setFs", {
        fsName: this.fsName,
        fsType: this.fsType
      });
      return await this.workerThread.execute("commitStagedChanges", { message });
    } catch (error) {
      consoleDotError$3("Version commit failed:", error);
      throw error;
    }
  }
  // -------------------
  //  Merging Methods
  // -------------------
  /**
   * Optimized sync status check with minimal remote operations
   */
  async getSyncStatus(__url = null, ref = "main") {
    try {
      consoleDotLog$4("Starting sync status check...");
      const _url = __url || this?.fetchInfo?.url;
      consoleDotLog$4("Getting local head commit...");
      const localHead = await this.workerThread.execute("getLastLocalCommit", { ref });
      consoleDotLog$4("Local head commit:", localHead);
      consoleDotLog$4("Getting remote head commit...");
      const remoteResult = await this.workerThread.execute("getLatestRemoteCommit", {
        url: _url,
        ref
      });
      consoleDotLog$4("Remote head result:", remoteResult);
      if (!remoteResult.success) {
        consoleDotLog$4("Remote branch not found");
        return {
          status: "remote-branch-not-found",
          localHead,
          remoteHead: null
        };
      }
      const remoteHead = remoteResult.commit;
      consoleDotLog$4("Remote head commit:", remoteHead);
      if (localHead === remoteHead) {
        consoleDotLog$4("Local and remote heads match - up to date");
        return {
          status: "up-to-date",
          localHead,
          remoteHead
        };
      }
      consoleDotLog$4("Getting commit histories...");
      const [localCommits, remoteCommits] = await Promise.all([
        await this.getLocalCommitHistory(10),
        await this.getRemoteCommitHistory(10)
      ]);
      consoleDotLog$4("Local commits (10 most recent):", localCommits);
      consoleDotLog$4("Remote commits (10 most recent):", remoteCommits);
      const commonCommit = this.findFirstCommonCommit(localCommits, remoteCommits);
      consoleDotLog$4("Common commit found:", commonCommit);
      let status;
      if (!commonCommit) {
        status = "diverged";
        consoleDotLog$4("No common commit found - branches have diverged");
      } else if (commonCommit === remoteHead) {
        status = "local-ahead";
        consoleDotLog$4("Local is ahead of remote");
      } else if (commonCommit === localHead) {
        status = "remote-ahead";
        consoleDotLog$4("Remote is ahead of local");
      } else {
        status = "diverged";
        consoleDotLog$4("Branches have diverged");
      }
      return {
        status,
        localHead,
        remoteHead,
        commonAncestor: commonCommit
      };
    } catch (err) {
      consoleDotError$3("getSyncStatus failed:", err);
      return {
        status: "error",
        error: err.message
      };
    }
  }
  /**
   * Find first common commit between two commit lists
   */
  findFirstCommonCommit(localCommits, remoteCommits) {
    const remoteSet = new Set(remoteCommits);
    for (const commit of localCommits) {
      if (remoteSet.has(commit)) {
        return commit;
      }
    }
    return null;
  }
  /**
   * Get local commit history
   */
  async getLocalCommitHistory(depth = 10) {
    try {
      const logs = await this.workerThread.execute("log", {
        depth
      });
      const commits = logs.map((commit) => commit.oid);
      consoleDotLog$4("GetLocalCommitHistory result: ", commits);
      return commits || [];
    } catch (error) {
      consoleDotError$3("Failed to get local commit history:", error);
      return [];
    }
  }
  /**
   * Get remote commit history by fetching from replica
   */
  async getRemoteCommitHistory(depth = 10) {
    try {
      consoleDotLog$4("Fetching remote commit history with depth:", depth);
      const result = await this.workerThread.execute("getCommitHistoryFromReplica", {
        depth
      });
      consoleDotLog$4("Raw result from worker:", result);
      if (Array.isArray(result)) {
        consoleDotLog$4("Received direct commits array:", result);
        return result;
      } else if (result && (result.commits || result.success)) {
        consoleDotLog$4("Received structured response with commits:", result.commits || []);
        return result.commits || [];
      } else {
        consoleDotError$3("Unexpected response format:", result);
        return [];
      }
    } catch (error) {
      consoleDotError$3("Failed to get remote commit history:", error);
      return [];
    }
  }
  /**
   * Optimized sync flow that minimizes remote operations
   */
  async autoSyncFlow(onConflictStrategy, syncUrl) {
    try {
      consoleDotLog$4("this.fetchInfo", this.fetchInfo);
      const { status, localHead, remoteHead, commonAncestor } = await this.getSyncStatus(syncUrl);
      consoleDotLog$4("Sync status:", status);
      switch (status) {
        case "up-to-date":
          return { synced: true };
        case "local-ahead":
          return await this.handleLocalAhead(localHead, remoteHead, onConflictStrategy, syncUrl);
        case "remote-ahead":
          return await this.handleRemoteAhead(localHead, remoteHead, onConflictStrategy, syncUrl);
        case "diverged":
          return await this.handleDiverged(localHead, remoteHead, commonAncestor, onConflictStrategy, syncUrl);
        case "remote-branch-not-found":
          consoleDotError$3("Remote branch not found");
          return { synced: false, error: "Remote branch not found" };
        default:
          throw new Error(`Unknown sync status: ${status}`);
      }
    } catch (err) {
      consoleDotError$3("autoSyncFlow failed:", err);
      throw err;
    }
  }
  /**
   * Handle case where remote is ahead of local (need to pull changes)
   */
  async handleRemoteAhead(localHead, remoteHead, onConflictStrategy, syncUrl) {
    try {
      consoleDotLog$4(`Handling remote-ahead scenario (local: ${localHead}, remote: ${remoteHead})`);
      const _onConflictStrategy = onConflictStrategy || "theirs";
      consoleDotLog$4("Attempting fast-forward merge...");
      const ffResult = await this.workerThread.execute("fastForward", {
        url: syncUrl,
        ref: "main"
      });
      if (ffResult.success) {
        consoleDotLog$4("Fast-forward successful");
        await this.generateFsTable();
        return {
          synced: true,
          strategy: "fast-forward",
          oldHead: localHead,
          newHead: remoteHead
        };
      }
      consoleDotLog$4("Fast-forward failed, attempting full pull...");
      const pullResult = await this.workerThread.execute("doFetch", {
        url: syncUrl,
        ref: "main"
      });
      consoleDotLog$4("Fetching notes from remote...");
      await this.workerThread.execute("doFetch", {
        url: syncUrl,
        remote: "origin",
        ref: "refs/notes/commits",
        tags: true,
        singleBranch: true
      });
      const mergeResult = await this.workerThread.execute("merge", {
        ours: "main",
        theirs: "origin/main",
        strategy: _onConflictStrategy
      });
      consoleDotLog$4("Fetching notes from remote...");
      await this.workerThread.execute("doFetch", {
        url: syncUrl,
        remote: "origin",
        ref: "refs/notes/commits",
        tags: true,
        singleBranch: true
      });
      if (!pullResult.success) {
        throw new Error("Pull failed: " + (pullResult.error || "Unknown error"));
      }
      consoleDotLog$4("Pull successful");
      await this.generateFsTable();
      const newLocalHead = await this.workerThread.execute("getLastLocalCommit", { ref: "main" });
      if (newLocalHead !== remoteHead) {
        consoleDotLog$4(`Warning: Local head (${newLocalHead}) doesn't match remote head (${remoteHead}) after pull`);
      }
      return {
        synced: true,
        strategy: "pull-with-merge",
        oldHead: localHead,
        newHead: newLocalHead
      };
    } catch (error) {
      consoleDotError$3("handleRemoteAhead failed:", error);
      try {
        await this.workerThread.execute("resetToCommit", {
          oid: localHead,
          hard: true
        });
      } catch (resetError) {
        consoleDotError$3("Failed to reset after error:", resetError);
      }
      throw error;
    }
  }
  /**
   * Handle case where local is ahead of remote (need to push changes)
   */
  async handleLocalAhead(localHead, remoteHead, onConflictStrategy, syncUrl) {
    try {
      consoleDotLog$4(`Handling local-ahead scenario (local: ${localHead}, remote: ${remoteHead})`);
      await this.setAuthParams(this.fetchInfo.username, this.fetchInfo.password);
      const pushNotesResult = await this.workerThread.execute("push", {
        url: syncUrl,
        ref: "refs/notes/commits",
        remoteRef: "refs/notes/commits",
        force: false
      });
      consoleDotLog$4("Attempting push...");
      const pushResult = await this.workerThread.execute("push", {
        url: syncUrl,
        ref: "main",
        force: false
      });
      if (pushResult.success || pushNotesResult.success) {
        consoleDotLog$4("Push successful");
        return {
          synced: true,
          strategy: "push",
          oldRemoteHead: remoteHead,
          newRemoteHead: localHead
        };
      }
      consoleDotLog$4("Push failed, rechecking sync status...");
      const newStatus = await this.getSyncStatus(syncUrl);
      if (newStatus.status === "up-to-date") {
        consoleDotLog$4("Status is now up-to-date after push failure");
        return { synced: true, strategy: "concurrent-update" };
      }
      if (newStatus.status === "remote-ahead") {
        consoleDotLog$4("Remote moved ahead during push attempt");
        return this.handleRemoteAhead(localHead, newStatus.remoteHead);
      }
      if (newStatus.status === "diverged") {
        consoleDotLog$4("Branches diverged during push attempt");
        return this.handleDiverged(localHead, newStatus.remoteHead, newStatus.commonAncestor, onConflictStrategy, syncUrl);
      }
      throw new Error(`Unexpected status after push failure: ${newStatus.status}`);
    } catch (error) {
      consoleDotError$3("handleLocalAhead failed:", error);
      throw error;
    }
  }
  /**
   * Handle case where branches have diverged
   */
  async handleDiverged(localHead, remoteHead, commonAncestor, onConflictStrategy, syncUrl) {
    try {
      const _onConflictStrategy = onConflictStrategy || "theirs";
      consoleDotLog$4("Using merge workflow");
      consoleDotLog$4("Pulling with merge...");
      const pullResult = await this.workerThread.execute("doFetch", {
        url: syncUrl,
        ref: "main"
      });
      consoleDotLog$4("Fetching notes from remote...");
      await this.workerThread.execute("doFetch", {
        url: syncUrl,
        remote: "origin",
        ref: "refs/notes/commits",
        tags: true,
        singleBranch: true
      });
      const mergeResult = await this.workerThread.execute("merge", {
        ours: "main",
        theirs: "origin/main",
        strategy: _onConflictStrategy
      });
      if (!pullResult.success) {
        throw new Error("Pull failed: " + (pullResult.error || "Unknown error"));
      }
      const pushNotesResult = await this.workerThread.execute("push", {
        url: syncUrl,
        ref: "refs/notes/commits",
        remoteRef: "refs/notes/commits",
        force: false
      });
      consoleDotLog$4("Pushing merged changes...");
      await this.setAuthParams(this.fetchInfo.username, this.fetchInfo.password);
      const pushResult = await this.workerThread.execute("push", {
        url: syncUrl,
        ref: "main",
        force: false
      });
      return {
        synced: true,
        strategy: "merge-workflow",
        oldLocalHead: localHead,
        newLocalHead: await this.workerThread.execute("getLastLocalCommit", { ref: "main" }),
        remoteHead
      };
    } catch (error) {
      consoleDotError$3("handleDiverged failed:", error);
      try {
        await this.workerThread.execute("resetToCommit", {
          oid: localHead,
          hard: true
        });
      } catch (resetError) {
        consoleDotError$3("Failed to reset after error:", resetError);
      }
      throw error;
    }
  }
  // ------------------------
  //  Authentication Methods
  // ------------------------
  /**
   * Sets authentication credentials
   * @param {string} username 
   * @param {string} password 
   * @returns {Promise<boolean>}
   */
  async setAuthParams(username, password) {
    return this.auth.setAuthParams(username, password);
  }
  /**
   * Sets Git user config (name and email)
   * @param {string} name
   * @param {string} email
   * @returns {Promise<void>}
   */
  async setUserConfig(name, email) {
    return this.auth.setUserConfig(name, email);
  }
  /**
   * Verifies if current auth credentials are valid
   * @returns {Promise<boolean>}
   */
  async verifyAuth() {
    return this.auth.verifyAuth();
  }
  async updateFetchInfo(args) {
    try {
      const newFetchInfo = args || {};
      if (!this.initialized) await this.initialize();
      this.fetchInfo = { ...this.fetchInfo, ...newFetchInfo };
      consoleDotLog$4("Fetch info updated:", this.fetchInfo);
      return this.fetchInfo;
    } catch (error) {
      consoleDotError$3("Some error happened while using updateFetchInfo");
      throw new Error("Some error happened while using updateFetchInfo");
    }
  }
  // ------------------
  //  Helper functions
  // ------------------
  async fetchNotes() {
    try {
      await this.reconfigureRemoteWithNotes();
      const serverRefs = await this.workerThread.execute("listServerRefs", {
        remote: "origin"
      });
      const hasNotes = serverRefs.refs.some((row) => row.ref === "refs/notes/commits");
      if (hasNotes) {
        consoleDotLog$4("Fetching notes from remote...");
        await this.workerThread.execute("doFetch", {
          url: this.fetchInfo.url,
          remote: "origin",
          ref: "refs/notes/commits",
          tags: true,
          singleBranch: true
        });
        consoleDotLog$4("Notes Fetch is done.");
      }
    } catch (error) {
      consoleDotError$3("Failed to fetch notes:", error);
    }
  }
  async reconfigureRemoteWithNotes() {
    try {
      const fetch2 = await this.workerThread.execute("getConfig", {
        path: "remote.origin.fetch"
      });
      if (fetch2 !== "+refs/notes/*:refs/notes/*") {
        await this.workerThread.execute("setConfig", {
          path: "remote.origin.fetch",
          value: "+refs/notes/*:refs/notes/*",
          args: { append: true }
        });
      }
      consoleDotLog$4("Successfully reconfigured remote with notes fetch");
    } catch (error) {
      consoleDotError$3("Failed to reconfigure remote:", error);
      throw error;
    }
  }
}
class StorageUtils {
  constructor(dbName = "VFS_Mounts") {
    this.dbName = dbName;
    this.localStorageWarningShown = false;
    this.forceLocalStorage = false;
  }
  supportsIndexedDB() {
    if (this.forceLocalStorage) return false;
    try {
      return typeof window !== "undefined" && !!window.indexedDB;
    } catch (e2) {
      return false;
    }
  }
  async ensureObjectStoreExists() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      request.onerror = () => {
        console.error("IndexedDB open error:", request.error);
        resolve(false);
      };
      request.onsuccess = () => {
        const db = request.result;
        if (db.objectStoreNames.contains("mounts")) {
          resolve(true);
        } else {
          resolve(false);
        }
        db.close();
      };
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains("mounts")) {
          db.createObjectStore("mounts");
          console.log("Created 'mounts' object store");
        }
      };
    });
  }
  /** Simplified localStorage methods with error handling */
  async getFromLocalStorage(key) {
    try {
      if (typeof localStorage === "undefined") return null;
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (e2) {
      console.error("LocalStorage get error:", e2);
      return null;
    }
  }
  async getFromIndexedDB(key) {
    const hasObjectStore = await this.ensureObjectStoreExists();
    if (!hasObjectStore) return null;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      request.onerror = () => resolve(null);
      request.onsuccess = () => {
        const db = request.result;
        try {
          const transaction = db.transaction("mounts", "readonly");
          const store2 = transaction.objectStore("mounts");
          const getRequest = store2.get(key);
          getRequest.onsuccess = () => resolve(getRequest.result || null);
          getRequest.onerror = () => resolve(null);
        } catch (error) {
          console.error("Transaction error:", error);
          resolve(null);
        } finally {
          db.close();
        }
      };
    });
  }
  async getAll() {
    if (this.supportsIndexedDB()) {
      try {
        return await this.getAllFromIndexedDB();
      } catch (e2) {
        console.error("IndexedDB getAll failed:", e2);
        return await this.getAllFromLocalStorage();
      }
    }
    return await this.getAllFromLocalStorage();
  }
  async getAllFromIndexedDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      request.onerror = () => resolve({});
      request.onsuccess = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains("mounts")) {
          resolve({});
          return;
        }
        const transaction = db.transaction("mounts", "readonly");
        const store2 = transaction.objectStore("mounts");
        const getAllKeysRequest = store2.getAllKeys();
        const result = {};
        getAllKeysRequest.onsuccess = async () => {
          const keys2 = getAllKeysRequest.result;
          for (const key of keys2) {
            const value = await this.get(key);
            if (value) {
              result[key] = value;
            }
          }
          resolve(result);
        };
        getAllKeysRequest.onerror = () => resolve({});
      };
    });
  }
  async getAllFromLocalStorage() {
    try {
      if (typeof localStorage === "undefined") return {};
      const result = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(this.dbName)) {
          try {
            result[key] = JSON.parse(localStorage.getItem(key));
          } catch (e2) {
            console.error("Error parsing localStorage item:", e2);
          }
        }
      }
      return result;
    } catch (e2) {
      console.error("LocalStorage getAll error:", e2);
      return {};
    }
  }
  async storeInLocalStorage(key, data) {
    try {
      if (typeof localStorage === "undefined") return false;
      const dataStr = JSON.stringify(data);
      if (dataStr.length > 5e6) {
        console.error("Data too large for localStorage");
        return false;
      }
      localStorage.setItem(key, dataStr);
      return true;
    } catch (e2) {
      console.error("LocalStorage set error:", e2);
      if (e2.name === "QuotaExceededError") {
        this.forceLocalStorage = true;
      }
      return false;
    }
  }
  async removeFromLocalStorage(key) {
    try {
      if (typeof localStorage === "undefined") return false;
      localStorage.removeItem(key);
      return true;
    } catch (e2) {
      console.error("LocalStorage remove error:", e2);
      return false;
    }
  }
  async get(key) {
    let value = null;
    if (this.supportsIndexedDB()) {
      try {
        value = await this.getFromIndexedDB(key);
      } catch (e2) {
        console.error("IndexedDB get failed:", e2);
      }
    }
    if (value === null) {
      try {
        value = await this.getFromLocalStorage(key);
      } catch (e2) {
        console.error("LocalStorage get fallback failed:", e2);
      }
    }
    return value;
  }
  async store(key, data) {
    let indexedSuccess = false;
    let localSuccess = false;
    if (this.supportsIndexedDB()) {
      try {
        indexedSuccess = await this.storeInIndexedDB(key, data);
      } catch (e2) {
        console.error("IndexedDB store failed:", e2);
      }
    }
    try {
      localSuccess = await this.storeInLocalStorage(key, data);
    } catch (e2) {
      console.error("LocalStorage store failed:", e2);
    }
    return indexedSuccess || localSuccess;
  }
  async remove(key) {
    let success = true;
    if (this.supportsIndexedDB()) {
      try {
        success = await this.removeFromIndexedDB(key) && success;
      } catch (e2) {
        console.error("IndexedDB remove failed:", e2);
        success = false;
      }
    }
    try {
      success = await this.removeFromLocalStorage(key) && success;
    } catch (e2) {
      console.error("LocalStorage remove failed:", e2);
      success = false;
    }
    return success;
  }
  async storeInIndexedDB(key, data) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);
      request.onerror = () => resolve(false);
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction("mounts", "readwrite");
        const store2 = transaction.objectStore("mounts");
        store2.put(data, key);
        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => resolve(false);
      };
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains("mounts")) {
          db.createObjectStore("mounts");
        }
      };
    });
  }
  async removeFromIndexedDB(key) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);
      request.onerror = () => resolve(false);
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction("mounts", "readwrite");
        const store2 = transaction.objectStore("mounts");
        store2.delete(key);
        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => resolve(false);
      };
    });
  }
}
const config$4 = await getConfig();
const logger$3 = new Logger(config$4.logging.supportChecker);
function consoleDotLog$3(...parameters) {
  logger$3.consoleDotLog(...parameters);
}
async function checkIndexedDBSupport() {
  try {
    if (!window.indexedDB) {
      consoleDotLog$3("IndexedDB not supported in this browser");
      return false;
    }
    return await new Promise((resolve) => {
      const dbName = "testIDBSupport";
      const request = indexedDB.open(dbName);
      request.onerror = () => {
        consoleDotLog$3("IndexedDB not available");
        resolve(false);
      };
      request.onsuccess = (event) => {
        const db = event.target.result;
        db.close();
        const deleteRequest = indexedDB.deleteDatabase(dbName);
        deleteRequest.onerror = () => {
          consoleDotLog$3("Failed to delete test database");
          resolve(true);
        };
        deleteRequest.onsuccess = () => {
          consoleDotLog$3("IndexedDB test successful");
          resolve(true);
        };
      };
      request.onblocked = () => {
        consoleDotLog$3("IndexedDB request blocked");
        resolve(false);
      };
    });
  } catch (e2) {
    consoleDotLog$3("IndexedDB test failed:", e2);
    return false;
  }
}
const config$3 = await getConfig();
const logger$2 = new Logger(config$3.logging.vfs);
function consoleDotLog$2(...parameters) {
  logger$2.consoleDotLog("[VFS] ", ...parameters);
}
function consoleDotError$2(...parameters) {
  logger$2.consoleDotError("[VFS] ", ...parameters);
}
class VFS {
  // Initialization and Core Setup
  constructor(storageName = "VFS_Mounts") {
    this.mounts = /* @__PURE__ */ Object.create(null);
    this.initializedMounts = /* @__PURE__ */ new Set();
    this.vfsUtilsInstances = /* @__PURE__ */ new Map();
    this.storageUtils = new StorageUtils(storageName);
    this.currentMountPath = "";
    this.idbSupported = null;
    (async () => {
      try {
        await this.retrieveAndMountFromFsTable();
      } catch (error) {
        consoleDotError$2("Automatic mount from fsTable failed:", error);
      }
    })();
    consoleDotLog$2("VFS instance created");
  }
  // Environment detection utilities
  getBrowserInfo() {
    if (typeof navigator === "undefined") return "Node.js";
    const userAgent = navigator.userAgent;
    let browser2 = "Unknown";
    if (userAgent.includes("Firefox")) browser2 = "Firefox";
    else if (userAgent.includes("SamsungBrowser")) browser2 = "Samsung Browser";
    else if (userAgent.includes("Opera") || userAgent.includes("OPR")) browser2 = "Opera";
    else if (userAgent.includes("Trident")) browser2 = "IE";
    else if (userAgent.includes("Edge")) browser2 = "Edge";
    else if (userAgent.includes("Chrome")) browser2 = "Chrome";
    else if (userAgent.includes("Safari")) browser2 = "Safari";
    return browser2;
  }
  getDeviceType() {
    if (typeof navigator === "undefined") return "Server";
    const userAgent = navigator.userAgent;
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(userAgent)) {
      return "Tablet";
    }
    if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(userAgent)) {
      return "Mobile";
    }
    return "Desktop";
  }
  getPlatformInfo() {
    const isBrowser = typeof window !== "undefined";
    return {
      browser: this.getBrowserInfo(),
      device: this.getDeviceType(),
      userAgent: isBrowser ? navigator.userAgent : "Node.js",
      platform: isBrowser ? navigator.platform : process$1.platform,
      screenResolution: isBrowser ? `${window.screen.width}x${window.screen.height}` : "N/A",
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      language: isBrowser ? navigator.language : "N/A"
    };
  }
  // Utility functions for versioning and merging
  getVersioningConfig(options = {}) {
    const versioning = options.versioning || config$3.versioning || {};
    return {
      strategy: versioning.strategy,
      interval: versioning.interval,
      number: versioning.number
    };
  }
  getMergingConfig(options = {}) {
    const merging = options.merging || config$3.merging || {};
    return {
      ...merging,
      strategy: merging.strategy || "immediate",
      onConflictStrategy: merging.onConflictStrategy || "local"
    };
  }
  // Storage and Support Checking
  async checkIndexedDBSupport() {
    consoleDotLog$2("Checking IndexedDB support...");
    if (this.idbSupported !== null) {
      return this.idbSupported;
    }
    if (typeof window === "undefined" || typeof navigator === "undefined") {
      consoleDotLog$2("Running in Node.js environment, IndexedDB not supported");
      this.idbSupported = false;
      return false;
    }
    try {
      await checkIndexedDBSupport();
      consoleDotLog$2("IndexedDB is supported");
      this.idbSupported = true;
      return true;
    } catch (error) {
      consoleDotError$2("IndexedDB not supported:", error);
      this.idbSupported = false;
      return false;
    }
  }
  async loadMountFromStorage(mountPath) {
    consoleDotLog$2(`Attempting to load mount from storage: ${mountPath}`);
    try {
      const storedMount = await this.storageUtils.get(mountPath);
      if (storedMount) {
        consoleDotLog$2(`Successfully loaded mount from storage: ${mountPath}`);
        return storedMount;
      }
      consoleDotLog$2(`No mount found in storage for path: ${mountPath}`);
      return null;
    } catch (error) {
      consoleDotError$2(`Failed to load mount from storage (path: ${mountPath}):`, error);
      throw error;
    }
  }
  async persistMountData(mountPath, mountData) {
    consoleDotLog$2(`Persisting mount data for ${mountPath}`);
    try {
      if (typeof indexedDB === "undefined") {
        this.mounts[mountPath] = mountData;
        consoleDotLog$2(`Node.js: Mount data persisted in memory for ${mountPath}`);
        return;
      }
      const dataToStore = { ...mountData };
      delete dataToStore.fsInstance;
      await this.storageUtils.store(mountPath, dataToStore);
      consoleDotLog$2(`Successfully persisted mount data for ${mountPath}`);
    } catch (error) {
      consoleDotError$2(`Failed to persist mount data for ${mountPath}:`, error);
      throw error;
    }
  }
  // Filesystem Instance Management
  async createFSInstance(fsType, mountPath, options = {}) {
    consoleDotLog$2(`Creating FS instance of type ${fsType} for mount path ${mountPath}`);
    try {
      const isNode = typeof window === "undefined";
      if (isNode && fsType === "node") {
        consoleDotLog$2("Using NodeFS (Native Worker Wrapper)");
        const { NodeFS } = await import("./NodeFS-DpMmI4EX.js");
        return new NodeFS(mountPath, { fsName: mountPath, fsType: "node", ...options });
      }
      if (isNode && fsType === "memory") {
        consoleDotLog$2("Using NodeFS (Disk-backed) for memory in Node.js");
        const { NodeFS } = await import("./NodeFS-DpMmI4EX.js");
        return new NodeFS(mountPath, { fsName: mountPath, fsType: "memory", ...options });
      }
      const useSW = false;
      if (fsType === "idb") {
        const isSupported = await this.checkIndexedDBSupport();
        if (!isSupported) {
          consoleDotLog$2(`IndexedDB not supported, falling back to memory FS for ${mountPath}`);
          fsType = "memory";
        }
      }
      let fsInstance;
      switch (fsType) {
        case "memory":
          consoleDotLog$2("Creating MemoryFS instance");
          const { MemoryFS: MemoryFS2 } = await Promise.resolve().then(() => memoryFs);
          fsInstance = new MemoryFS2(mountPath, { ...options, useSW: false });
          break;
        case "idb":
          consoleDotLog$2("Creating IDBFs instance");
          const { IDBFs: IDBFs2 } = await Promise.resolve().then(() => IDBFs$1);
          fsInstance = new IDBFs2(mountPath, { ...options, useSW });
          break;
        default:
          throw new Error(`Unknown FS type: ${fsType}`);
      }
      return fsInstance;
    } catch (error) {
      consoleDotError$2(`Failed to create FS instance`, error);
      throw error;
    }
  }
  async ensureFSInitialized(fsPath) {
    consoleDotLog$2(`Ensuring FS is initialized for path: ${fsPath}`);
    if (this.initializedMounts.has(fsPath)) {
      consoleDotLog$2(`FS already initialized for path: ${fsPath}`);
      return true;
    }
    const mountData = this.mounts[fsPath];
    if (!mountData) {
      const errorMsg = `Mount not found: ${fsPath}`;
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    }
    if (!mountData.fsInstance) {
      consoleDotLog$2(`Creating new FS instance for mount at ${fsPath}`);
      mountData.fsInstance = await this.createFSInstance(
        mountData.fsType,
        fsPath,
        {
          versioning: this.getVersioningConfig(mountData),
          merging: this.getMergingConfig(mountData)
        }
      );
    }
    consoleDotLog$2(`Fetching data for mount at ${fsPath}`);
    await this.fetchFS(
      mountData.fetchMethod,
      mountData.fsType,
      mountData.fsInstance,
      fsPath,
      mountData.fetchInfo
    );
    this.initializedMounts.add(fsPath);
    consoleDotLog$2(`Successfully initialized FS for path: ${fsPath}`);
    return true;
  }
  // Mount/Unmount Operations
  async mount(path2, fsType, fsName, fetchMethod, options = {}) {
    consoleDotLog$2(`Mounting filesystem - path: ${path2}, type: ${fsType}, name: ${fsName}, method: ${fetchMethod}, options: ${JSON.stringify(options)}`);
    try {
      const fetchInfo = options.fetchInfo || {};
      const versioning = this.getVersioningConfig(options);
      const merging = this.getMergingConfig(options);
      const normalizedPath = path2.endsWith("/") ? path2 : `${path2}/`;
      const mountPath = `${normalizedPath}${fsName}`;
      consoleDotLog$2(`Normalized mount path: ${mountPath}`);
      if (this.mounts[mountPath]) {
        const errorMsg = `Path ${mountPath} is already mounted`;
        consoleDotError$2(errorMsg);
        throw new Error(errorMsg);
      }
      this.currentMountPath = mountPath;
      consoleDotLog$2(`Checking storage for existing mount at ${mountPath}`);
      const storedMount = await this.loadMountFromStorage(mountPath);
      if (storedMount) {
        consoleDotLog$2(`Found stored mount, initializing existing mount at ${mountPath}`);
        return this.initializeStoredMount(mountPath, storedMount, fetchMethod, fetchInfo, { versioning, merging });
      }
      consoleDotLog$2(`No stored mount found, creating new mount at ${mountPath}`);
      return this.createNewMount(mountPath, fsType, fsName, fetchMethod, fetchInfo, versioning, merging);
    } catch (error) {
      consoleDotError$2("Mount operation failed:", error);
      throw error;
    }
  }
  async retrieveAndMountFromFsTable() {
    consoleDotLog$2("Attempting to retrieve and mount filesystems from fsTable");
    try {
      if (typeof indexedDB === "undefined") {
        consoleDotLog$2("IndexedDB not available (Node.js environment). Skipping mount from fsTable.");
        return false;
      }
      try {
        const hasData = await this.storageUtils.ensureObjectStoreExists();
        if (!hasData) {
          consoleDotLog$2("No storage data found - fresh initialization");
          return false;
        }
      } catch (e2) {
        consoleDotError$2("error: ", e2);
      }
      const allMounts = await this.storageUtils.getAll();
      consoleDotLog$2("Retrieved all mounts from storage:", allMounts);
      if (!allMounts || Object.keys(allMounts).length === 0) {
        consoleDotLog$2("No stored mounts found in fsTable");
        return false;
      }
      consoleDotLog$2(`Found ${Object.keys(allMounts).length} stored mounts`);
      for (const mountPath in allMounts) {
        const mountData = allMounts[mountPath];
        if (!mountData) continue;
        consoleDotLog$2(`Processing mount at ${mountPath} from fsTable`);
        try {
          const lastSlashIndex = mountPath.lastIndexOf("/");
          const path2 = mountPath.substring(0, lastSlashIndex);
          const fsName = mountPath.substring(lastSlashIndex + 1);
          await this.mount(
            path2,
            mountData.fsType,
            fsName,
            mountData.fetchMethod,
            {
              fetchInfo: mountData.fetchInfo,
              versioning: mountData.versioning,
              merging: mountData.merging
            }
          );
          consoleDotLog$2(`Successfully mounted ${mountPath} from fsTable`);
        } catch (mountError) {
          consoleDotError$2(`Failed to mount ${mountPath} from fsTable:`, mountError);
        }
      }
      consoleDotLog$2("Finished mounting all filesystems from fsTable");
      return true;
    } catch (error) {
      consoleDotError$2("Failed to retrieve and mount:", error);
      return false;
    }
  }
  async initializeStoredMount(mountPath, storedMount, fetchMethod, fetchInfo, options) {
    consoleDotLog$2(`Initializing stored mount at ${mountPath}`);
    try {
      consoleDotLog$2(`Creating FS instance for stored mount (type: ${storedMount.fsType})`);
      const fsInstance = await this.createFSInstance(
        storedMount.fsType,
        mountPath,
        {
          versioning: this.getVersioningConfig(storedMount),
          merging: this.getMergingConfig(storedMount)
        }
      );
      consoleDotLog$2(`Fetching data for stored mount using method: ${storedMount.fetchMethod || fetchMethod}`);
      await this.fetchFS(
        storedMount.fetchMethod || fetchMethod,
        storedMount.fsType,
        fsInstance,
        mountPath,
        storedMount.fetchInfo || fetchInfo
      );
      const environment = this.getPlatformInfo();
      const accessLog = storedMount.accessLog || [];
      accessLog.push({
        time: (/* @__PURE__ */ new Date()).toISOString(),
        action: "remount",
        environment
      });
      this.mounts[mountPath] = {
        ...storedMount,
        fsInstance,
        fetchMethod: storedMount.fetchMethod || fetchMethod,
        fetchInfo: {
          ...storedMount.fetchInfo || fetchInfo,
          lastFetched: (/* @__PURE__ */ new Date()).toISOString()
        },
        versioning: this.getVersioningConfig(storedMount),
        merging: this.getMergingConfig(storedMount),
        environment,
        // Update environment info
        modified: (/* @__PURE__ */ new Date()).toISOString(),
        accessLog
      };
      this.initializedMounts.add(mountPath);
      consoleDotLog$2(`Successfully initialized stored mount at ${mountPath}`);
      return this.mounts[mountPath];
    } catch (error) {
      consoleDotError$2(`Failed to initialize stored mount at ${mountPath}:`, error);
      throw error;
    }
  }
  async createNewMount(mountPath, fsType, fsName, fetchMethod, fetchInfo, versioning = {}, merging = {}) {
    consoleDotLog$2(`Creating new mount at ${mountPath}`);
    try {
      consoleDotLog$2(`Creating new FS instance (type: ${fsType})`);
      const fsInstance = await this.createFSInstance(fsType, mountPath, { versioning, merging });
      consoleDotLog$2(`Fetching data for new mount using method: ${fetchMethod}`);
      await this.fetchFS(fetchMethod, fsType, fsInstance, mountPath, fetchInfo);
      const vfsUtils = this.vfsUtilsInstances.get(mountPath);
      if (!vfsUtils) {
        throw new Error("VFSutils instance not found for mount");
      }
      consoleDotLog$2("Generating filesystem table");
      const fsTable = await vfsUtils.generateFsTable();
      const fsSize = await vfsUtils.getFsTableSize(fsTable);
      consoleDotLog$2(`Filesystem table generated, size: ${fsSize}`);
      const environment = this.getPlatformInfo();
      const mountData = {
        fsInstance,
        fsType: fsInstance instanceof MemoryFS ? "memory" : fsType,
        fsName,
        fsTable,
        fetchMethod,
        fetchInfo: {
          ...fetchInfo,
          time: (/* @__PURE__ */ new Date()).toISOString(),
          size: fsSize,
          lastFetched: (/* @__PURE__ */ new Date()).toISOString()
        },
        versioning: this.getVersioningConfig({ versioning }),
        merging: this.getMergingConfig({ merging }),
        environment,
        // Add environment info
        created: (/* @__PURE__ */ new Date()).toISOString(),
        modified: (/* @__PURE__ */ new Date()).toISOString(),
        accessLog: [{
          time: (/* @__PURE__ */ new Date()).toISOString(),
          action: "mount",
          environment
        }]
      };
      this.mounts[mountPath] = mountData;
      consoleDotLog$2(`Persisting mount data for ${mountPath}`);
      await this.persistMountData(mountPath, mountData);
      this.initializedMounts.add(mountPath);
      consoleDotLog$2(`Successfully mounted new filesystem at ${mountPath}`);
      return mountData;
    } catch (error) {
      consoleDotError$2(`Failed to create new mount at ${mountPath}:`, error);
      throw error;
    }
  }
  async getMountPaths() {
    return Object.keys(this.mounts);
  }
  async getMountInfo(mountPath) {
    if (!this.mounts[mountPath]) {
      const errorMsg = `Mount not found: ${mountPath}`;
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    }
    const mountData = this.mounts[mountPath];
    return {
      path: mountPath,
      type: mountData.fsType,
      name: mountData.fsName,
      fetchMethod: mountData.fetchMethod,
      versioning: mountData.versioning,
      merging: mountData.merging,
      created: mountData.created,
      modified: mountData.modified,
      lastFetched: mountData.fetchInfo.lastFetched,
      size: mountData.fetchInfo.size,
      environment: mountData.environment,
      accessLog: mountData.accessLog
    };
  }
  async unmount(path2, fsName) {
    const fsPath = path2 + "/" + fsName;
    consoleDotLog$2(`Unmounting filesystem at ${fsPath}`);
    if (!this.mounts[fsPath]) {
      const errorMsg = `Path ${fsPath} is not mounted`;
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    }
    const mountData = this.mounts[fsPath];
    try {
      if (this.vfsUtilsInstances.has(fsPath)) {
        consoleDotLog$2(`Terminating VFSutils instance for ${fsPath}`);
        await this.vfsUtilsInstances.get(fsPath).terminate(mountData.fsName, mountData.fsType);
        this.vfsUtilsInstances.delete(fsPath);
      }
      if (this.mounts[fsPath].fsInstance) {
        consoleDotLog$2(`Closing all files for mount at ${fsPath}`);
        await this.mounts[fsPath].fsInstance.fs_fcloseall();
        this.mounts[fsPath].fsInstance = null;
      }
      delete this.mounts[fsPath];
      this.initializedMounts.delete(fsPath);
      this.storageUtils.remove(fsPath);
      consoleDotLog$2(`Successfully unmounted ${fsPath}`);
      return true;
    } catch (error) {
      consoleDotError$2(`Error unmounting ${fsPath}:`, error);
      throw error;
    }
  }
  // Filesystem Operations
  async fetchFS(fetchMethod, fsType, fsInstance, fsName, fetchInfo) {
    consoleDotLog$2(`Fetching filesystem data - method: ${fetchMethod}, type: ${fsType}, name: ${fsName}`);
    try {
      if (this.vfsUtilsInstances.has(this.currentMountPath)) {
        consoleDotLog$2("Terminating existing VFSutils instance for this mount");
        await this.vfsUtilsInstances.get(this.currentMountPath).terminate();
        this.vfsUtilsInstances.delete(this.currentMountPath);
      }
      consoleDotLog$2("Creating new VFSutils instance for mount:", this.currentMountPath);
      const vfsUtils = new VFSutils(fsType, fsInstance, fsName, fetchInfo);
      this.vfsUtilsInstances.set(this.currentMountPath, vfsUtils);
      const fetchStrategies = {
        git: () => vfsUtils.fetchFromGit(),
        disk: () => vfsUtils.fetchFromDisk(),
        googleDrive: () => vfsUtils.fetchFromGoogleDrive()
      };
      const strategy = fetchStrategies[fetchMethod];
      if (!strategy) {
        const errorMsg = `Unknown fetch method: ${fetchMethod}`;
        consoleDotError$2(errorMsg);
        throw new Error(errorMsg);
      }
      consoleDotLog$2(`Executing fetch strategy for ${fetchMethod}`);
      await strategy();
      if (this.mounts[this.currentMountPath]) {
        this.mounts[this.currentMountPath].fetchInfo.lastFetched = (/* @__PURE__ */ new Date()).toISOString();
        this.mounts[this.currentMountPath].modified = (/* @__PURE__ */ new Date()).toISOString();
        await this.persistMountData(this.currentMountPath, this.mounts[this.currentMountPath]);
      }
      consoleDotLog$2(`Successfully fetched data using ${fetchMethod} method`);
    } catch (error) {
      consoleDotError$2(`Fetch operation failed (method: ${fetchMethod}):`, error);
      if (this.vfsUtilsInstances.has(this.currentMountPath)) {
        consoleDotLog$2("Cleaning up VFSutils after fetch failure");
        await this.vfsUtilsInstances.get(this.currentMountPath).terminate(fsName, fsType);
        this.vfsUtilsInstances.delete(this.currentMountPath);
      }
      throw error;
    }
  }
  async resolveFS(path2) {
    consoleDotLog$2(`Resolving filesystem for path: ${path2}`);
    try {
      for (const mountPath in this.mounts) {
        if (path2.startsWith(mountPath)) {
          consoleDotLog$2(`Found matching mount at `, mountPath);
          await this.ensureFSInitialized(mountPath);
          const relativePath = path2.slice(mountPath.length) || "/";
          consoleDotLog$2(`Resolved path: ${path2} to mount: ${mountPath}, relative path: ${relativePath}, this.mounts[mountPath] : `, this.mounts[mountPath]);
          consoleDotLog$2(
            "resolveFs returned value: ",
            {
              fs: this.mounts[mountPath],
              relativePath,
              versioning: this.mounts[mountPath].versioning || config$3.versioning,
              merging: this.mounts[mountPath].merging || config$3.merging
            }
          );
          return {
            fs: this.mounts[mountPath],
            relativePath,
            versioning: this.mounts[mountPath].versioning || config$3.versioning,
            merging: this.mounts[mountPath].merging || config$3.merging
          };
        }
      }
      const errorMsg = `No filesystem mounted for path: ${path2}`;
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    } catch (error) {
      consoleDotError$2(`Failed to resolve filesystem for path ${path2}:`, error);
      throw error;
    }
  }
  // Filesystem Table Operations
  async writeToFsTable(path2, type = "file", size = 0) {
    consoleDotLog$2(`Writing to fsTable - path: ${path2}, type: ${type}, size: ${size}`);
    await this.validateVFSutils();
    try {
      const vfsUtils = this.vfsUtilsInstances.get(this.currentMountPath);
      consoleDotLog$2(`Updating fsTable with create operation for ${path2}`);
      const updateResult = await vfsUtils.updateFsTable("create", path2, type, size);
      consoleDotLog$2(`Updating mount fsTable with new data`);
      await this.updateMountFsTable(updateResult.fsTable);
      consoleDotLog$2(`Successfully updated fsTable for ${path2}`);
      return updateResult.fsTable;
    } catch (error) {
      consoleDotError$2("Failed to write to fsTable:", error);
      throw error;
    }
  }
  async removeFromFsTable(path2) {
    consoleDotLog$2(`Removing from fsTable - path: ${path2}`);
    await this.validateVFSutils();
    try {
      const vfsUtils = this.vfsUtilsInstances.get(this.currentMountPath);
      consoleDotLog$2(`Updating fsTable with remove operation for ${path2}`);
      const updateResult = await vfsUtils.updateFsTable("remove", path2);
      consoleDotLog$2(`Updating mount fsTable with removal data`);
      await this.updateMountFsTable(updateResult.fsTable);
      consoleDotLog$2(`Successfully removed ${path2} from fsTable`);
      return updateResult.fsTable;
    } catch (error) {
      consoleDotError$2("Failed to remove from fsTable:", error);
      throw error;
    }
  }
  async updateMountFsTable(fsTable) {
    consoleDotLog$2(`Updating mount fsTable for current mount path`);
    if (!this.currentMountPath) {
      const errorMsg = "No active mount path available";
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    }
    if (typeof indexedDB === "undefined") {
      if (!this.mounts[this.currentMountPath]) {
        const errorMsg = `Mount data not found in memory for path: ${this.currentMountPath}`;
        consoleDotError$2(errorMsg);
        throw new Error(errorMsg);
      }
      this.mounts[this.currentMountPath].fsTable = fsTable;
      consoleDotLog$2(`Updated in-memory fsTable for ${this.currentMountPath}`);
      return;
    }
    consoleDotLog$2(`Loading mount data for ${this.currentMountPath}`);
    const mountData = await this.storageUtils.get(this.currentMountPath);
    if (!mountData) {
      const errorMsg = `Mount data not found for path: ${this.currentMountPath}`;
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    }
    consoleDotLog$2(`Updating fsTable in mount data`);
    mountData.fsTable = fsTable;
    consoleDotLog$2(`Storing updated mount data for ${this.currentMountPath}`);
    await this.storageUtils.store(this.currentMountPath, mountData);
    consoleDotLog$2(`Successfully updated mount fsTable`);
  }
  // Validation Utilities
  async validateVFSutils() {
    consoleDotLog$2("Validating VFSutils instance");
    if (!this.currentMountPath || !this.vfsUtilsInstances.has(this.currentMountPath)) {
      const errorMsg = "VFSutils not initialized for current mount";
      consoleDotError$2(errorMsg);
      throw new Error(errorMsg);
    }
    consoleDotLog$2("VFSutils validation passed");
  }
  //----------------------
  // Versioning Operations
  //----------------------
  async versioner(message) {
    consoleDotLog$2(`Committing version with message: ${message}`);
    await this.validateVFSutils();
    try {
      const vfsUtils = this.vfsUtilsInstances.get(this.currentMountPath);
      const commitResult = await vfsUtils.commitStagedChanges(message);
      consoleDotLog$2(`Version committed successfully`);
      return commitResult;
    } catch (error) {
      consoleDotError$2("Failed to commit version:", error);
      throw error;
    }
  }
  //--------------------
  // Merging Operations
  //--------------------
  async merger(onConflictStrategy) {
    consoleDotLog$2("Starting merge operation");
    await this.validateVFSutils();
    const syncUrl = this.mounts[this.currentMountPath]?.merging?.syncUrl;
    try {
      const vfsUtils = this.vfsUtilsInstances.get(this.currentMountPath);
      const mergeResult = await vfsUtils.autoSyncFlow(onConflictStrategy, syncUrl);
      consoleDotLog$2("Merge operation completed successfully:", mergeResult);
      return mergeResult;
    } catch (error) {
      consoleDotError$2("Merge operation failed:", error);
      throw error;
    }
  }
  //-------------------
  // Some info setters for vfsUtils
  //-------------------
  async setMergingStrategy(mergingStrategy) {
    consoleDotLog$2("Setting merging strategy");
    let mountData = this.mounts[this.currentMountPath];
    mountData = { ...mountData, merging: mergingStrategy };
    await this.persistMountData(this.currentMountPath, mountData);
    consoleDotLog$2("Merging strategy set successfully:", mergingStrategy);
    return true;
  }
  async setVersioingStrategy(versioningStrategy) {
    consoleDotLog$2("Setting versioning strategy");
    let mountData = this.mounts[this.currentMountPath];
    mountData = { ...mountData, versioning: versioningStrategy };
    await this.persistMountData(this.currentMountPath, mountData);
    consoleDotLog$2("Versioning strategy set successfully:", versioningStrategy);
    return true;
  }
  async setUserConfigs(args) {
    await this.validateVFSutils();
    consoleDotLog$2("Setting user configurations:", args);
    const vfsUtils = this.vfsUtilsInstances.get(this.currentMountPath);
    await vfsUtils.updateFetchInfo(args);
    let mountData = this.mounts[this.currentMountPath];
    mountData = { ...mountData, fetchInfo: { ...mountData.fetchInfo, ...args } };
    this.persistMountData(this.currentMountPath, mountData);
    return args;
  }
}
const config$2 = await getConfig();
const logger$1 = new Logger(config$2.logging.kfs);
function consoleDotLog$1(...params) {
  logger$1.consoleDotLog("[Versioning]", ...params);
}
function consoleDotError$1(...params) {
  logger$1.consoleDotError("[Versioning]", ...params);
}
class VersioningManager {
  constructor(vfs) {
    this.vfs = vfs;
    this.clockIntervalID = null;
    this.operationQueueCount = 0;
    this.config = this._getDefaultVersioningConfig();
  }
  _getDefaultVersioningConfig() {
    const versioning = config$2.versioning || {};
    return {
      strategy: versioning.strategy,
      interval: versioning.interval,
      number: versioning.number
    };
  }
  async _getVersioningConfig(options = {}) {
    const defaultConfig2 = this._getDefaultVersioningConfig();
    const versioning = options.versioning || {};
    return {
      strategy: versioning.strategy || defaultConfig2.strategy,
      interval: versioning.interval || defaultConfig2.interval,
      number: versioning.number || defaultConfig2.number
    };
  }
  async setup(options = {}) {
    this.config = await this._getVersioningConfig(options);
    consoleDotLog$1("Versioning configuration:", this.config);
    if (this.config.strategy === "clock") {
      this._startClockVersioning();
    } else {
      this.clearClock();
    }
  }
  clearClock() {
    if (this.clockIntervalID) {
      clearInterval(this.clockIntervalID);
      this.clockIntervalID = null;
    }
  }
  _startClockVersioning() {
    this.clearClock();
    const intervalMs = (this.config.interval || 10) * 1e3;
    consoleDotLog$1("Starting clock-based versioning with interval:", intervalMs, "ms");
    this.clockIntervalID = setInterval(async () => {
      consoleDotLog$1("Clock-based auto commit triggered");
      try {
        await this.vfs.versioner("Clock-based auto commit");
      } catch (error) {
        consoleDotError$1("Error in clock-based versioning:", error);
      }
    }, intervalMs);
  }
  async maybeTriggerVersioning(overrideConfig = null) {
    const strategyConfig = overrideConfig || this.config;
    if (strategyConfig.strategy === "immediate") return;
    if (strategyConfig.strategy === "batch") {
      this.operationQueueCount++;
      const batchSize = strategyConfig.number || 5;
      consoleDotLog$1(`Batch operation count: ${this.operationQueueCount}/${batchSize}`);
      if (this.operationQueueCount >= batchSize) {
        this.operationQueueCount = 0;
        await this.vfs.versioner(`Batch commit after ${batchSize} operations`);
      }
    }
  }
  async getConfig() {
    return this.config;
  }
}
const config$1 = await getConfig();
new Logger(config$1.logging.kfs);
class MergingManager {
  constructor(vfs) {
    this.vfs = vfs;
    this.clockIntervalID = null;
    this.config = this._getDefaultMergingConfig();
  }
  _getDefaultMergingConfig() {
    return {
      strategy: config$1.merging?.strategy || null,
      interval: config$1.merging?.interval || 10,
      number: config$1.merging?.number || 5
    };
  }
  async setup(options = {}) {
    this.config = {
      ...this._getDefaultMergingConfig(),
      ...options.merging || {}
    };
    if (this.config.strategy === "clock") {
      await this._startClockMerging();
    } else {
      this.clearClock();
    }
  }
  async _startClockMerging() {
    this.clearClock();
    const intervalMs = this.config.interval * 1e3;
    this.clockIntervalID = setInterval(async () => {
      try {
        await this.vfs.merger();
      } catch (error) {
        console.error("Clock-based merge failed:", error);
      }
    }, intervalMs);
  }
  clearClock() {
    if (this.clockIntervalID) {
      clearInterval(this.clockIntervalID);
      this.clockIntervalID = null;
    }
  }
  async getConfig() {
    return this.config;
  }
}
const config = await getConfig();
const logger = new Logger(config.logging.kfs);
function consoleDotLog(...params) {
  logger.consoleDotLog("[KFS]", ...params);
}
function consoleDotError(...params) {
  logger.consoleDotError("[KFS]", ...params);
}
class KFS {
  constructor() {
    this.vfs = new VFS();
    this.fsInstance = null;
    this.versioningManager = new VersioningManager(this.vfs);
    this.mergingManager = new MergingManager(this.vfs);
    this.commitCount = 0;
    this.mountPaths = null;
    this.mergingConfig = null;
    (async () => {
      try {
        await this.init();
      } catch (error) {
        consoleDotError("Initing Failed for KFS: ", error);
      }
    })();
    consoleDotLog("KFS instance created");
  }
  async init() {
    if (!this.initialized) {
      this.mountPaths = await this.vfs.getMountPaths();
      this.initialized = true;
    }
    consoleDotLog("mountpaths: ", this.mountPaths);
    return this;
  }
  // -------------------------------
  // Versioning Configuration
  // -------------------------------
  _setupVersioningAndMerging(options) {
    this.versioningManager.setup(options);
    this.mergingManager.setup(options);
  }
  _clearClocks() {
    this.versioningManager.clearClock();
    this.mergingManager.clearClock();
  }
  async _handleCommit(message) {
    await this.versioningManager.getConfig();
    this.mergingConfig = await this.mergingManager.getConfig();
    const strategyMap = { remote: "theirs", local: "ours", combine: "combine" };
    const userStrategy = this.mergingConfig?.onConflictStrategy || "remote";
    const onConflictStrategy = strategyMap[userStrategy] || "remote";
    await this.vfs.versioner(message);
    this.commitCount++;
    if (this.mergingConfig?.strategy === "immediate") {
      await this.vfs.merger(onConflictStrategy);
    }
  }
  async merge() {
    try {
      consoleDotLog("Merging...", this.mountPaths);
      const strategyMap = { remote: "theirs", local: "ours", combine: "combine" };
      const userStrategy = this.mergingConfig?.onConflictStrategy || "remote";
      const onConflictStrategy = strategyMap[userStrategy] || "remote";
      consoleDotLog("Merging...", this.mountPaths);
      await this.vfs.merger(onConflictStrategy);
      consoleDotLog("Merge completed successfully.");
    } catch (error) {
      consoleDotError("Merge failed:", error);
      throw new Error(`Failed to merge: ${error.message}`);
    }
  }
  // -------------------------------
  // Filesystem Operations
  // -------------------------------
  async mount(path2, fsType, fsName, fetchMethod, options = {}) {
    try {
      this._setupVersioningAndMerging(options);
      path2 = this._normalizePath(path2);
      const versioningConfig = await this.versioningManager.getConfig();
      this.mergingConfig = await this.mergingManager.getConfig();
      const mountData = await this.vfs.mount(path2, fsType, fsName, fetchMethod, {
        ...options,
        versioning: versioningConfig,
        merging: this.mergingConfig
      });
      this.mergingConfig = mountData.merging;
      this.fsInstance = mountData.fsInstance;
      const root = await this.read(`${path2}/${fsName}`);
      this.mountPaths = await this.vfs.getMountPaths();
      consoleDotLog("Mount successful, root:", root);
      return mountData;
    } catch (error) {
      consoleDotError(`Failed to mount filesystem at ${path2}:`, error);
      throw new Error(`Failed to mount filesystem: ${error.message}`);
    }
  }
  async unmount(path2, fsName) {
    try {
      path2 = this._normalizePath(path2);
      await this.vfs.unmount(path2, fsName);
      this.fsInstance = null;
      this._clearClocks();
      this.commitCount = 0;
      return { success: true };
    } catch (error) {
      consoleDotError(`Failed to unmount filesystem at ${path2}:`, error);
      throw new Error(`Failed to unmount filesystem: ${error.message}`);
    }
  }
  async setMergingStrategy(mergingStrategy) {
    await this.vfs.setMergingStrategy(mergingStrategy);
    consoleDotLog("Merging strategy set to:", mergingStrategy);
  }
  async setVersioingStrategy(versioningStrategy) {
    await this.vfs.setVersioingStrategy(versioningStrategy);
    consoleDotLog("Versioning strategy set to:", versioningStrategy);
  }
  /**
   * Sets user configurations for the KFS instance.
    * @param {string} [args.name] - The name of the user.
    * @param {string} [args.email] - The email of the user.
    * @param {string} [args.username] - The username of the user.
    * @param {string} [args.password] - The password of the user.
    * @throws {Error} - Throws an error if the arguments are invalid or if the operation fails.
   */
  async setUserConfigs(args) {
    if (!args || typeof args !== "object") {
      throw new Error("Invalid arguments: must be an object");
    }
    const allowedFields = ["password", "username", "email", "name"];
    const invalidFields = Object.keys(args).filter(
      (field) => !allowedFields.includes(field)
    );
    if (invalidFields.length > 0) {
      throw new Error(
        `Invalid field(s) provided: ${invalidFields.join(", ")}. Allowed fields are: ${allowedFields.join(", ")}`
      );
    }
    args && this.vfs.setUserConfigs(args);
    return args;
  }
  async create(path2, type = "file", content = "", mode = "w") {
    try {
      if (!["file", "dir"].includes(type)) {
        throw new Error(`Invalid type: ${type}. Must be 'file' or 'dir'`);
      }
      if (!["a", "w"].includes(mode)) {
        throw new Error(`Invalid mode: ${mode}. Must be 'a' (append) or 'w' (write)`);
      }
      path2 = this._normalizePath(path2);
      if (this.mountPaths && this.mountPaths.includes(path2)) {
        throw new Error(`Cannot write directly to mount path (${path2}). Use mount() instead.`);
      }
      const { fs, relativePath, versioning } = await this.vfs.resolveFS(path2);
      if (type === "file") {
        await this._ensurePathExists(fs, relativePath);
        let finalContent = content;
        let operationMessage = `Created file at ${path2}`;
        if (mode === "a") {
          try {
            const fd2 = await fs.fsInstance.fs_fopen(relativePath, "r");
            const existingContent = await fs.fsInstance.fs_fread(fd2, 1024 * 1024);
            await fs.fsInstance.fs_fclose(fd2);
            finalContent = existingContent + content;
            operationMessage = `Appended to file at ${path2}`;
          } catch (readError) {
            operationMessage = `Created file at ${path2}`;
          }
        }
        const fd = await fs.fsInstance.fs_fopen(relativePath, "w");
        const writeResult = await fs.fsInstance.fs_fwrite(fd, finalContent);
        if (writeResult === -1) {
          throw new Error("Failed to write to file");
        }
        await fs.fsInstance.fs_fclose(fd);
        await this.vfs.writeToFsTable(relativePath, type, finalContent.length);
        if (versioning?.strategy === "immediate") {
          await this._handleCommit(operationMessage);
        } else {
          await this.versioningManager.maybeTriggerVersioning(versioning);
        }
      } else if (type === "dir") {
        if (mode === "a") {
          try {
            await fs.fsInstance.fs_mkdir(relativePath);
            await this.vfs.writeToFsTable(relativePath, type, 0);
            if (versioning?.strategy === "immediate") {
              await this._handleCommit(`Created directory at ${path2}`);
            }
          } catch (error) {
            if (!error.message.includes("exists")) throw error;
          }
        } else {
          try {
            const stats = await fs.fsInstance.fs_stat(relativePath);
            if (await stats.isDirectory()) {
              await fs.fsInstance.fs_rmdir(relativePath);
            } else {
              await fs.fsInstance.fs_remove(relativePath);
            }
          } catch (error) {
          }
          await fs.fsInstance.fs_mkdir(relativePath);
          await this.vfs.writeToFsTable(relativePath, type, 0);
          if (versioning?.strategy === "immediate") {
            await this._handleCommit(`Created directory at ${path2}`);
          }
        }
      }
      return { success: true };
    } catch (error) {
      consoleDotError(`Failed to create ${type} at ${path2}:`, error);
      throw new Error(`Failed to create: ${error.message}`);
    }
  }
  async remove(path2) {
    try {
      path2 = this._normalizePath(path2);
      if (this.mountPaths && this.mountPaths.includes(path2)) {
        throw new Error(`Cannot remove path (${path2}) directly. Use unmount() instead.`);
      }
      const { fs, relativePath, versioning } = await this.vfs.resolveFS(path2);
      const stats = await fs.fsInstance.fs_stat(relativePath);
      if (!stats) throw new Error("ENOENT: no such file or directory");
      if (await stats.isDirectory()) {
        await fs.fsInstance.fs_rmdir(relativePath);
      } else {
        await fs.fsInstance.fs_remove(relativePath);
      }
      await this.vfs.removeFromFsTable(relativePath);
      if (versioning?.strategy === "immediate") {
        await this._handleCommit(`Removed ${path2}`);
      } else {
        await this.versioningManager.maybeTriggerVersioning(versioning);
      }
      return { success: true };
    } catch (error) {
      consoleDotError(`Failed to remove ${path2}:`, error);
      throw new Error(`Failed to remove: ${error.message}`);
    }
  }
  async read(path2) {
    try {
      path2 = this._normalizePath(path2);
      const { fs, relativePath } = await this.vfs.resolveFS(path2);
      this.fsInstance = fs.fsInstance;
      const stats = await this.fsInstance.fs_stat(relativePath);
      if (!stats) throw new Error("ENOENT: no such file or directory");
      if (await stats.isDirectory()) {
        const result = await this.fsInstance.fs_readdir(relativePath);
        consoleDotLog("result", result);
        return result;
      } else {
        const fd = await this.fsInstance.fs_fopen(relativePath, "r");
        const data = await this.fsInstance.fs_fread(fd, 1024 * 1024);
        await this.fsInstance.fs_fclose(fd);
        return data;
      }
    } catch (error) {
      throw new Error(`Failed to read file: ${error.message}`);
    }
  }
  // -------------------------------
  // Utility Methods
  // -------------------------------
  async _ensurePathExists(fs, path2) {
    const parts = path2.split("/").filter((p) => p !== "");
    const dirParts = parts.slice(0, -1);
    let currentPath = "";
    for (const part of dirParts) {
      currentPath = currentPath ? `${currentPath}/${part}` : `/${part}`;
      try {
        await fs.fsInstance.fs_mkdir(currentPath);
        await this.vfs.writeToFsTable(currentPath, "dir");
      } catch (error) {
        if (!error.message.includes("exists")) consoleDotError(error);
      }
    }
  }
  _normalizePath(path2) {
    if (typeof path2 !== "string") throw new Error("Path must be a string");
    return path2.startsWith("/") ? path2 : `/${path2}`;
  }
  // Config functions
  async setConfig(config2) {
    return configStore.setConfig(config2);
  }
}
export {
  KFS as K,
  Logger as L,
  getConfig as g,
  process$1 as p,
  workerPool as w
};
//# sourceMappingURL=kfs-Bpj766xl.js.map
